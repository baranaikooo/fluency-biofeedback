var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=(n,r,a)=>(a=n==null?{}:e(i(n)),s(r||!n||!n.__esModule?t(a,`default`,{value:n,enumerable:!0}):a,n));(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var l=o(((e,t)=>{(function(){function n(e,t){Object.defineProperty(a.prototype,e,{get:function(){console.warn(`%s(...) is deprecated in plain JavaScript React classes. %s`,t[0],t[1])}})}function r(e){return typeof e!=`object`||!e?null:(e=we&&e[we]||e[`@@iterator`],typeof e==`function`?e:null)}function i(e,t){e=(e=e.constructor)&&(e.displayName||e.name)||`ReactClass`;var n=e+`.`+t;Te[n]||(console.error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.",t,e),Te[n]=!0)}function a(e,t,n){this.props=e,this.context=t,this.refs=De,this.updater=n||Ee}function o(){}function s(e,t,n){this.props=e,this.context=t,this.refs=De,this.updater=n||Ee}function c(){}function l(e){return``+e}function u(e){try{l(e);var t=!1}catch{t=!0}if(t){t=console;var n=t.error,r=typeof Symbol==`function`&&Symbol.toStringTag&&e[Symbol.toStringTag]||e.constructor.name||`Object`;return n.call(t,`The provided key is an unsupported type %s. This value must be coerced to a string before using it here.`,r),l(e)}}function d(e){if(e==null)return null;if(typeof e==`function`)return e.$$typeof===Ae?null:e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case pe:return`Fragment`;case he:return`Profiler`;case me:return`StrictMode`;case ye:return`Suspense`;case be:return`SuspenseList`;case Ce:return`Activity`}if(typeof e==`object`)switch(typeof e.tag==`number`&&console.error(`Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue.`),e.$$typeof){case fe:return`Portal`;case _e:return e.displayName||`Context`;case ge:return(e._context.displayName||`Context`)+`.Consumer`;case ve:var t=e.render;return e=e.displayName,e||=(e=t.displayName||t.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case xe:return t=e.displayName||null,t===null?d(e.type)||`Memo`:t;case Se:t=e._payload,e=e._init;try{return d(e(t))}catch{}}return null}function f(e){if(e===pe)return`<>`;if(typeof e==`object`&&e&&e.$$typeof===Se)return`<...>`;try{var t=d(e);return t?`<`+t+`>`:`<...>`}catch{return`<...>`}}function p(){var e=T.A;return e===null?null:e.getOwner()}function m(){return Error(`react-stack-top-frame`)}function h(e){if(je.call(e,`key`)){var t=Object.getOwnPropertyDescriptor(e,`key`).get;if(t&&t.isReactWarning)return!1}return e.key!==void 0}function g(e,t){function n(){Ne||(Ne=!0,console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)",t))}n.isReactWarning=!0,Object.defineProperty(e,`key`,{get:n,configurable:!0})}function _(){var e=d(this.type);return Pe[e]||(Pe[e]=!0,console.error(`Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release.`)),e=this.props.ref,e===void 0?null:e}function v(e,t,n,r,i,a){var o=n.ref;return e={$$typeof:de,type:e,key:t,props:n,_owner:r},(o===void 0?null:o)===null?Object.defineProperty(e,`ref`,{enumerable:!1,value:null}):Object.defineProperty(e,`ref`,{enumerable:!1,get:_}),e._store={},Object.defineProperty(e._store,`validated`,{configurable:!1,enumerable:!1,writable:!0,value:0}),Object.defineProperty(e,`_debugInfo`,{configurable:!1,enumerable:!1,writable:!0,value:null}),Object.defineProperty(e,`_debugStack`,{configurable:!1,enumerable:!1,writable:!0,value:i}),Object.defineProperty(e,`_debugTask`,{configurable:!1,enumerable:!1,writable:!0,value:a}),Object.freeze&&(Object.freeze(e.props),Object.freeze(e)),e}function y(e,t){return t=v(e.type,t,e.props,e._owner,e._debugStack,e._debugTask),e._store&&(t._store.validated=e._store.validated),t}function b(e){ee(e)?e._store&&(e._store.validated=1):typeof e==`object`&&e&&e.$$typeof===Se&&(e._payload.status===`fulfilled`?ee(e._payload.value)&&e._payload.value._store&&(e._payload.value._store.validated=1):e._store&&(e._store.validated=1))}function ee(e){return typeof e==`object`&&!!e&&e.$$typeof===de}function te(e){var t={"=":`=0`,":":`=2`};return`$`+e.replace(/[=:]/g,function(e){return t[e]})}function ne(e,t){return typeof e==`object`&&e&&e.key!=null?(u(e.key),te(``+e.key)):t.toString(36)}function re(e){switch(e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason;default:switch(typeof e.status==`string`?e.then(c,c):(e.status=`pending`,e.then(function(t){e.status===`pending`&&(e.status=`fulfilled`,e.value=t)},function(t){e.status===`pending`&&(e.status=`rejected`,e.reason=t)})),e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason}}throw e}function ie(e,t,n,i,a){var o=typeof e;(o===`undefined`||o===`boolean`)&&(e=null);var s=!1;if(e===null)s=!0;else switch(o){case`bigint`:case`string`:case`number`:s=!0;break;case`object`:switch(e.$$typeof){case de:case fe:s=!0;break;case Se:return s=e._init,ie(s(e._payload),t,n,i,a)}}if(s){s=e,a=a(s);var c=i===``?`.`+ne(s,0):i;return ke(a)?(n=``,c!=null&&(n=c.replace(Re,`$&/`)+`/`),ie(a,t,n,``,function(e){return e})):a!=null&&(ee(a)&&(a.key!=null&&(s&&s.key===a.key||u(a.key)),n=y(a,n+(a.key==null||s&&s.key===a.key?``:(``+a.key).replace(Re,`$&/`)+`/`)+c),i!==``&&s!=null&&ee(s)&&s.key==null&&s._store&&!s._store.validated&&(n._store.validated=2),a=n),t.push(a)),1}if(s=0,c=i===``?`.`:i+`:`,ke(e))for(var l=0;l<e.length;l++)i=e[l],o=c+ne(i,l),s+=ie(i,t,n,o,a);else if(l=r(e),typeof l==`function`)for(l===e.entries&&(Le||console.warn(`Using Maps as children is not supported. Use an array of keyed ReactElements instead.`),Le=!0),e=l.call(e),l=0;!(i=e.next()).done;)i=i.value,o=c+ne(i,l++),s+=ie(i,t,n,o,a);else if(o===`object`){if(typeof e.then==`function`)return ie(re(e),t,n,i,a);throw t=String(e),Error(`Objects are not valid as a React child (found: `+(t===`[object Object]`?`object with keys {`+Object.keys(e).join(`, `)+`}`:t)+`). If you meant to render a collection of children, use an array instead.`)}return s}function ae(e,t,n){if(e==null)return e;var r=[],i=0;return ie(e,r,``,``,function(e){return t.call(n,e,i++)}),r}function oe(e){if(e._status===-1){var t=e._ioInfo;t!=null&&(t.start=t.end=performance.now()),t=e._result;var n=t();if(n.then(function(t){if(e._status===0||e._status===-1){e._status=1,e._result=t;var r=e._ioInfo;r!=null&&(r.end=performance.now()),n.status===void 0&&(n.status=`fulfilled`,n.value=t)}},function(t){if(e._status===0||e._status===-1){e._status=2,e._result=t;var r=e._ioInfo;r!=null&&(r.end=performance.now()),n.status===void 0&&(n.status=`rejected`,n.reason=t)}}),t=e._ioInfo,t!=null){t.value=n;var r=n.displayName;typeof r==`string`&&(t.name=r)}e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return t=e._result,t===void 0&&console.error(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`,t),`default`in t||console.error(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`,t),t.default;throw e._result}function x(){var e=T.H;return e===null&&console.error(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.`),e}function se(){T.asyncTransitions--}function S(e){if(Ve===null)try{var n=(`require`+Math.random()).slice(0,7);Ve=(t&&t[n]).call(t,`timers`).setImmediate}catch{Ve=function(e){!1===Be&&(Be=!0,typeof MessageChannel>`u`&&console.error(`This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning.`));var t=new MessageChannel;t.port1.onmessage=e,t.port2.postMessage(void 0)}}return Ve(e)}function ce(e){return 1<e.length&&typeof AggregateError==`function`?AggregateError(e):e[0]}function le(e,t){t!==He-1&&console.error(`You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. `),He=t}function C(e,t,n){var r=T.actQueue;if(r!==null)if(r.length!==0)try{ue(r),S(function(){return C(e,t,n)});return}catch(e){T.thrownErrors.push(e)}else T.actQueue=null;0<T.thrownErrors.length?(r=ce(T.thrownErrors),T.thrownErrors.length=0,n(r)):t(e)}function ue(e){if(!We){We=!0;var t=0;try{for(;t<e.length;t++){var n=e[t];do{T.didUsePromise=!1;var r=n(!1);if(r!==null){if(T.didUsePromise){e[t]=n,e.splice(0,t);return}n=r}else break}while(1)}e.length=0}catch(n){e.splice(0,t+1),T.thrownErrors.push(n)}finally{We=!1}}}typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart==`function`&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());var de=Symbol.for(`react.transitional.element`),fe=Symbol.for(`react.portal`),pe=Symbol.for(`react.fragment`),me=Symbol.for(`react.strict_mode`),he=Symbol.for(`react.profiler`),ge=Symbol.for(`react.consumer`),_e=Symbol.for(`react.context`),ve=Symbol.for(`react.forward_ref`),ye=Symbol.for(`react.suspense`),be=Symbol.for(`react.suspense_list`),xe=Symbol.for(`react.memo`),Se=Symbol.for(`react.lazy`),Ce=Symbol.for(`react.activity`),we=Symbol.iterator,Te={},Ee={isMounted:function(){return!1},enqueueForceUpdate:function(e){i(e,`forceUpdate`)},enqueueReplaceState:function(e){i(e,`replaceState`)},enqueueSetState:function(e){i(e,`setState`)}},w=Object.assign,De={};Object.freeze(De),a.prototype.isReactComponent={},a.prototype.setState=function(e,t){if(typeof e!=`object`&&typeof e!=`function`&&e!=null)throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);this.updater.enqueueSetState(this,e,t,`setState`)},a.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,`forceUpdate`)};var Oe={isMounted:[`isMounted`,`Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks.`],replaceState:[`replaceState`,`Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236).`]};for(Ke in Oe)Oe.hasOwnProperty(Ke)&&n(Ke,Oe[Ke]);o.prototype=a.prototype,Oe=s.prototype=new o,Oe.constructor=s,w(Oe,a.prototype),Oe.isPureReactComponent=!0;var ke=Array.isArray,Ae=Symbol.for(`react.client.reference`),T={H:null,A:null,T:null,S:null,actQueue:null,asyncTransitions:0,isBatchingLegacy:!1,didScheduleLegacyUpdate:!1,didUsePromise:!1,thrownErrors:[],getCurrentStack:null,recentlyCreatedOwnerStacks:0},je=Object.prototype.hasOwnProperty,Me=console.createTask?console.createTask:function(){return null};Oe={react_stack_bottom_frame:function(e){return e()}};var Ne,E,Pe={},Fe=Oe.react_stack_bottom_frame.bind(Oe,m)(),Ie=Me(f(m)),Le=!1,Re=/\/+/g,ze=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)},Be=!1,Ve=null,He=0,Ue=!1,We=!1,Ge=typeof queueMicrotask==`function`?function(e){queueMicrotask(function(){return queueMicrotask(e)})}:S;Oe=Object.freeze({__proto__:null,c:function(e){return x().useMemoCache(e)}});var Ke={map:ae,forEach:function(e,t,n){ae(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return ae(e,function(){t++}),t},toArray:function(e){return ae(e,function(e){return e})||[]},only:function(e){if(!ee(e))throw Error(`React.Children.only expected to receive a single React element child.`);return e}};e.Activity=Ce,e.Children=Ke,e.Component=a,e.Fragment=pe,e.Profiler=he,e.PureComponent=s,e.StrictMode=me,e.Suspense=ye,e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=T,e.__COMPILER_RUNTIME=Oe,e.act=function(e){var t=T.actQueue,n=He;He++;var r=T.actQueue=t===null?[]:t,i=!1;try{var a=e()}catch(e){T.thrownErrors.push(e)}if(0<T.thrownErrors.length)throw le(t,n),e=ce(T.thrownErrors),T.thrownErrors.length=0,e;if(typeof a==`object`&&a&&typeof a.then==`function`){var o=a;return Ge(function(){i||Ue||(Ue=!0,console.error(`You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);`))}),{then:function(e,a){i=!0,o.then(function(i){if(le(t,n),n===0){try{ue(r),S(function(){return C(i,e,a)})}catch(e){T.thrownErrors.push(e)}if(0<T.thrownErrors.length){var o=ce(T.thrownErrors);T.thrownErrors.length=0,a(o)}}else e(i)},function(e){le(t,n),0<T.thrownErrors.length?(e=ce(T.thrownErrors),T.thrownErrors.length=0,a(e)):a(e)})}}}var s=a;if(le(t,n),n===0&&(ue(r),r.length!==0&&Ge(function(){i||Ue||(Ue=!0,console.error("A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"))}),T.actQueue=null),0<T.thrownErrors.length)throw e=ce(T.thrownErrors),T.thrownErrors.length=0,e;return{then:function(e,t){i=!0,n===0?(T.actQueue=r,S(function(){return C(s,e,t)})):e(s)}}},e.cache=function(e){return function(){return e.apply(null,arguments)}},e.cacheSignal=function(){return null},e.captureOwnerStack=function(){var e=T.getCurrentStack;return e===null?null:e()},e.cloneElement=function(e,t,n){if(e==null)throw Error(`The argument must be a React element, but you passed `+e+`.`);var r=w({},e.props),i=e.key,a=e._owner;if(t!=null){var o;a:{if(je.call(t,`ref`)&&(o=Object.getOwnPropertyDescriptor(t,`ref`).get)&&o.isReactWarning){o=!1;break a}o=t.ref!==void 0}for(s in o&&(a=p()),h(t)&&(u(t.key),i=``+t.key),t)!je.call(t,s)||s===`key`||s===`__self`||s===`__source`||s===`ref`&&t.ref===void 0||(r[s]=t[s])}var s=arguments.length-2;if(s===1)r.children=n;else if(1<s){o=Array(s);for(var c=0;c<s;c++)o[c]=arguments[c+2];r.children=o}for(r=v(e.type,i,r,a,e._debugStack,e._debugTask),i=2;i<arguments.length;i++)b(arguments[i]);return r},e.createContext=function(e){return e={$$typeof:_e,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:ge,_context:e},e._currentRenderer=null,e._currentRenderer2=null,e},e.createElement=function(e,t,n){for(var r=2;r<arguments.length;r++)b(arguments[r]);r={};var i=null;if(t!=null)for(c in E||!(`__self`in t)||`key`in t||(E=!0,console.warn(`Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform`)),h(t)&&(u(t.key),i=``+t.key),t)je.call(t,c)&&c!==`key`&&c!==`__self`&&c!==`__source`&&(r[c]=t[c]);var a=arguments.length-2;if(a===1)r.children=n;else if(1<a){for(var o=Array(a),s=0;s<a;s++)o[s]=arguments[s+2];Object.freeze&&Object.freeze(o),r.children=o}if(e&&e.defaultProps)for(c in a=e.defaultProps,a)r[c]===void 0&&(r[c]=a[c]);i&&g(r,typeof e==`function`?e.displayName||e.name||`Unknown`:e);var c=1e4>T.recentlyCreatedOwnerStacks++;return v(e,i,r,p(),c?Error(`react-stack-top-frame`):Fe,c?Me(f(e)):Ie)},e.createRef=function(){var e={current:null};return Object.seal(e),e},e.forwardRef=function(e){e!=null&&e.$$typeof===xe?console.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...))."):typeof e==`function`?e.length!==0&&e.length!==2&&console.error(`forwardRef render functions accept exactly two parameters: props and ref. %s`,e.length===1?`Did you forget to use the ref parameter?`:`Any additional parameter will be undefined.`):console.error(`forwardRef requires a render function but was given %s.`,e===null?`null`:typeof e),e!=null&&e.defaultProps!=null&&console.error(`forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?`);var t={$$typeof:ve,render:e},n;return Object.defineProperty(t,`displayName`,{enumerable:!1,configurable:!0,get:function(){return n},set:function(t){n=t,e.name||e.displayName||(Object.defineProperty(e,`name`,{value:t}),e.displayName=t)}}),t},e.isValidElement=ee,e.lazy=function(e){e={_status:-1,_result:e};var t={$$typeof:Se,_payload:e,_init:oe},n={name:`lazy`,start:-1,end:-1,value:null,owner:null,debugStack:Error(`react-stack-top-frame`),debugTask:console.createTask?console.createTask(`lazy()`):null};return e._ioInfo=n,t._debugInfo=[{awaited:n}],t},e.memo=function(e,t){e??console.error(`memo: The first argument must be a component. Instead received: %s`,e===null?`null`:typeof e),t={$$typeof:xe,type:e,compare:t===void 0?null:t};var n;return Object.defineProperty(t,`displayName`,{enumerable:!1,configurable:!0,get:function(){return n},set:function(t){n=t,e.name||e.displayName||(Object.defineProperty(e,`name`,{value:t}),e.displayName=t)}}),t},e.startTransition=function(e){var t=T.T,n={};n._updatedFibers=new Set,T.T=n;try{var r=e(),i=T.S;i!==null&&i(n,r),typeof r==`object`&&r&&typeof r.then==`function`&&(T.asyncTransitions++,r.then(se,se),r.then(c,ze))}catch(e){ze(e)}finally{t===null&&n._updatedFibers&&(e=n._updatedFibers.size,n._updatedFibers.clear(),10<e&&console.warn(`Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.`)),t!==null&&n.types!==null&&(t.types!==null&&t.types!==n.types&&console.error(`We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React.`),t.types=n.types),T.T=t}},e.unstable_useCacheRefresh=function(){return x().useCacheRefresh()},e.use=function(e){return x().use(e)},e.useActionState=function(e,t,n){return x().useActionState(e,t,n)},e.useCallback=function(e,t){return x().useCallback(e,t)},e.useContext=function(e){var t=x();return e.$$typeof===ge&&console.error(`Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?`),t.useContext(e)},e.useDebugValue=function(e,t){return x().useDebugValue(e,t)},e.useDeferredValue=function(e,t){return x().useDeferredValue(e,t)},e.useEffect=function(e,t){return e??console.warn(`React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?`),x().useEffect(e,t)},e.useEffectEvent=function(e){return x().useEffectEvent(e)},e.useId=function(){return x().useId()},e.useImperativeHandle=function(e,t,n){return x().useImperativeHandle(e,t,n)},e.useInsertionEffect=function(e,t){return e??console.warn(`React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?`),x().useInsertionEffect(e,t)},e.useLayoutEffect=function(e,t){return e??console.warn(`React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?`),x().useLayoutEffect(e,t)},e.useMemo=function(e,t){return x().useMemo(e,t)},e.useOptimistic=function(e,t){return x().useOptimistic(e,t)},e.useReducer=function(e,t,n){return x().useReducer(e,t,n)},e.useRef=function(e){return x().useRef(e)},e.useState=function(e){return x().useState(e)},e.useSyncExternalStore=function(e,t,n){return x().useSyncExternalStore(e,t,n)},e.useTransition=function(){return x().useTransition()},e.version=`19.2.4`,typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop==`function`&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error())})()})),u=o(((e,t)=>{t.exports=l()})),d=o((e=>{(function(){function t(){if(ee=!1,ie){var t=e.unstable_now();x=t;var n=!0;try{a:{y=!1,b&&(b=!1,ne(ae),ae=-1),v=!0;var a=_;try{b:{for(o(t),g=r(p);g!==null&&!(g.expirationTime>t&&c());){var u=g.callback;if(typeof u==`function`){g.callback=null,_=g.priorityLevel;var d=u(g.expirationTime<=t);if(t=e.unstable_now(),typeof d==`function`){g.callback=d,o(t),n=!0;break b}g===r(p)&&i(p),o(t)}else i(p);g=r(p)}if(g!==null)n=!0;else{var f=r(m);f!==null&&l(s,f.startTime-t),n=!1}}break a}finally{g=null,_=a,v=!1}n=void 0}}finally{n?se():ie=!1}}}function n(e,t){var n=e.length;e.push(t);a:for(;0<n;){var r=n-1>>>1,i=e[r];if(0<a(i,t))e[r]=t,e[n]=i,n=r;else break a}}function r(e){return e.length===0?null:e[0]}function i(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;a:for(var r=0,i=e.length,o=i>>>1;r<o;){var s=2*(r+1)-1,c=e[s],l=s+1,u=e[l];if(0>a(c,n))l<i&&0>a(u,c)?(e[r]=u,e[l]=n,r=l):(e[r]=c,e[s]=n,r=s);else if(l<i&&0>a(u,n))e[r]=u,e[l]=n,r=l;else break a}}return t}function a(e,t){var n=e.sortIndex-t.sortIndex;return n===0?e.id-t.id:n}function o(e){for(var t=r(m);t!==null;){if(t.callback===null)i(m);else if(t.startTime<=e)i(m),t.sortIndex=t.expirationTime,n(p,t);else break;t=r(m)}}function s(e){if(b=!1,o(e),!y)if(r(p)!==null)y=!0,ie||(ie=!0,se());else{var t=r(m);t!==null&&l(s,t.startTime-e)}}function c(){return ee?!0:!(e.unstable_now()-x<oe)}function l(t,n){ae=te(function(){t(e.unstable_now())},n)}if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart==`function`&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error()),e.unstable_now=void 0,typeof performance==`object`&&typeof performance.now==`function`){var u=performance;e.unstable_now=function(){return u.now()}}else{var d=Date,f=d.now();e.unstable_now=function(){return d.now()-f}}var p=[],m=[],h=1,g=null,_=3,v=!1,y=!1,b=!1,ee=!1,te=typeof setTimeout==`function`?setTimeout:null,ne=typeof clearTimeout==`function`?clearTimeout:null,re=typeof setImmediate<`u`?setImmediate:null,ie=!1,ae=-1,oe=5,x=-1;if(typeof re==`function`)var se=function(){re(t)};else if(typeof MessageChannel<`u`){var S=new MessageChannel,ce=S.port2;S.port1.onmessage=t,se=function(){ce.postMessage(null)}}else se=function(){te(t,0)};e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(e){e.callback=null},e.unstable_forceFrameRate=function(e){0>e||125<e?console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`):oe=0<e?Math.floor(1e3/e):5},e.unstable_getCurrentPriorityLevel=function(){return _},e.unstable_next=function(e){switch(_){case 1:case 2:case 3:var t=3;break;default:t=_}var n=_;_=t;try{return e()}finally{_=n}},e.unstable_requestPaint=function(){ee=!0},e.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=_;_=e;try{return t()}finally{_=n}},e.unstable_scheduleCallback=function(t,i,a){var o=e.unstable_now();switch(typeof a==`object`&&a?(a=a.delay,a=typeof a==`number`&&0<a?o+a:o):a=o,t){case 1:var c=-1;break;case 2:c=250;break;case 5:c=1073741823;break;case 4:c=1e4;break;default:c=5e3}return c=a+c,t={id:h++,callback:i,priorityLevel:t,startTime:a,expirationTime:c,sortIndex:-1},a>o?(t.sortIndex=a,n(m,t),r(p)===null&&t===r(m)&&(b?(ne(ae),ae=-1):b=!0,l(s,a-o))):(t.sortIndex=c,n(p,t),y||v||(y=!0,ie||(ie=!0,se()))),t},e.unstable_shouldYield=c,e.unstable_wrapCallback=function(e){var t=_;return function(){var n=_;_=t;try{return e.apply(this,arguments)}finally{_=n}}},typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop==`function`&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error())})()})),f=o(((e,t)=>{t.exports=d()})),p=o((e=>{(function(){function t(){}function n(e){return``+e}function r(e,t,r){var i=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;try{n(i);var a=!1}catch{a=!0}return a&&(console.error(`The provided key is an unsupported type %s. This value must be coerced to a string before using it here.`,typeof Symbol==`function`&&Symbol.toStringTag&&i[Symbol.toStringTag]||i.constructor.name||`Object`),n(i)),{$$typeof:d,key:i==null?null:``+i,children:e,containerInfo:t,implementation:r}}function i(e,t){if(e===`font`)return``;if(typeof t==`string`)return t===`use-credentials`?t:``}function a(e){return e===null?"`null`":e===void 0?"`undefined`":e===``?`an empty string`:`something with type "`+typeof e+`"`}function o(e){return e===null?"`null`":e===void 0?"`undefined`":e===``?`an empty string`:typeof e==`string`?JSON.stringify(e):typeof e==`number`?"`"+e+"`":`something with type "`+typeof e+`"`}function s(){var e=f.H;return e===null&&console.error(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.`),e}typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart==`function`&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());var c=u(),l={d:{f:t,r:function(){throw Error(`Invalid form element. requestFormReset must be passed a form that was rendered by React.`)},D:t,C:t,L:t,m:t,X:t,S:t,M:t},p:0,findDOMNode:null},d=Symbol.for(`react.portal`),f=c.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;typeof Map==`function`&&Map.prototype!=null&&typeof Map.prototype.forEach==`function`&&typeof Set==`function`&&Set.prototype!=null&&typeof Set.prototype.clear==`function`&&typeof Set.prototype.forEach==`function`||console.error(`React depends on Map and Set built-in types. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills`),e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=l,e.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(`Target container is not a DOM element.`);return r(e,t,null,n)},e.flushSync=function(e){var t=f.T,n=l.p;try{if(f.T=null,l.p=2,e)return e()}finally{f.T=t,l.p=n,l.d.f()&&console.error(`flushSync was called from inside a lifecycle method. React cannot flush when React is already rendering. Consider moving this call to a scheduler task or micro task.`)}},e.preconnect=function(e,t){typeof e==`string`&&e?t!=null&&typeof t!=`object`?console.error("ReactDOM.preconnect(): Expected the `options` argument (second) to be an object but encountered %s instead. The only supported option at this time is `crossOrigin` which accepts a string.",o(t)):t!=null&&typeof t.crossOrigin!=`string`&&console.error("ReactDOM.preconnect(): Expected the `crossOrigin` option (second argument) to be a string but encountered %s instead. Try removing this option or passing a string value instead.",a(t.crossOrigin)):console.error("ReactDOM.preconnect(): Expected the `href` argument (first) to be a non-empty string but encountered %s instead.",a(e)),typeof e==`string`&&(t?(t=t.crossOrigin,t=typeof t==`string`?t===`use-credentials`?t:``:void 0):t=null,l.d.C(e,t))},e.prefetchDNS=function(e){if(typeof e!=`string`||!e)console.error("ReactDOM.prefetchDNS(): Expected the `href` argument (first) to be a non-empty string but encountered %s instead.",a(e));else if(1<arguments.length){var t=arguments[1];typeof t==`object`&&t.hasOwnProperty(`crossOrigin`)?console.error("ReactDOM.prefetchDNS(): Expected only one argument, `href`, but encountered %s as a second argument instead. This argument is reserved for future options and is currently disallowed. It looks like the you are attempting to set a crossOrigin property for this DNS lookup hint. Browsers do not perform DNS queries using CORS and setting this attribute on the resource hint has no effect. Try calling ReactDOM.prefetchDNS() with just a single string argument, `href`.",o(t)):console.error("ReactDOM.prefetchDNS(): Expected only one argument, `href`, but encountered %s as a second argument instead. This argument is reserved for future options and is currently disallowed. Try calling ReactDOM.prefetchDNS() with just a single string argument, `href`.",o(t))}typeof e==`string`&&l.d.D(e)},e.preinit=function(e,t){if(typeof e==`string`&&e?typeof t!=`object`||!t?console.error("ReactDOM.preinit(): Expected the `options` argument (second) to be an object with an `as` property describing the type of resource to be preinitialized but encountered %s instead.",o(t)):t.as!==`style`&&t.as!==`script`&&console.error('ReactDOM.preinit(): Expected the `as` property in the `options` argument (second) to contain a valid value describing the type of resource to be preinitialized but encountered %s instead. Valid values for `as` are "style" and "script".',o(t.as)):console.error("ReactDOM.preinit(): Expected the `href` argument (first) to be a non-empty string but encountered %s instead.",a(e)),typeof e==`string`&&t&&typeof t.as==`string`){var n=t.as,r=i(n,t.crossOrigin),s=typeof t.integrity==`string`?t.integrity:void 0,c=typeof t.fetchPriority==`string`?t.fetchPriority:void 0;n===`style`?l.d.S(e,typeof t.precedence==`string`?t.precedence:void 0,{crossOrigin:r,integrity:s,fetchPriority:c}):n===`script`&&l.d.X(e,{crossOrigin:r,integrity:s,fetchPriority:c,nonce:typeof t.nonce==`string`?t.nonce:void 0})}},e.preinitModule=function(e,t){var n=``;if(typeof e==`string`&&e||(n+=" The `href` argument encountered was "+a(e)+`.`),t!==void 0&&typeof t!=`object`?n+=" The `options` argument encountered was "+a(t)+`.`:t&&`as`in t&&t.as!==`script`&&(n+=" The `as` option encountered was "+o(t.as)+`.`),n)console.error("ReactDOM.preinitModule(): Expected up to two arguments, a non-empty `href` string and, optionally, an `options` object with a valid `as` property.%s",n);else switch(n=t&&typeof t.as==`string`?t.as:`script`,n){case`script`:break;default:n=o(n),console.error('ReactDOM.preinitModule(): Currently the only supported "as" type for this function is "script" but received "%s" instead. This warning was generated for `href` "%s". In the future other module types will be supported, aligning with the import-attributes proposal. Learn more here: (https://github.com/tc39/proposal-import-attributes)',n,e)}typeof e==`string`&&(typeof t==`object`&&t?(t.as==null||t.as===`script`)&&(n=i(t.as,t.crossOrigin),l.d.M(e,{crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0})):t??l.d.M(e))},e.preload=function(e,t){var n=``;if(typeof e==`string`&&e||(n+=" The `href` argument encountered was "+a(e)+`.`),typeof t!=`object`||!t?n+=" The `options` argument encountered was "+a(t)+`.`:typeof t.as==`string`&&t.as||(n+=" The `as` option encountered was "+a(t.as)+`.`),n&&console.error('ReactDOM.preload(): Expected two arguments, a non-empty `href` string and an `options` object with an `as` property valid for a `<link rel="preload" as="..." />` tag.%s',n),typeof e==`string`&&typeof t==`object`&&t&&typeof t.as==`string`){n=t.as;var r=i(n,t.crossOrigin);l.d.L(e,n,{crossOrigin:r,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,type:typeof t.type==`string`?t.type:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy==`string`?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet==`string`?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes==`string`?t.imageSizes:void 0,media:typeof t.media==`string`?t.media:void 0})}},e.preloadModule=function(e,t){var n=``;typeof e==`string`&&e||(n+=" The `href` argument encountered was "+a(e)+`.`),t!==void 0&&typeof t!=`object`?n+=" The `options` argument encountered was "+a(t)+`.`:t&&`as`in t&&typeof t.as!=`string`&&(n+=" The `as` option encountered was "+a(t.as)+`.`),n&&console.error('ReactDOM.preloadModule(): Expected two arguments, a non-empty `href` string and, optionally, an `options` object with an `as` property valid for a `<link rel="modulepreload" as="..." />` tag.%s',n),typeof e==`string`&&(t?(n=i(t.as,t.crossOrigin),l.d.m(e,{as:typeof t.as==`string`&&t.as!==`script`?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0})):l.d.m(e))},e.requestFormReset=function(e){l.d.r(e)},e.unstable_batchedUpdates=function(e,t){return e(t)},e.useFormState=function(e,t,n){return s().useFormState(e,t,n)},e.useFormStatus=function(){return s().useHostTransitionStatus()},e.version=`19.2.4`,typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop==`function`&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error())})()})),m=o(((e,t)=>{t.exports=p()})),h=o((e=>{(function(){function t(e,t){for(e=e.memoizedState;e!==null&&0<t;)e=e.next,t--;return e}function n(e,t,r,i){if(r>=t.length)return i;var a=t[r],o=$f(e)?e.slice():P({},e);return o[a]=n(e[a],t,r+1,i),o}function r(e,t,n){if(t.length!==n.length)console.warn(`copyWithRename() expects paths of the same length`);else{for(var r=0;r<n.length-1;r++)if(t[r]!==n[r]){console.warn(`copyWithRename() expects paths to be the same except for the deepest key`);return}return i(e,t,n,0)}}function i(e,t,n,r){var a=t[r],o=$f(e)?e.slice():P({},e);return r+1===t.length?(o[n[r]]=o[a],$f(o)?o.splice(a,1):delete o[a]):o[a]=i(e[a],t,n,r+1),o}function a(e,t,n){var r=t[n],i=$f(e)?e.slice():P({},e);return n+1===t.length?($f(i)?i.splice(r,1):delete i[r],i):(i[r]=a(e[r],t,n+1),i)}function o(){return!1}function s(){return null}function c(){console.error(`Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://react.dev/link/rules-of-hooks`)}function l(){console.error(`Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().`)}function d(){}function p(){}function h(e){var t=[];return e.forEach(function(e){t.push(e)}),t.sort().join(`, `)}function g(e,t,n,r){return new Tr(e,t,n,r)}function _(e,t){e.context===Rg&&(sf(e.current,2,t,e,null,null),pl())}function v(e,t){if(zg!==null){var n=t.staleFamilies;t=t.updatedFamilies,zl(),wr(e.current,t,n),pl()}}function y(e){zg=e}function b(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function ee(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function te(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function ne(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function re(e){if(ee(e)!==e)throw Error(`Unable to find node on an unmounted component.`)}function ie(e){var t=e.alternate;if(!t){if(t=ee(e),t===null)throw Error(`Unable to find node on an unmounted component.`);return t===e?e:null}for(var n=e,r=t;;){var i=n.return;if(i===null)break;var a=i.alternate;if(a===null){if(r=i.return,r!==null){n=r;continue}break}if(i.child===a.child){for(a=i.child;a;){if(a===n)return re(i),e;if(a===r)return re(i),t;a=a.sibling}throw Error(`Unable to find node on an unmounted component.`)}if(n.return!==r.return)n=i,r=a;else{for(var o=!1,s=i.child;s;){if(s===n){o=!0,n=i,r=a;break}if(s===r){o=!0,r=i,n=a;break}s=s.sibling}if(!o){for(s=a.child;s;){if(s===n){o=!0,n=a,r=i;break}if(s===r){o=!0,r=a,n=i;break}s=s.sibling}if(!o)throw Error(`Child was not found in either parent set. This indicates a bug in React related to the return pointer. Please file an issue.`)}}if(n.alternate!==r)throw Error(`Return fibers should always be each others' alternates. This error is likely caused by a bug in React. Please file an issue.`)}if(n.tag!==3)throw Error(`Unable to find node on an unmounted component.`);return n.stateNode.current===n?e:t}function ae(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=ae(e),t!==null)return t;e=e.sibling}return null}function oe(e){return typeof e!=`object`||!e?null:(e=Zf&&e[Zf]||e[`@@iterator`],typeof e==`function`?e:null)}function x(e){if(e==null)return null;if(typeof e==`function`)return e.$$typeof===Qf?null:e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case zf:return`Fragment`;case Vf:return`Profiler`;case Bf:return`StrictMode`;case Gf:return`Suspense`;case Kf:return`SuspenseList`;case Yf:return`Activity`}if(typeof e==`object`)switch(typeof e.tag==`number`&&console.error(`Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue.`),e.$$typeof){case Rf:return`Portal`;case Uf:return e.displayName||`Context`;case Hf:return(e._context.displayName||`Context`)+`.Consumer`;case Wf:var t=e.render;return e=e.displayName,e||=(e=t.displayName||t.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case qf:return t=e.displayName||null,t===null?x(e.type)||`Memo`:t;case Jf:t=e._payload,e=e._init;try{return x(e(t))}catch{}}return null}function se(e){return typeof e.tag==`number`?S(e):typeof e.name==`string`?e.name:null}function S(e){var t=e.type;switch(e.tag){case 31:return`Activity`;case 24:return`Cache`;case 9:return(t._context.displayName||`Context`)+`.Consumer`;case 10:return t.displayName||`Context`;case 18:return`DehydratedFragment`;case 11:return e=t.render,e=e.displayName||e.name||``,t.displayName||(e===``?`ForwardRef`:`ForwardRef(`+e+`)`);case 7:return`Fragment`;case 26:case 27:case 5:return t;case 4:return`Portal`;case 3:return`Root`;case 6:return`Text`;case 16:return x(t);case 8:return t===Bf?`StrictMode`:`Mode`;case 22:return`Offscreen`;case 12:return`Profiler`;case 21:return`Scope`;case 13:return`Suspense`;case 19:return`SuspenseList`;case 25:return`TracingMarker`;case 1:case 0:case 14:case 15:if(typeof t==`function`)return t.displayName||t.name||null;if(typeof t==`string`)return t;break;case 29:if(t=e._debugInfo,t!=null){for(var n=t.length-1;0<=n;n--)if(typeof t[n].name==`string`)return t[n].name}if(e.return!==null)return S(e.return)}return null}function ce(e){return{current:e}}function le(e,t){0>rp?console.error(`Unexpected pop.`):(t!==np[rp]&&console.error(`Unexpected Fiber popped.`),e.current=tp[rp],tp[rp]=null,np[rp]=null,rp--)}function C(e,t,n){rp++,tp[rp]=e.current,np[rp]=n,e.current=t}function ue(e){return e===null&&console.error(`Expected host context to exist. This error is likely caused by a bug in React. Please file an issue.`),e}function de(e,t){C(op,t,e),C(ap,e,e),C(ip,null,e);var n=t.nodeType;switch(n){case 9:case 11:n=n===9?`#document`:`#fragment`,t=(t=t.documentElement)&&(t=t.namespaceURI)?Ku(t):WS;break;default:if(n=t.tagName,t=t.namespaceURI)t=Ku(t),t=qu(t,n);else switch(n){case`svg`:t=GS;break;case`math`:t=KS;break;default:t=WS}}n=n.toLowerCase(),n=qt(null,n),n={context:t,ancestorInfo:n},le(ip,e),C(ip,n,e)}function fe(e){le(ip,e),le(ap,e),le(op,e)}function pe(){return ue(ip.current)}function me(e){e.memoizedState!==null&&C(sp,e,e);var t=ue(ip.current),n=e.type,r=qu(t.context,n);n=qt(t.ancestorInfo,n),r={context:r,ancestorInfo:n},t!==r&&(C(ap,e,e),C(ip,r,e))}function he(e){ap.current===e&&(le(ip,e),le(ap,e)),sp.current===e&&(le(sp,e),xC._currentValue=bC)}function ge(){}function _e(){if(cp===0){lp=console.log,up=console.info,dp=console.warn,fp=console.error,pp=console.group,mp=console.groupCollapsed,hp=console.groupEnd;var e={configurable:!0,enumerable:!0,value:ge,writable:!0};Object.defineProperties(console,{info:e,log:e,warn:e,error:e,group:e,groupCollapsed:e,groupEnd:e})}cp++}function ve(){if(cp--,cp===0){var e={configurable:!0,enumerable:!0,writable:!0};Object.defineProperties(console,{log:P({},e,{value:lp}),info:P({},e,{value:up}),warn:P({},e,{value:dp}),error:P({},e,{value:fp}),group:P({},e,{value:pp}),groupCollapsed:P({},e,{value:mp}),groupEnd:P({},e,{value:hp})})}0>cp&&console.error(`disabledDepth fell below zero. This is a bug in React. Please file an issue.`)}function ye(e){var t=Error.prepareStackTrace;if(Error.prepareStackTrace=void 0,e=e.stack,Error.prepareStackTrace=t,e.startsWith(`Error: react-stack-top-frame
`)&&(e=e.slice(29)),t=e.indexOf(`
`),t!==-1&&(e=e.slice(t+1)),t=e.indexOf(`react_stack_bottom_frame`),t!==-1&&(t=e.lastIndexOf(`
`,t)),t!==-1)e=e.slice(0,t);else return``;return e}function be(e){if(gp===void 0)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);gp=t&&t[1]||``,_p=-1<e.stack.indexOf(`
    at`)?` (<anonymous>)`:-1<e.stack.indexOf(`@`)?`@unknown:0:0`:``}return`
`+gp+e+_p}function xe(e,t){if(!e||vp)return``;var n=yp.get(e);if(n!==void 0)return n;vp=!0,n=Error.prepareStackTrace,Error.prepareStackTrace=void 0;var r=null;r=F.H,F.H=null,_e();try{var i={DetermineComponentFrameRoot:function(){try{if(t){var n=function(){throw Error()};if(Object.defineProperty(n.prototype,`props`,{set:function(){throw Error()}}),typeof Reflect==`object`&&Reflect.construct){try{Reflect.construct(n,[])}catch(e){var r=e}Reflect.construct(e,[],n)}else{try{n.call()}catch(e){r=e}e.call(n.prototype)}}else{try{throw Error()}catch(e){r=e}(n=e())&&typeof n.catch==`function`&&n.catch(function(){})}}catch(e){if(e&&r&&typeof e.stack==`string`)return[e.stack,r.stack]}return[null,null]}};i.DetermineComponentFrameRoot.displayName=`DetermineComponentFrameRoot`;var a=Object.getOwnPropertyDescriptor(i.DetermineComponentFrameRoot,`name`);a&&a.configurable&&Object.defineProperty(i.DetermineComponentFrameRoot,`name`,{value:`DetermineComponentFrameRoot`});var o=i.DetermineComponentFrameRoot(),s=o[0],c=o[1];if(s&&c){var l=s.split(`
`),u=c.split(`
`);for(o=a=0;a<l.length&&!l[a].includes(`DetermineComponentFrameRoot`);)a++;for(;o<u.length&&!u[o].includes(`DetermineComponentFrameRoot`);)o++;if(a===l.length||o===u.length)for(a=l.length-1,o=u.length-1;1<=a&&0<=o&&l[a]!==u[o];)o--;for(;1<=a&&0<=o;a--,o--)if(l[a]!==u[o]){if(a!==1||o!==1)do if(a--,o--,0>o||l[a]!==u[o]){var d=`
`+l[a].replace(` at new `,` at `);return e.displayName&&d.includes(`<anonymous>`)&&(d=d.replace(`<anonymous>`,e.displayName)),typeof e==`function`&&yp.set(e,d),d}while(1<=a&&0<=o);break}}}finally{vp=!1,F.H=r,ve(),Error.prepareStackTrace=n}return l=(l=e?e.displayName||e.name:``)?be(l):``,typeof e==`function`&&yp.set(e,l),l}function Se(e,t){switch(e.tag){case 26:case 27:case 5:return be(e.type);case 16:return be(`Lazy`);case 13:return e.child!==t&&t!==null?be(`Suspense Fallback`):be(`Suspense`);case 19:return be(`SuspenseList`);case 0:case 15:return xe(e.type,!1);case 11:return xe(e.type.render,!1);case 1:return xe(e.type,!0);case 31:return be(`Activity`);default:return``}}function Ce(e){try{var t=``,n=null;do{t+=Se(e,n);var r=e._debugInfo;if(r)for(var i=r.length-1;0<=i;i--){var a=r[i];if(typeof a.name==`string`){var o=t;a:{var s=a.name,c=a.env,l=a.debugLocation;if(l!=null){var u=ye(l),d=u.lastIndexOf(`
`),f=d===-1?u:u.slice(d+1);if(f.indexOf(s)!==-1){var p=`
`+f;break a}}p=be(s+(c?` [`+c+`]`:``))}t=o+p}}n=e,e=e.return}while(e);return t}catch(e){return`
Error generating stack: `+e.message+`
`+e.stack}}function we(e){return(e=e?e.displayName||e.name:``)?be(e):``}function Te(){if(bp===null)return null;var e=bp._debugOwner;return e==null?null:se(e)}function Ee(){if(bp===null)return``;var e=bp;try{var t=``;switch(e.tag===6&&(e=e.return),e.tag){case 26:case 27:case 5:t+=be(e.type);break;case 13:t+=be(`Suspense`);break;case 19:t+=be(`SuspenseList`);break;case 31:t+=be(`Activity`);break;case 30:case 0:case 15:case 1:e._debugOwner||t!==``||(t+=we(e.type));break;case 11:e._debugOwner||t!==``||(t+=we(e.type.render))}for(;e;)if(typeof e.tag==`number`){var n=e;e=n._debugOwner;var r=n._debugStack;if(e&&r){var i=ye(r);i!==``&&(t+=`
`+i)}}else if(e.debugStack!=null){var a=e.debugStack;(e=e.owner)&&a&&(t+=`
`+ye(a))}else break;var o=t}catch(e){o=`
Error generating stack: `+e.message+`
`+e.stack}return o}function w(e,t,n,r,i,a,o){var s=bp;De(e);try{return e!==null&&e._debugTask?e._debugTask.run(t.bind(null,n,r,i,a,o)):t(n,r,i,a,o)}finally{De(s)}throw Error(`runWithFiberInDEV should never be called in production. This is a bug in React.`)}function De(e){F.getCurrentStack=e===null?null:Ee,xp=!1,bp=e}function Oe(e){return typeof Symbol==`function`&&Symbol.toStringTag&&e[Symbol.toStringTag]||e.constructor.name||`Object`}function ke(e){try{return Ae(e),!1}catch{return!0}}function Ae(e){return``+e}function T(e,t){if(ke(e))return console.error("The provided `%s` attribute is an unsupported type %s. This value must be coerced to a string before using it here.",t,Oe(e)),Ae(e)}function je(e,t){if(ke(e))return console.error("The provided `%s` CSS property is an unsupported type %s. This value must be coerced to a string before using it here.",t,Oe(e)),Ae(e)}function Me(e){if(ke(e))return console.error(`Form field values (value, checked, defaultValue, or defaultChecked props) must be strings, not %s. This value must be coerced to a string before using it here.`,Oe(e)),Ae(e)}function Ne(e){if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>`u`)return!1;var t=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(t.isDisabled)return!0;if(!t.supportsFiber)return console.error(`The installed version of React DevTools is too old and will not work with the current version of React. Please update React DevTools. https://react.dev/link/react-devtools`),!0;try{Ip=t.inject(e),Lp=t}catch(e){console.error(`React instrumentation encountered an error: %o.`,e)}return!!t.checkDCE}function E(e){if(typeof Pp==`function`&&Fp(e),Lp&&typeof Lp.setStrictMode==`function`)try{Lp.setStrictMode(Ip,e)}catch(e){Rp||(Rp=!0,console.error(`React instrumentation encountered an error: %o`,e))}}function Pe(e){return e>>>=0,e===0?32:31-(Vp(e)/Hp|0)|0}function Fe(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return console.error(`Should have found matching lanes. This is a bug in React.`),e}}function Ie(e,t,n){var r=e.pendingLanes;if(r===0)return 0;var i=0,a=e.suspendedLanes,o=e.pingedLanes;e=e.warmLanes;var s=r&134217727;return s===0?(s=r&~a,s===0?o===0?n||(n=r&~e,n!==0&&(i=Fe(n))):i=Fe(o):i=Fe(s)):(r=s&~a,r===0?(o&=s,o===0?n||(n=s&~e,n!==0&&(i=Fe(n))):i=Fe(o)):i=Fe(r)),i===0?0:t!==0&&t!==i&&(t&a)===0&&(a=i&-i,n=t&-t,a>=n||a===32&&n&4194048)?t:i}function Le(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Re(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return console.error(`Should have found matching lanes. This is a bug in React.`),-1}}function ze(){var e=Gp;return Gp<<=1,!(Gp&62914560)&&(Gp=4194304),e}function Be(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Ve(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function He(e,t,n,r,i,a){var o=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var s=e.entanglements,c=e.expirationTimes,l=e.hiddenUpdates;for(n=o&~n;0<n;){var u=31-Bp(n),d=1<<u;s[u]=0,c[u]=-1;var f=l[u];if(f!==null)for(l[u]=null,u=0;u<f.length;u++){var p=f[u];p!==null&&(p.lane&=-536870913)}n&=~d}r!==0&&Ue(e,r,0),a!==0&&i===0&&e.tag!==0&&(e.suspendedLanes|=a&~(o&~t))}function Ue(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var r=31-Bp(t);e.entangledLanes|=t,e.entanglements[r]=e.entanglements[r]|1073741824|n&261930}function We(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-Bp(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}function Ge(e,t){var n=t&-t;return n=n&42?1:Ke(n),(n&(e.suspendedLanes|t))===0?n:0}function Ke(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function qe(e,t,n){if(zp)for(e=e.pendingUpdatersLaneMap;0<n;){var r=31-Bp(n),i=1<<r;e[r].add(t),n&=~i}}function Je(e,t){if(zp)for(var n=e.pendingUpdatersLaneMap,r=e.memoizedUpdaters;0<t;){var i=31-Bp(t);e=1<<i,i=n[i],0<i.size&&(i.forEach(function(e){var t=e.alternate;t!==null&&r.has(t)||r.add(e)}),i.clear()),t&=~e}}function Ye(e){return e&=-e,Kp!==0&&Kp<e?qp!==0&&qp<e?e&134217727?Jp:Yp:qp:Kp}function Xe(){var e=I.p;return e===0?(e=window.event,e===void 0?Jp:vf(e.type)):e}function Ze(e,t){var n=I.p;try{return I.p=e,t()}finally{I.p=n}}function Qe(e){delete e[Zp],delete e[Qp],delete e[em],delete e[tm],delete e[nm]}function $e(e){var t=e[Zp];if(t)return t;for(var n=e.parentNode;n;){if(t=n[$p]||n[Zp]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=Dd(e);e!==null;){if(n=e[Zp])return n;e=Dd(e)}return t}e=n,n=e.parentNode}return null}function et(e){if(e=e[Zp]||e[$p]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function tt(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(`getNodeFromInstance: Invalid argument.`)}function nt(e){var t=e[rm];return t||=e[rm]={hoistableStyles:new Map,hoistableScripts:new Map},t}function rt(e){e[im]=!0}function it(e,t){at(e,t),at(e+`Capture`,t)}function at(e,t){om[e]&&console.error("EventRegistry: More than one plugin attempted to publish the same registration name, `%s`.",e),om[e]=t;var n=e.toLowerCase();for(sm[n]=e,e===`onDoubleClick`&&(sm.ondblclick=e),e=0;e<t.length;e++)am.add(t[e])}function ot(e,t){cm[t.type]||t.onChange||t.onInput||t.readOnly||t.disabled||t.value==null||console.error(e===`select`?"You provided a `value` prop to a form field without an `onChange` handler. This will render a read-only field. If the field should be mutable use `defaultValue`. Otherwise, set `onChange`.":"You provided a `value` prop to a form field without an `onChange` handler. This will render a read-only field. If the field should be mutable use `defaultValue`. Otherwise, set either `onChange` or `readOnly`."),t.onChange||t.readOnly||t.disabled||t.checked==null||console.error("You provided a `checked` prop to a form field without an `onChange` handler. This will render a read-only field. If the field should be mutable use `defaultChecked`. Otherwise, set either `onChange` or `readOnly`.")}function st(e){return Sp.call(dm,e)?!0:Sp.call(um,e)?!1:lm.test(e)?dm[e]=!0:(um[e]=!0,console.error("Invalid attribute name: `%s`",e),!1)}function ct(e,t,n){if(st(t)){if(!e.hasAttribute(t)){switch(typeof n){case`symbol`:case`object`:return n;case`function`:return n;case`boolean`:if(!1===n)return n}return n===void 0?void 0:null}return e=e.getAttribute(t),e===``&&!0===n?!0:(T(n,t),e===``+n?n:e)}}function lt(e,t,n){if(st(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case`undefined`:case`function`:case`symbol`:e.removeAttribute(t);return;case`boolean`:var r=t.toLowerCase().slice(0,5);if(r!==`data-`&&r!==`aria-`){e.removeAttribute(t);return}}T(n,t),e.setAttribute(t,``+n)}}function ut(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case`undefined`:case`function`:case`symbol`:case`boolean`:e.removeAttribute(t);return}T(n,t),e.setAttribute(t,``+n)}}function dt(e,t,n,r){if(r===null)e.removeAttribute(n);else{switch(typeof r){case`undefined`:case`function`:case`symbol`:case`boolean`:e.removeAttribute(n);return}T(r,n),e.setAttributeNS(t,n,``+r)}}function ft(e){switch(typeof e){case`bigint`:case`boolean`:case`number`:case`string`:case`undefined`:return e;case`object`:return Me(e),e;default:return``}}function pt(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()===`input`&&(t===`checkbox`||t===`radio`)}function mt(e,t,n){var r=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&r!==void 0&&typeof r.get==`function`&&typeof r.set==`function`){var i=r.get,a=r.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(e){Me(e),n=``+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:r.enumerable}),{getValue:function(){return n},setValue:function(e){Me(e),n=``+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function ht(e){if(!e._valueTracker){var t=pt(e)?`checked`:`value`;e._valueTracker=mt(e,t,``+e[t])}}function gt(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r=``;return e&&(r=pt(e)?e.checked?`true`:`false`:e.value),e=r,e===n?!1:(t.setValue(e),!0)}function _t(e){if(e||=typeof document<`u`?document:void 0,e===void 0)return null;try{return e.activeElement||e.body}catch{return e.body}}function vt(e){return e.replace(fm,function(e){return`\\`+e.charCodeAt(0).toString(16)+` `})}function yt(e,t){t.checked===void 0||t.defaultChecked===void 0||mm||(console.error(`%s contains an input of type %s with both checked and defaultChecked props. Input elements must be either controlled or uncontrolled (specify either the checked prop, or the defaultChecked prop, but not both). Decide between using a controlled or uncontrolled input element and remove one of these props. More info: https://react.dev/link/controlled-components`,Te()||`A component`,t.type),mm=!0),t.value===void 0||t.defaultValue===void 0||pm||(console.error(`%s contains an input of type %s with both value and defaultValue props. Input elements must be either controlled or uncontrolled (specify either the value prop, or the defaultValue prop, but not both). Decide between using a controlled or uncontrolled input element and remove one of these props. More info: https://react.dev/link/controlled-components`,Te()||`A component`,t.type),pm=!0)}function bt(e,t,n,r,i,a,o,s){e.name=``,o!=null&&typeof o!=`function`&&typeof o!=`symbol`&&typeof o!=`boolean`?(T(o,`type`),e.type=o):e.removeAttribute(`type`),t==null?o!==`submit`&&o!==`reset`||e.removeAttribute(`value`):o===`number`?(t===0&&e.value===``||e.value!=t)&&(e.value=``+ft(t)):e.value!==``+ft(t)&&(e.value=``+ft(t)),t==null?n==null?r!=null&&e.removeAttribute(`value`):St(e,o,ft(n)):St(e,o,ft(t)),i==null&&a!=null&&(e.defaultChecked=!!a),i!=null&&(e.checked=i&&typeof i!=`function`&&typeof i!=`symbol`),s!=null&&typeof s!=`function`&&typeof s!=`symbol`&&typeof s!=`boolean`?(T(s,`name`),e.name=``+ft(s)):e.removeAttribute(`name`)}function xt(e,t,n,r,i,a,o,s){if(a!=null&&typeof a!=`function`&&typeof a!=`symbol`&&typeof a!=`boolean`&&(T(a,`type`),e.type=a),t!=null||n!=null){if(!(a!==`submit`&&a!==`reset`||t!=null)){ht(e);return}n=n==null?``:``+ft(n),t=t==null?n:``+ft(t),s||t===e.value||(e.value=t),e.defaultValue=t}r??=i,r=typeof r!=`function`&&typeof r!=`symbol`&&!!r,e.checked=s?e.checked:!!r,e.defaultChecked=!!r,o!=null&&typeof o!=`function`&&typeof o!=`symbol`&&typeof o!=`boolean`&&(T(o,`name`),e.name=o),ht(e)}function St(e,t,n){t===`number`&&_t(e.ownerDocument)===e||e.defaultValue===``+n||(e.defaultValue=``+n)}function Ct(e,t){t.value??(typeof t.children==`object`&&t.children!==null?Pf.Children.forEach(t.children,function(e){e==null||typeof e==`string`||typeof e==`number`||typeof e==`bigint`||gm||(gm=!0,console.error("Cannot infer the option value of complex children. Pass a `value` prop or use a plain string as children to <option>."))}):t.dangerouslySetInnerHTML==null||_m||(_m=!0,console.error("Pass a `value` prop if you set dangerouslyInnerHTML so React knows which value should be selected."))),t.selected==null||hm||(console.error("Use the `defaultValue` or `value` props on <select> instead of setting `selected` on <option>."),hm=!0)}function wt(){var e=Te();return e?`

Check the render method of \``+e+"`.":``}function Tt(e,t,n,r){if(e=e.options,t){t={};for(var i=0;i<n.length;i++)t[`$`+n[i]]=!0;for(n=0;n<e.length;n++)i=t.hasOwnProperty(`$`+e[n].value),e[n].selected!==i&&(e[n].selected=i),i&&r&&(e[n].defaultSelected=!0)}else{for(n=``+ft(n),t=null,i=0;i<e.length;i++){if(e[i].value===n){e[i].selected=!0,r&&(e[i].defaultSelected=!0);return}t!==null||e[i].disabled||(t=e[i])}t!==null&&(t.selected=!0)}}function Et(e,t){for(e=0;e<ym.length;e++){var n=ym[e];if(t[n]!=null){var r=$f(t[n]);t.multiple&&!r?console.error("The `%s` prop supplied to <select> must be an array if `multiple` is true.%s",n,wt()):!t.multiple&&r&&console.error("The `%s` prop supplied to <select> must be a scalar value if `multiple` is false.%s",n,wt())}}t.value===void 0||t.defaultValue===void 0||vm||(console.error(`Select elements must be either controlled or uncontrolled (specify either the value prop, or the defaultValue prop, but not both). Decide between using a controlled or uncontrolled select element and remove one of these props. More info: https://react.dev/link/controlled-components`),vm=!0)}function Dt(e,t){t.value===void 0||t.defaultValue===void 0||bm||(console.error(`%s contains a textarea with both value and defaultValue props. Textarea elements must be either controlled or uncontrolled (specify either the value prop, or the defaultValue prop, but not both). Decide between using a controlled or uncontrolled textarea and remove one of these props. More info: https://react.dev/link/controlled-components`,Te()||`A component`),bm=!0),t.children!=null&&t.value==null&&console.error("Use the `defaultValue` or `value` props instead of setting children on <textarea>.")}function Ot(e,t,n){if(t!=null&&(t=``+ft(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n==null?``:``+ft(n)}function kt(e,t,n,r){if(t==null){if(r!=null){if(n!=null)throw Error("If you supply `defaultValue` on a <textarea>, do not pass children.");if($f(r)){if(1<r.length)throw Error(`<textarea> can only have at most one child.`);r=r[0]}n=r}n??=``,t=n}n=ft(t),e.defaultValue=n,r=e.textContent,r===n&&r!==``&&r!==null&&(e.value=r),ht(e)}function At(e,t){return e.serverProps===void 0&&e.serverTail.length===0&&e.children.length===1&&3<e.distanceFromLeaf&&e.distanceFromLeaf>15-t?At(e.children[0],t):e}function jt(e){return`  `+`  `.repeat(e)}function Mt(e){return`+ `+`  `.repeat(e)}function Nt(e){return`- `+`  `.repeat(e)}function Pt(e){switch(e.tag){case 26:case 27:case 5:return e.type;case 16:return`Lazy`;case 31:return`Activity`;case 13:return`Suspense`;case 19:return`SuspenseList`;case 0:case 15:return e=e.type,e.displayName||e.name||null;case 11:return e=e.type.render,e.displayName||e.name||null;case 1:return e=e.type,e.displayName||e.name||null;default:return null}}function Ft(e,t){return xm.test(e)?(e=JSON.stringify(e),e.length>t-2?8>t?`{"..."}`:`{`+e.slice(0,t-7)+`..."}`:`{`+e+`}`):e.length>t?5>t?`{"..."}`:e.slice(0,t-3)+`...`:e}function It(e,t,n){var r=120-2*n;if(t===null)return Mt(n)+Ft(e,r)+`
`;if(typeof t==`string`){for(var i=0;i<t.length&&i<e.length&&t.charCodeAt(i)===e.charCodeAt(i);i++);return i>r-8&&10<i&&(e=`...`+e.slice(i-8),t=`...`+t.slice(i-8)),Mt(n)+Ft(e,r)+`
`+Nt(n)+Ft(t,r)+`
`}return jt(n)+Ft(e,r)+`
`}function Lt(e){return Object.prototype.toString.call(e).replace(/^\[object (.*)\]$/,function(e,t){return t})}function Rt(e,t){switch(typeof e){case`string`:return e=JSON.stringify(e),e.length>t?5>t?`"..."`:e.slice(0,t-4)+`..."`:e;case`object`:if(e===null)return`null`;if($f(e))return`[...]`;if(e.$$typeof===Lf)return(t=x(e.type))?`<`+t+`>`:`<...>`;var n=Lt(e);if(n===`Object`){for(var r in n=``,t-=2,e)if(e.hasOwnProperty(r)){var i=JSON.stringify(r);if(i!==`"`+r+`"`&&(r=i),t-=r.length-2,i=Rt(e[r],15>t?t:15),t-=i.length,0>t){n+=n===``?`...`:`, ...`;break}n+=(n===``?``:`,`)+r+`:`+i}return`{`+n+`}`}return n;case`function`:return(t=e.displayName||e.name)?`function `+t:`function`;default:return String(e)}}function zt(e,t){return typeof e!=`string`||xm.test(e)?`{`+Rt(e,t-2)+`}`:e.length>t-2?5>t?`"..."`:`"`+e.slice(0,t-5)+`..."`:`"`+e+`"`}function Bt(e,t,n){var r=120-n.length-e.length,i=[],a;for(a in t)if(t.hasOwnProperty(a)&&a!==`children`){var o=zt(t[a],120-n.length-a.length-1);r-=a.length+o.length+2,i.push(a+`=`+o)}return i.length===0?n+`<`+e+`>
`:0<r?n+`<`+e+` `+i.join(` `)+`>
`:n+`<`+e+`
`+n+`  `+i.join(`
`+n+`  `)+`
`+n+`>
`}function Vt(e,t,n){var r=``,i=P({},t),a;for(a in e)if(e.hasOwnProperty(a)){delete i[a];var o=120-2*n-a.length-2,s=Rt(e[a],o);t.hasOwnProperty(a)?(o=Rt(t[a],o),r+=Mt(n)+a+`: `+s+`
`,r+=Nt(n)+a+`: `+o+`
`):r+=Mt(n)+a+`: `+s+`
`}for(var c in i)i.hasOwnProperty(c)&&(e=Rt(i[c],120-2*n-c.length-2),r+=Nt(n)+c+`: `+e+`
`);return r}function Ht(e,t,n,r){var i=``,a=new Map;for(l in n)n.hasOwnProperty(l)&&a.set(l.toLowerCase(),l);if(a.size===1&&a.has(`children`))i+=Bt(e,t,jt(r));else{for(var o in t)if(t.hasOwnProperty(o)&&o!==`children`){var s=120-2*(r+1)-o.length-1,c=a.get(o.toLowerCase());if(c!==void 0){a.delete(o.toLowerCase());var l=t[o];c=n[c];var u=zt(l,s);s=zt(c,s),typeof l==`object`&&l&&typeof c==`object`&&c&&Lt(l)===`Object`&&Lt(c)===`Object`&&(2<Object.keys(l).length||2<Object.keys(c).length||-1<u.indexOf(`...`)||-1<s.indexOf(`...`))?i+=jt(r+1)+o+`={{
`+Vt(l,c,r+2)+jt(r+1)+`}}
`:(i+=Mt(r+1)+o+`=`+u+`
`,i+=Nt(r+1)+o+`=`+s+`
`)}else i+=jt(r+1)+o+`=`+zt(t[o],s)+`
`}a.forEach(function(e){if(e!==`children`){var t=120-2*(r+1)-e.length-1;i+=Nt(r+1)+e+`=`+zt(n[e],t)+`
`}}),i=i===``?jt(r)+`<`+e+`>
`:jt(r)+`<`+e+`
`+i+jt(r)+`>
`}return e=n.children,t=t.children,typeof e==`string`||typeof e==`number`||typeof e==`bigint`?(a=``,(typeof t==`string`||typeof t==`number`||typeof t==`bigint`)&&(a=``+t),i+=It(a,``+e,r+1)):(typeof t==`string`||typeof t==`number`||typeof t==`bigint`)&&(i=e==null?i+It(``+t,null,r+1):i+It(``+t,void 0,r+1)),i}function Ut(e,t){var n=Pt(e);if(n===null){for(n=``,e=e.child;e;)n+=Ut(e,t),e=e.sibling;return n}return jt(t)+`<`+n+`>
`}function Wt(e,t){var n=At(e,t);if(n!==e&&(e.children.length!==1||e.children[0]!==n))return jt(t)+`...
`+Wt(n,t+1);n=``;var r=e.fiber._debugInfo;if(r)for(var i=0;i<r.length;i++){var a=r[i].name;typeof a==`string`&&(n+=jt(t)+`<`+a+`>
`,t++)}if(r=``,i=e.fiber.pendingProps,e.fiber.tag===6)r=It(i,e.serverProps,t),t++;else if(a=Pt(e.fiber),a!==null)if(e.serverProps===void 0){r=t;var o=120-2*r-a.length-2,s=``;for(l in i)if(i.hasOwnProperty(l)&&l!==`children`){var c=zt(i[l],15);if(o-=l.length+c.length+2,0>o){s+=` ...`;break}s+=` `+l+`=`+c}r=jt(r)+`<`+a+s+`>
`,t++}else e.serverProps===null?(r=Bt(a,i,Mt(t)),t++):typeof e.serverProps==`string`?console.error(`Should not have matched a non HostText fiber to a Text node. This is a bug in React.`):(r=Ht(a,i,e.serverProps,t),t++);var l=``;for(i=e.fiber.child,a=0;i&&a<e.children.length;)o=e.children[a],o.fiber===i?(l+=Wt(o,t),a++):l+=Ut(i,t),i=i.sibling;for(i&&0<e.children.length&&(l+=jt(t)+`...
`),i=e.serverTail,e.serverProps===null&&t--,e=0;e<i.length;e++)a=i[e],l=typeof a==`string`?l+(Nt(t)+Ft(a,120-2*t)+`
`):l+Bt(a.type,a.props,Nt(t));return n+r+l}function Gt(e){try{return`

`+Wt(e,0)}catch{return``}}function Kt(e,t,n){for(var r=t,i=null,a=0;r;)r===e&&(a=0),i={fiber:r,children:i===null?[]:[i],serverProps:r===t?n:r===e?null:void 0,serverTail:[],distanceFromLeaf:a},a++,r=r.return;return i===null?``:Gt(i).replaceAll(/^[+-]/gm,`>`)}function qt(e,t){var n=P({},e||Em),r={tag:t};return Cm.indexOf(t)!==-1&&(n.aTagInScope=null,n.buttonTagInScope=null,n.nobrTagInScope=null),wm.indexOf(t)!==-1&&(n.pTagInButtonScope=null),Sm.indexOf(t)!==-1&&t!==`address`&&t!==`div`&&t!==`p`&&(n.listItemTagAutoclosing=null,n.dlItemTagAutoclosing=null),n.current=r,t===`form`&&(n.formTag=r),t===`a`&&(n.aTagInScope=r),t===`button`&&(n.buttonTagInScope=r),t===`nobr`&&(n.nobrTagInScope=r),t===`p`&&(n.pTagInButtonScope=r),t===`li`&&(n.listItemTagAutoclosing=r),(t===`dd`||t===`dt`)&&(n.dlItemTagAutoclosing=r),t===`#document`||t===`html`?n.containerTagInScope=null:n.containerTagInScope||=r,e!==null||t!==`#document`&&t!==`html`&&t!==`body`?!0===n.implicitRootScope&&(n.implicitRootScope=!1):n.implicitRootScope=!0,n}function Jt(e,t,n){switch(t){case`select`:return e===`hr`||e===`option`||e===`optgroup`||e===`script`||e===`template`||e===`#text`;case`optgroup`:return e===`option`||e===`#text`;case`option`:return e===`#text`;case`tr`:return e===`th`||e===`td`||e===`style`||e===`script`||e===`template`;case`tbody`:case`thead`:case`tfoot`:return e===`tr`||e===`style`||e===`script`||e===`template`;case`colgroup`:return e===`col`||e===`template`;case`table`:return e===`caption`||e===`colgroup`||e===`tbody`||e===`tfoot`||e===`thead`||e===`style`||e===`script`||e===`template`;case`head`:return e===`base`||e===`basefont`||e===`bgsound`||e===`link`||e===`meta`||e===`title`||e===`noscript`||e===`noframes`||e===`style`||e===`script`||e===`template`;case`html`:if(n)break;return e===`head`||e===`body`||e===`frameset`;case`frameset`:return e===`frame`;case`#document`:if(!n)return e===`html`}switch(e){case`h1`:case`h2`:case`h3`:case`h4`:case`h5`:case`h6`:return t!==`h1`&&t!==`h2`&&t!==`h3`&&t!==`h4`&&t!==`h5`&&t!==`h6`;case`rp`:case`rt`:return Tm.indexOf(t)===-1;case`caption`:case`col`:case`colgroup`:case`frameset`:case`frame`:case`tbody`:case`td`:case`tfoot`:case`th`:case`thead`:case`tr`:return t==null;case`head`:return n||t===null;case`html`:return n&&t===`#document`||t===null;case`body`:return n&&(t===`#document`||t===`html`)||t===null}return!0}function Yt(e,t){switch(e){case`address`:case`article`:case`aside`:case`blockquote`:case`center`:case`details`:case`dialog`:case`dir`:case`div`:case`dl`:case`fieldset`:case`figcaption`:case`figure`:case`footer`:case`header`:case`hgroup`:case`main`:case`menu`:case`nav`:case`ol`:case`p`:case`section`:case`summary`:case`ul`:case`pre`:case`listing`:case`table`:case`hr`:case`xmp`:case`h1`:case`h2`:case`h3`:case`h4`:case`h5`:case`h6`:return t.pTagInButtonScope;case`form`:return t.formTag||t.pTagInButtonScope;case`li`:return t.listItemTagAutoclosing;case`dd`:case`dt`:return t.dlItemTagAutoclosing;case`button`:return t.buttonTagInScope;case`a`:return t.aTagInScope;case`nobr`:return t.nobrTagInScope}return null}function Xt(e,t){for(;e;){switch(e.tag){case 5:case 26:case 27:if(e.type===t)return e}e=e.return}return null}function Zt(e,t){t||=Em;var n=t.current;if(t=(n=Jt(e,n&&n.tag,t.implicitRootScope)?null:n)?null:Yt(e,t),t=n||t,!t)return!0;var r=t.tag;if(t=String(!!n)+`|`+e+`|`+r,Dm[t])return!1;Dm[t]=!0;var i=(t=bp)?Xt(t.return,r):null,a=t!==null&&i!==null?Kt(i,t,null):``,o=`<`+e+`>`;return n?(n=``,r===`table`&&e===`tr`&&(n+=` Add a <tbody>, <thead> or <tfoot> to your code to match the DOM tree generated by the browser.`),console.error(`In HTML, %s cannot be a child of <%s>.%s
This will cause a hydration error.%s`,o,r,n,a)):console.error(`In HTML, %s cannot be a descendant of <%s>.
This will cause a hydration error.%s`,o,r,a),t&&(e=t.return,i===null||e===null||i===e&&e._debugOwner===t._debugOwner||w(i,function(){console.error(`<%s> cannot contain a nested %s.
See this log for the ancestor stack trace.`,r,o)})),!1}function Qt(e,t,n){if(n||Jt(`#text`,t,!1))return!0;if(n=`#text|`+t,Dm[n])return!1;Dm[n]=!0;var r=(n=bp)?Xt(n,t):null;return n=n!==null&&r!==null?Kt(r,n,n.tag===6?null:{children:null}):``,/\S/.test(e)?console.error(`In HTML, text nodes cannot be a child of <%s>.
This will cause a hydration error.%s`,t,n):console.error(`In HTML, whitespace text nodes cannot be a child of <%s>. Make sure you don't have any extra whitespace between tags on each line of your source code.
This will cause a hydration error.%s`,t,n),!1}function $t(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}function en(e){return e.replace(Nm,function(e,t){return t.toUpperCase()})}function tn(e,t,n){var r=t.indexOf(`--`)===0;r||(-1<t.indexOf(`-`)?Fm.hasOwnProperty(t)&&Fm[t]||(Fm[t]=!0,console.error(`Unsupported style property %s. Did you mean %s?`,t,en(t.replace(Mm,`ms-`)))):jm.test(t)?Fm.hasOwnProperty(t)&&Fm[t]||(Fm[t]=!0,console.error(`Unsupported vendor-prefixed style property %s. Did you mean %s?`,t,t.charAt(0).toUpperCase()+t.slice(1))):!Pm.test(n)||Im.hasOwnProperty(n)&&Im[n]||(Im[n]=!0,console.error(`Style property values shouldn't contain a semicolon. Try "%s: %s" instead.`,t,n.replace(Pm,``))),typeof n==`number`&&(isNaN(n)?Lm||(Lm=!0,console.error("`NaN` is an invalid value for the `%s` css style property.",t)):isFinite(n)||Rm||(Rm=!0,console.error("`Infinity` is an invalid value for the `%s` css style property.",t)))),n==null||typeof n==`boolean`||n===``?r?e.setProperty(t,``):t===`float`?e.cssFloat=``:e[t]=``:r?e.setProperty(t,n):typeof n!=`number`||n===0||zm.has(t)?t===`float`?e.cssFloat=n:(je(n,t),e[t]=(``+n).trim()):e[t]=n+`px`}function nn(e,t,n){if(t!=null&&typeof t!=`object`)throw Error("The `style` prop expects a mapping from style properties to values, not a string. For example, style={{marginRight: spacing + 'em'}} when using JSX.");if(t&&Object.freeze(t),e=e.style,n!=null){if(t){var r={};if(n){for(var i in n)if(n.hasOwnProperty(i)&&!t.hasOwnProperty(i))for(var a=Om[i]||[i],o=0;o<a.length;o++)r[a[o]]=i}for(var s in t)if(t.hasOwnProperty(s)&&(!n||n[s]!==t[s]))for(i=Om[s]||[s],a=0;a<i.length;a++)r[i[a]]=s;for(var c in s={},t)for(i=Om[c]||[c],a=0;a<i.length;a++)s[i[a]]=c;for(var l in c={},r)if(i=r[l],(a=s[l])&&i!==a&&(o=i+`,`+a,!c[o])){c[o]=!0,o=console;var u=t[i];o.error.call(o,`%s a style property during rerender (%s) when a conflicting property is set (%s) can lead to styling bugs. To avoid this, don't mix shorthand and non-shorthand properties for the same value; instead, replace the shorthand with separate values.`,u==null||typeof u==`boolean`||u===``?`Removing`:`Updating`,i,a)}}for(var d in n)!n.hasOwnProperty(d)||t!=null&&t.hasOwnProperty(d)||(d.indexOf(`--`)===0?e.setProperty(d,``):d===`float`?e.cssFloat=``:e[d]=``);for(var f in t)l=t[f],t.hasOwnProperty(f)&&n[f]!==l&&tn(e,f,l)}else for(r in t)t.hasOwnProperty(r)&&tn(e,r,t[r])}function rn(e){if(e.indexOf(`-`)===-1)return!1;switch(e){case`annotation-xml`:case`color-profile`:case`font-face`:case`font-face-src`:case`font-face-uri`:case`font-face-format`:case`font-face-name`:case`missing-glyph`:return!1;default:return!0}}function an(e){return Hm.get(e)||e}function on(e,t){if(Sp.call(Gm,t)&&Gm[t])return!0;if(qm.test(t)){if(e=`aria-`+t.slice(4).toLowerCase(),e=Wm.hasOwnProperty(e)?e:null,e==null)return console.error("Invalid ARIA attribute `%s`. ARIA attributes follow the pattern aria-* and must be lowercase.",t),Gm[t]=!0;if(t!==e)return console.error("Invalid ARIA attribute `%s`. Did you mean `%s`?",t,e),Gm[t]=!0}if(Km.test(t)){if(e=t.toLowerCase(),e=Wm.hasOwnProperty(e)?e:null,e==null)return Gm[t]=!0,!1;t!==e&&(console.error("Unknown ARIA attribute `%s`. Did you mean `%s`?",t,e),Gm[t]=!0)}return!0}function sn(e,t){var n=[],r;for(r in t)on(e,r)||n.push(r);t=n.map(function(e){return"`"+e+"`"}).join(`, `),n.length===1?console.error(`Invalid aria prop %s on <%s> tag. For details, see https://react.dev/link/invalid-aria-props`,t,e):1<n.length&&console.error(`Invalid aria props %s on <%s> tag. For details, see https://react.dev/link/invalid-aria-props`,t,e)}function cn(e,t,n,r){if(Sp.call(Ym,t)&&Ym[t])return!0;var i=t.toLowerCase();if(i===`onfocusin`||i===`onfocusout`)return console.error(`React uses onFocus and onBlur instead of onFocusIn and onFocusOut. All React events are normalized to bubble, so onFocusIn and onFocusOut are not needed/supported by React.`),Ym[t]=!0;if(typeof n==`function`&&(e===`form`&&t===`action`||e===`input`&&t===`formAction`||e===`button`&&t===`formAction`))return!0;if(r!=null){if(e=r.possibleRegistrationNames,r.registrationNameDependencies.hasOwnProperty(t))return!0;if(r=e.hasOwnProperty(i)?e[i]:null,r!=null)return console.error("Invalid event handler property `%s`. Did you mean `%s`?",t,r),Ym[t]=!0;if(Xm.test(t))return console.error("Unknown event handler property `%s`. It will be ignored.",t),Ym[t]=!0}else if(Xm.test(t))return Zm.test(t)&&console.error("Invalid event handler property `%s`. React events use the camelCase naming convention, for example `onClick`.",t),Ym[t]=!0;if(Qm.test(t)||$m.test(t))return!0;if(i===`innerhtml`)return console.error("Directly setting property `innerHTML` is not permitted. For more information, lookup documentation on `dangerouslySetInnerHTML`."),Ym[t]=!0;if(i===`aria`)return console.error("The `aria` attribute is reserved for future use in React. Pass individual `aria-` attributes instead."),Ym[t]=!0;if(i===`is`&&n!=null&&typeof n!=`string`)return console.error("Received a `%s` for a string attribute `is`. If this is expected, cast the value to a string.",typeof n),Ym[t]=!0;if(typeof n==`number`&&isNaN(n))return console.error("Received NaN for the `%s` attribute. If this is expected, cast the value to a string.",t),Ym[t]=!0;if(Um.hasOwnProperty(i)){if(i=Um[i],i!==t)return console.error("Invalid DOM property `%s`. Did you mean `%s`?",t,i),Ym[t]=!0}else if(t!==i)return console.error("React does not recognize the `%s` prop on a DOM element. If you intentionally want it to appear in the DOM as a custom attribute, spell it as lowercase `%s` instead. If you accidentally passed it from a parent component, remove it from the DOM element.",t,i),Ym[t]=!0;switch(t){case`dangerouslySetInnerHTML`:case`children`:case`style`:case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`defaultValue`:case`defaultChecked`:case`innerHTML`:case`ref`:return!0;case`innerText`:case`textContent`:return!0}switch(typeof n){case`boolean`:switch(t){case`autoFocus`:case`checked`:case`multiple`:case`muted`:case`selected`:case`contentEditable`:case`spellCheck`:case`draggable`:case`value`:case`autoReverse`:case`externalResourcesRequired`:case`focusable`:case`preserveAlpha`:case`allowFullScreen`:case`async`:case`autoPlay`:case`controls`:case`default`:case`defer`:case`disabled`:case`disablePictureInPicture`:case`disableRemotePlayback`:case`formNoValidate`:case`hidden`:case`loop`:case`noModule`:case`noValidate`:case`open`:case`playsInline`:case`readOnly`:case`required`:case`reversed`:case`scoped`:case`seamless`:case`itemScope`:case`capture`:case`download`:case`inert`:return!0;default:return i=t.toLowerCase().slice(0,5),i===`data-`||i===`aria-`?!0:(n?console.error('Received `%s` for a non-boolean attribute `%s`.\n\nIf you want to write it to the DOM, pass a string instead: %s="%s" or %s={value.toString()}.',n,t,t,n,t):console.error(`Received \`%s\` for a non-boolean attribute \`%s\`.

If you want to write it to the DOM, pass a string instead: %s="%s" or %s={value.toString()}.

If you used to conditionally omit it with %s={condition && value}, pass %s={condition ? value : undefined} instead.`,n,t,t,n,t,t,t),Ym[t]=!0)}case`function`:case`symbol`:return Ym[t]=!0,!1;case`string`:if(n===`false`||n===`true`){switch(t){case`checked`:case`selected`:case`multiple`:case`muted`:case`allowFullScreen`:case`async`:case`autoPlay`:case`controls`:case`default`:case`defer`:case`disabled`:case`disablePictureInPicture`:case`disableRemotePlayback`:case`formNoValidate`:case`hidden`:case`loop`:case`noModule`:case`noValidate`:case`open`:case`playsInline`:case`readOnly`:case`required`:case`reversed`:case`scoped`:case`seamless`:case`itemScope`:case`inert`:break;default:return!0}console.error("Received the string `%s` for the boolean attribute `%s`. %s Did you mean %s={%s}?",n,t,n===`false`?`The browser will interpret it as a truthy value.`:`Although this works, it will not work as expected if you pass the string "false".`,t,n),Ym[t]=!0}}return!0}function ln(e,t,n){var r=[],i;for(i in t)cn(e,i,t[i],n)||r.push(i);t=r.map(function(e){return"`"+e+"`"}).join(`, `),r.length===1?console.error(`Invalid value for prop %s on <%s> tag. Either remove it from the element, or pass a string or number value to keep it in the DOM. For details, see https://react.dev/link/attribute-behavior `,t,e):1<r.length&&console.error(`Invalid values for props %s on <%s> tag. Either remove them from the element, or pass a string or number value to keep them in the DOM. For details, see https://react.dev/link/attribute-behavior `,t,e)}function un(e){return eh.test(``+e)?`javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')`:e}function dn(){}function fn(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}function pn(e){var t=et(e);if(t&&(e=t.stateNode)){var n=e[Qp]||null;a:switch(e=t.stateNode,t.type){case`input`:if(bt(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type===`radio`&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(T(t,`name`),n=n.querySelectorAll(`input[name="`+vt(``+t)+`"][type="radio"]`),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var i=r[Qp]||null;if(!i)throw Error("ReactDOMInput: Mixing React and non-React radio inputs with the same `name` is not supported.");bt(r,i.value,i.defaultValue,i.defaultValue,i.checked,i.defaultChecked,i.type,i.name)}}for(t=0;t<n.length;t++)r=n[t],r.form===e.form&&gt(r)}break a;case`textarea`:Ot(e,n.value,n.defaultValue);break a;case`select`:t=n.value,t!=null&&Tt(e,!!n.multiple,t,!1)}}}function mn(e,t,n){if(ih)return e(t,n);ih=!0;try{return e(t)}finally{if(ih=!1,(nh!==null||rh!==null)&&(pl(),nh&&(t=nh,e=rh,rh=nh=null,pn(t),e)))for(t=0;t<e.length;t++)pn(e[t])}}function hn(e,t){var n=e.stateNode;if(n===null)return null;var r=n[Qp]||null;if(r===null)return null;n=r[t];a:switch(t){case`onClick`:case`onClickCapture`:case`onDoubleClick`:case`onDoubleClickCapture`:case`onMouseDown`:case`onMouseDownCapture`:case`onMouseMove`:case`onMouseMoveCapture`:case`onMouseUp`:case`onMouseUpCapture`:case`onMouseEnter`:(r=!r.disabled)||(e=e.type,r=!(e===`button`||e===`input`||e===`select`||e===`textarea`)),e=!r;break a;default:e=!1}if(e)return null;if(n&&typeof n!=`function`)throw Error("Expected `"+t+"` listener to be a function, instead got a value of `"+typeof n+"` type.");return n}function gn(){if(uh)return uh;var e,t=lh,n=t.length,r,i=`value`in ch?ch.value:ch.textContent,a=i.length;for(e=0;e<n&&t[e]===i[e];e++);var o=n-e;for(r=1;r<=o&&t[n-r]===i[a-r];r++);return uh=i.slice(e,1<r?1-r:void 0)}function _n(e){var t=e.keyCode;return`charCode`in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function vn(){return!0}function yn(){return!1}function bn(e){function t(t,n,r,i,a){for(var o in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=i,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(o)&&(t=e[o],this[o]=t?t(i):i[o]);return this.isDefaultPrevented=(i.defaultPrevented==null?!1===i.returnValue:i.defaultPrevented)?vn:yn,this.isPropagationStopped=yn,this}return P(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():typeof e.returnValue!=`unknown`&&(e.returnValue=!1),this.isDefaultPrevented=vn)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():typeof e.cancelBubble!=`unknown`&&(e.cancelBubble=!0),this.isPropagationStopped=vn)},persist:function(){},isPersistent:vn}),t}function xn(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Oh[e])?!!t[e]:!1}function Sn(){return xn}function Cn(e,t){switch(e){case`keyup`:return Fh.indexOf(t.keyCode)!==-1;case`keydown`:return t.keyCode!==Ih;case`keypress`:case`mousedown`:case`focusout`:return!0;default:return!1}}function wn(e){return e=e.detail,typeof e==`object`&&`data`in e?e.data:null}function Tn(e,t){switch(e){case`compositionend`:return wn(t);case`keypress`:return t.which===Vh?(Uh=!0,Hh):null;case`textInput`:return e=t.data,e===Hh&&Uh?null:e;default:return null}}function En(e,t){if(Wh)return e===`compositionend`||!Lh&&Cn(e,t)?(e=gn(),uh=lh=ch=null,Wh=!1,e):null;switch(e){case`paste`:return null;case`keypress`:if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case`compositionend`:return Bh&&t.locale!==`ko`?null:t.data;default:return null}}function Dn(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t===`input`?!!Gh[e.type]:t===`textarea`}function On(e){if(!ah)return!1;e=`on`+e;var t=e in document;return t||=(t=document.createElement(`div`),t.setAttribute(e,`return;`),typeof t[e]==`function`),t}function kn(e,t,n,r){nh?rh?rh.push(r):rh=[r]:nh=r,t=bu(t,`onChange`),0<t.length&&(n=new fh(`onChange`,`change`,null,n,r),e.push({event:n,listeners:t}))}function An(e){mu(e,0)}function jn(e){if(gt(tt(e)))return e}function Mn(e,t){if(e===`change`)return t}function Nn(){Kh&&(Kh.detachEvent(`onpropertychange`,Pn),qh=Kh=null)}function Pn(e){if(e.propertyName===`value`&&jn(qh)){var t=[];kn(t,qh,e,fn(e)),mn(An,t)}}function Fn(e,t,n){e===`focusin`?(Nn(),Kh=t,qh=n,Kh.attachEvent(`onpropertychange`,Pn)):e===`focusout`&&Nn()}function In(e){if(e===`selectionchange`||e===`keyup`||e===`keydown`)return jn(qh)}function Ln(e,t){if(e===`click`)return jn(t)}function Rn(e,t){if(e===`input`||e===`change`)return jn(t)}function zn(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}function Bn(e,t){if(Yh(e,t))return!0;if(typeof e!=`object`||!e||typeof t!=`object`||!t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!Sp.call(t,i)||!Yh(e[i],t[i]))return!1}return!0}function Vn(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Hn(e,t){var n=Vn(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}a:{for(;n;){if(n.nextSibling){n=n.nextSibling;break a}n=n.parentNode}n=void 0}n=Vn(n)}}function Un(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Un(e,t.parentNode):`contains`in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Wn(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=_t(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href==`string`}catch{n=!1}if(n)e=t.contentWindow;else break;t=_t(e.document)}return t}function Gn(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t===`input`&&(e.type===`text`||e.type===`search`||e.type===`tel`||e.type===`url`||e.type===`password`)||t===`textarea`||e.contentEditable===`true`)}function Kn(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;eg||Zh==null||Zh!==_t(r)||(r=Zh,`selectionStart`in r&&Gn(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),$h&&Bn($h,r)||($h=r,r=bu(Qh,`onSelect`),0<r.length&&(t=new fh(`onSelect`,`select`,null,t,n),e.push({event:t,listeners:r}),t.target=Zh)))}function qn(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n[`Webkit`+e]=`webkit`+t,n[`Moz`+e]=`moz`+t,n}function Jn(e){if(ng[e])return ng[e];if(!tg[e])return e;var t=tg[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in rg)return ng[e]=t[n];return e}function Yn(e,t){dg.set(e,t),it(t,[e])}function Xn(e){for(var t=yg,n=0;n<e.length;n++){var r=e[n];if(typeof r==`object`&&r)if($f(r)&&r.length===2&&typeof r[0]==`string`){if(t!==yg&&t!==Sg)return bg;t=Sg}else return bg;else{if(typeof r==`function`||typeof r==`string`&&50<r.length||t!==yg&&t!==xg)return bg;t=xg}}return t}function Zn(e,t,n,r){for(var i in e)Sp.call(e,i)&&i[0]!==`_`&&Qn(i,e[i],t,n,r)}function Qn(e,t,n,r,i){switch(typeof t){case`object`:if(t===null){t=`null`;break}else{if(t.$$typeof===Lf){var a=x(t.type)||`…`,o=t.key;t=t.props;var s=Object.keys(t),c=s.length;if(o==null&&c===0){t=`<`+a+` />`;break}if(3>r||c===1&&s[0]===`children`&&o==null){t=`<`+a+` … />`;break}for(var l in n.push([i+`\xA0\xA0`.repeat(r)+e,`<`+a]),o!==null&&Qn(`key`,o,n,r+1,i),e=!1,t)l===`children`?t.children!=null&&(!$f(t.children)||0<t.children.length)&&(e=!0):Sp.call(t,l)&&l[0]!==`_`&&Qn(l,t[l],n,r+1,i);n.push([``,e?`>…</`+a+`>`:`/>`]);return}if(a=Object.prototype.toString.call(t),a=a.slice(8,a.length-1),a===`Array`){if(l=Xn(t),l===xg||l===yg){t=JSON.stringify(t);break}else if(l===Sg){for(n.push([i+`\xA0\xA0`.repeat(r)+e,``]),e=0;e<t.length;e++)a=t[e],Qn(a[0],a[1],n,r+1,i);return}}if(a===`Promise`){if(t.status===`fulfilled`){if(a=n.length,Qn(e,t.value,n,r,i),n.length>a){n=n[a],n[1]=`Promise<`+(n[1]||`Object`)+`>`;return}}else if(t.status===`rejected`&&(a=n.length,Qn(e,t.reason,n,r,i),n.length>a)){n=n[a],n[1]=`Rejected Promise<`+n[1]+`>`;return}n.push([`\xA0\xA0`.repeat(r)+e,`Promise`]);return}a===`Object`&&(l=Object.getPrototypeOf(t))&&typeof l.constructor==`function`&&(a=l.constructor.name),n.push([i+`\xA0\xA0`.repeat(r)+e,a===`Object`?3>r?``:`…`:a]),3>r&&Zn(t,n,r+1,i);return}case`function`:t=t.name===``?`() => {}`:t.name+`() {}`;break;case`string`:t=t===vg?`…`:JSON.stringify(t);break;case`undefined`:t=`undefined`;break;case`boolean`:t=t?`true`:`false`;break;default:t=String(t)}n.push([i+`\xA0\xA0`.repeat(r)+e,t])}function $n(e,t,n,r){var i=!0;for(o in e)o in t||(n.push([Cg+`\xA0\xA0`.repeat(r)+o,`…`]),i=!1);for(var a in t)if(a in e){var o=e[a],s=t[a];if(o!==s){if(r===0&&a===`children`)i=`\xA0\xA0`.repeat(r)+a,n.push([Cg+i,`…`],[wg+i,`…`]);else{if(!(3<=r)){if(typeof o==`object`&&typeof s==`object`&&o!==null&&s!==null&&o.$$typeof===s.$$typeof)if(s.$$typeof===Lf){if(o.type===s.type&&o.key===s.key){o=x(s.type)||`…`,i=`\xA0\xA0`.repeat(r)+a,o=`<`+o+` … />`,n.push([Cg+i,o],[wg+i,o]),i=!1;continue}}else{var c=Object.prototype.toString.call(o),l=Object.prototype.toString.call(s);if(c===l&&(l===`[object Object]`||l===`[object Array]`)){c=[Tg+`\xA0\xA0`.repeat(r)+a,l===`[object Array]`?`Array`:``],n.push(c),l=n.length,$n(o,s,n,r+1)?l===n.length&&(c[1]=`Referentially unequal but deeply equal objects. Consider memoization.`):i=!1;continue}}else if(typeof o==`function`&&typeof s==`function`&&o.name===s.name&&o.length===s.length&&(c=Function.prototype.toString.call(o),l=Function.prototype.toString.call(s),c===l)){o=s.name===``?`() => {}`:s.name+`() {}`,n.push([Tg+`\xA0\xA0`.repeat(r)+a,o+` Referentially unequal function closure. Consider memoization.`]);continue}}Qn(a,o,n,r,Cg),Qn(a,s,n,r,wg)}i=!1}}else n.push([wg+`\xA0\xA0`.repeat(r)+a,`…`]),i=!1;return i}function er(e){z=e&63?`Blocking`:e&64?`Gesture`:e&4194176?`Transition`:e&62914560?`Suspense`:e&2080374784?`Idle`:`Other`}function tr(e,t,n,r){L&&(kg.start=t,kg.end=n,Og.color=`warning`,Og.tooltipText=r,Og.properties=null,(e=e._debugTask)?e.run(performance.measure.bind(performance,r,kg)):performance.measure(r,kg))}function nr(e,t,n){tr(e,t,n,`Reconnect`)}function rr(e,t,n,r,i){var a=S(e);if(a!==null&&L){var o=e.alternate,s=e.actualDuration;if(o===null||o.child!==e.child)for(var c=e.child;c!==null;c=c.sibling)s-=c.actualDuration;r=.5>s?r?`tertiary-light`:`primary-light`:10>s?r?`tertiary`:`primary`:100>s?r?`tertiary-dark`:`primary-dark`:`error`;var l=e.memoizedProps;s=e._debugTask,l!==null&&o!==null&&o.memoizedProps!==l?(c=[Ag],l=$n(o.memoizedProps,l,c,0),1<c.length&&(l&&!Dg&&(o.lanes&i)===0&&100<e.actualDuration?(Dg=!0,c[0]=Mg,Og.color=`warning`,Og.tooltipText=jg):(Og.color=r,Og.tooltipText=a),Og.properties=c,kg.start=t,kg.end=n,s==null?performance.measure(`​`+a,kg):s.run(performance.measure.bind(performance,`​`+a,kg)))):s==null?console.timeStamp(a,t,n,Eg,void 0,r):s.run(console.timeStamp.bind(console,a,t,n,Eg,void 0,r))}}function ir(e,t,n,r){if(L){var i=S(e);if(i!==null){for(var a=null,o=[],s=0;s<r.length;s++){var c=r[s];a==null&&c.source!==null&&(a=c.source._debugTask),c=c.value,o.push([`Error`,typeof c==`object`&&c&&typeof c.message==`string`?String(c.message):String(c)])}e.key!==null&&Qn(`key`,e.key,o,0,``),e.memoizedProps!==null&&Zn(e.memoizedProps,o,0,``),a??=e._debugTask,e={start:t,end:n,detail:{devtools:{color:`error`,track:Eg,tooltipText:e.tag===13?`Hydration failed`:`Error boundary caught an error`,properties:o}}},a?a.run(performance.measure.bind(performance,`​`+i,e)):performance.measure(`​`+i,e)}}}function ar(e,t,n,r,i){if(i!==null){if(L){var a=S(e);if(a!==null){r=[];for(var o=0;o<i.length;o++){var s=i[o].value;r.push([`Error`,typeof s==`object`&&s&&typeof s.message==`string`?String(s.message):String(s)])}e.key!==null&&Qn(`key`,e.key,r,0,``),e.memoizedProps!==null&&Zn(e.memoizedProps,r,0,``),t={start:t,end:n,detail:{devtools:{color:`error`,track:Eg,tooltipText:`A lifecycle or effect errored`,properties:r}}},(e=e._debugTask)?e.run(performance.measure.bind(performance,`​`+a,t)):performance.measure(`​`+a,t)}}}else a=S(e),a!==null&&L&&(i=1>r?`secondary-light`:100>r?`secondary`:500>r?`secondary-dark`:`error`,(e=e._debugTask)?e.run(console.timeStamp.bind(console,a,t,n,Eg,void 0,i)):console.timeStamp(a,t,n,Eg,void 0,i))}function or(e,t,n,r){if(L&&!(t<=e)){var i=(n&738197653)===n?`tertiary-dark`:`primary-dark`;n=(n&536870912)===n?`Prepared`:(n&201326741)===n?`Hydrated`:`Render`,r?r.run(console.timeStamp.bind(console,n,e,t,z,R,i)):console.timeStamp(n,e,t,z,R,i)}}function sr(e,t,n,r){!L||t<=e||(n=(n&738197653)===n?`tertiary-dark`:`primary-dark`,r?r.run(console.timeStamp.bind(console,`Prewarm`,e,t,z,R,n)):console.timeStamp(`Prewarm`,e,t,z,R,n))}function cr(e,t,n,r){!L||t<=e||(n=(n&738197653)===n?`tertiary-dark`:`primary-dark`,r?r.run(console.timeStamp.bind(console,`Suspended`,e,t,z,R,n)):console.timeStamp(`Suspended`,e,t,z,R,n))}function lr(e,t,n,r,i,a){if(L&&!(t<=e)){n=[];for(var o=0;o<r.length;o++){var s=r[o].value;n.push([`Recoverable Error`,typeof s==`object`&&s&&typeof s.message==`string`?String(s.message):String(s)])}e={start:e,end:t,detail:{devtools:{color:`primary-dark`,track:z,trackGroup:R,tooltipText:i?`Hydration Failed`:`Recovered after Error`,properties:n}}},a?a.run(performance.measure.bind(performance,`Recovered`,e)):performance.measure(`Recovered`,e)}}function ur(e,t,n,r){!L||t<=e||(r?r.run(console.timeStamp.bind(console,`Errored`,e,t,z,R,`error`)):console.timeStamp(`Errored`,e,t,z,R,`error`))}function dr(e,t,n,r){!L||t<=e||(r?r.run(console.timeStamp.bind(console,n,e,t,z,R,`secondary-light`)):console.timeStamp(n,e,t,z,R,`secondary-light`))}function fr(e,t,n,r,i){if(L&&!(t<=e)){for(var a=[],o=0;o<n.length;o++){var s=n[o].value;a.push([`Error`,typeof s==`object`&&s&&typeof s.message==`string`?String(s.message):String(s)])}e={start:e,end:t,detail:{devtools:{color:`error`,track:z,trackGroup:R,tooltipText:r?`Remaining Effects Errored`:`Commit Errored`,properties:a}}},i?i.run(performance.measure.bind(performance,`Errored`,e)):performance.measure(`Errored`,e)}}function pr(e,t,n){!L||t<=e||(n?n.run(console.timeStamp.bind(console,`Animating`,e,t,z,R,`secondary-dark`)):console.timeStamp(`Animating`,e,t,z,R,`secondary-dark`))}function mr(){for(var e=Ig,t=Lg=Ig=0;t<e;){var n=Fg[t];Fg[t++]=null;var r=Fg[t];Fg[t++]=null;var i=Fg[t];Fg[t++]=null;var a=Fg[t];if(Fg[t++]=null,r!==null&&i!==null){var o=r.pending;o===null?i.next=i:(i.next=o.next,o.next=i),r.pending=i}a!==0&&vr(n,i,a)}}function hr(e,t,n,r){Fg[Ig++]=e,Fg[Ig++]=t,Fg[Ig++]=n,Fg[Ig++]=r,Lg|=r,e.lanes|=r,e=e.alternate,e!==null&&(e.lanes|=r)}function gr(e,t,n,r){return hr(e,t,n,r),yr(e)}function _r(e,t){return hr(e,null,null,t),yr(e)}function vr(e,t,n){e.lanes|=n;var r=e.alternate;r!==null&&(r.lanes|=n);for(var i=!1,a=e.return;a!==null;)a.childLanes|=n,r=a.alternate,r!==null&&(r.childLanes|=n),a.tag===22&&(e=a.stateNode,e===null||e._visibility&Ng||(i=!0)),e=a,a=a.return;return e.tag===3?(a=e.stateNode,i&&t!==null&&(i=31-Bp(n),e=a.hiddenUpdates,r=e[i],r===null?e[i]=[t]:r.push(t),t.lane=n|536870912),a):null}function yr(e){if(qx>Kx)throw Qx=qx=0,$x=Jx=null,Error(`Maximum update depth exceeded. This can happen when a component repeatedly calls setState inside componentWillUpdate or componentDidUpdate. React limits the number of nested updates to prevent infinite loops.`);Qx>Zx&&(Qx=0,$x=null,console.error(`Maximum update depth exceeded. This can happen when a component calls setState inside useEffect, but useEffect either doesn't have a dependency array, or one of the dependencies changes on every render.`)),e.alternate===null&&e.flags&4098&&Xl(e);for(var t=e,n=t.return;n!==null;)t.alternate===null&&t.flags&4098&&Xl(e),t=n,n=t.return;return t.tag===3?t.stateNode:null}function br(e){if(zg===null)return e;var t=zg(e);return t===void 0?e:t.current}function xr(e){if(zg===null)return e;var t=zg(e);return t===void 0?e!=null&&typeof e.render==`function`&&(t=br(e.render),e.render!==t)?(t={$$typeof:Wf,render:t},e.displayName!==void 0&&(t.displayName=e.displayName),t):e:t.current}function Sr(e,t){if(zg===null)return!1;var n=e.elementType;t=t.type;var r=!1,i=typeof t==`object`&&t?t.$$typeof:null;switch(e.tag){case 1:typeof t==`function`&&(r=!0);break;case 0:(typeof t==`function`||i===Jf)&&(r=!0);break;case 11:(i===Wf||i===Jf)&&(r=!0);break;case 14:case 15:(i===qf||i===Jf)&&(r=!0);break;default:return!1}return!!(r&&(e=zg(n),e!==void 0&&e===zg(t)))}function Cr(e){zg!==null&&typeof WeakSet==`function`&&(Bg===null&&(Bg=new WeakSet),Bg.add(e))}function wr(e,t,n){do{var r=e,i=r.alternate,a=r.child,o=r.sibling,s=r.tag;r=r.type;var c=null;switch(s){case 0:case 15:case 1:c=r;break;case 11:c=r.render}if(zg===null)throw Error(`Expected resolveFamily to be set during hot reload.`);var l=!1;if(r=!1,c!==null&&(c=zg(c),c!==void 0&&(n.has(c)?r=!0:t.has(c)&&(s===1?r=!0:l=!0))),Bg!==null&&(Bg.has(e)||i!==null&&Bg.has(i))&&(r=!0),r&&(e._debugNeedsRemount=!0),(r||l)&&(i=_r(e,2),i!==null&&cl(i,e,2)),a===null||r||wr(a,t,n),o===null)break;e=o}while(1)}function Tr(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null,this.actualDuration=-0,this.actualStartTime=-1.1,this.treeBaseDuration=this.selfBaseDuration=-0,this._debugTask=this._debugStack=this._debugOwner=this._debugInfo=null,this._debugNeedsRemount=!1,this._debugHookTypes=null,Gg||typeof Object.preventExtensions!=`function`||Object.preventExtensions(this)}function Er(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Dr(e,t){var n=e.alternate;switch(n===null?(n=g(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n._debugOwner=e._debugOwner,n._debugStack=e._debugStack,n._debugTask=e._debugTask,n._debugHookTypes=e._debugHookTypes,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null,n.actualDuration=-0,n.actualStartTime=-1.1),n.flags=e.flags&65011712,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext,_debugThenableState:t._debugThenableState},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n.selfBaseDuration=e.selfBaseDuration,n.treeBaseDuration=e.treeBaseDuration,n._debugInfo=e._debugInfo,n._debugNeedsRemount=e._debugNeedsRemount,n.tag){case 0:case 15:n.type=br(e.type);break;case 1:n.type=br(e.type);break;case 11:n.type=xr(e.type)}return n}function Or(e,t){e.flags&=65011714;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null,e.selfBaseDuration=0,e.treeBaseDuration=0):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext,_debugThenableState:t._debugThenableState},e.selfBaseDuration=n.selfBaseDuration,e.treeBaseDuration=n.treeBaseDuration),e}function kr(e,t,n,r,i,a){var o=0,s=e;if(typeof e==`function`)Er(e)&&(o=1),s=br(s);else if(typeof e==`string`)o=pe(),o=Xd(e,n,o)?26:e===`html`||e===`head`||e===`body`?27:5;else a:switch(e){case Yf:return t=g(31,n,t,i),t.elementType=Yf,t.lanes=a,t;case zf:return jr(n.children,i,a,t);case Bf:o=8,i|=Hg,i|=Ug;break;case Vf:return e=n,r=i,typeof e.id!=`string`&&console.error('Profiler must specify an "id" of type `string` as a prop. Received the type `%s` instead.',typeof e.id),t=g(12,e,t,r|V),t.elementType=Vf,t.lanes=a,t.stateNode={effectDuration:0,passiveEffectDuration:0},t;case Gf:return t=g(13,n,t,i),t.elementType=Gf,t.lanes=a,t;case Kf:return t=g(19,n,t,i),t.elementType=Kf,t.lanes=a,t;default:if(typeof e==`object`&&e)switch(e.$$typeof){case Uf:o=10;break a;case Hf:o=9;break a;case Wf:o=11,s=xr(s);break a;case qf:o=14;break a;case Jf:o=16,s=null;break a}s=``,(e===void 0||typeof e==`object`&&e&&Object.keys(e).length===0)&&(s+=` You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.`),e===null?n=`null`:$f(e)?n=`array`:e!==void 0&&e.$$typeof===Lf?(n=`<`+(x(e.type)||`Unknown`)+` />`,s=` Did you accidentally export a JSX literal instead of a component?`):n=typeof e,(o=r?se(r):null)&&(s+=`

Check the render method of \``+o+"`."),o=29,n=Error(`Element type is invalid: expected a string (for built-in components) or a class/function (for composite components) but got: `+(n+`.`+s)),s=null}return t=g(o,n,t,i),t.elementType=e,t.type=s,t.lanes=a,t._debugOwner=r,t}function Ar(e,t,n){return t=kr(e.type,e.key,e.props,e._owner,t,n),t._debugOwner=e._owner,t._debugStack=e._debugStack,t._debugTask=e._debugTask,t}function jr(e,t,n,r){return e=g(7,e,r,t),e.lanes=n,e}function Mr(e,t,n){return e=g(6,e,null,t),e.lanes=n,e}function Nr(e){var t=g(18,null,null,B);return t.stateNode=e,t}function Pr(e,t,n){return t=g(4,e.children===null?[]:e.children,e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function Fr(e,t){if(typeof e==`object`&&e){var n=qg.get(e);return n===void 0?(t={value:e,source:t,stack:Ce(t)},qg.set(e,t),t):n}return{value:e,source:t,stack:Ce(t)}}function Ir(e,t){Hr(),Jg[Yg++]=Zg,Jg[Yg++]=Xg,Xg=e,Zg=t}function Lr(e,t,n){Hr(),Qg[$g++]=t_,Qg[$g++]=n_,Qg[$g++]=e_,e_=e;var r=t_;e=n_;var i=32-Bp(r)-1;r&=~(1<<i),n+=1;var a=32-Bp(t)+i;if(30<a){var o=i-i%5;a=(r&(1<<o)-1).toString(32),r>>=o,i-=o,t_=1<<32-Bp(t)+i|n<<i|r,n_=a+e}else t_=1<<a|n<<i|r,n_=e}function Rr(e){Hr(),e.return!==null&&(Ir(e,1),Lr(e,1,0))}function zr(e){for(;e===Xg;)Xg=Jg[--Yg],Jg[Yg]=null,Zg=Jg[--Yg],Jg[Yg]=null;for(;e===e_;)e_=Qg[--$g],Qg[$g]=null,n_=Qg[--$g],Qg[$g]=null,t_=Qg[--$g],Qg[$g]=null}function Br(){return Hr(),e_===null?null:{id:t_,overflow:n_}}function Vr(e,t){Hr(),Qg[$g++]=t_,Qg[$g++]=n_,Qg[$g++]=e_,t_=t.id,n_=t.overflow,e_=e}function Hr(){H||console.error(`Expected to be hydrating. This is a bug in React. Please file an issue.`)}function Ur(e,t){if(e.return===null){if(o_===null)o_={fiber:e,children:[],serverProps:void 0,serverTail:[],distanceFromLeaf:t};else{if(o_.fiber!==e)throw Error(`Saw multiple hydration diff roots in a pass. This is a bug in React.`);o_.distanceFromLeaf>t&&(o_.distanceFromLeaf=t)}return o_}var n=Ur(e.return,t+1).children;return 0<n.length&&n[n.length-1].fiber===e?(n=n[n.length-1],n.distanceFromLeaf>t&&(n.distanceFromLeaf=t),n):(t={fiber:e,children:[],serverProps:void 0,serverTail:[],distanceFromLeaf:t},n.push(t),t)}function Wr(){H&&console.error(`We should not be hydrating here. This is a bug in React. Please file a bug.`)}function Gr(e,t){a_||(e=Ur(e,0),e.serverProps=null,t!==null&&(t=wd(t),e.serverTail.push(t)))}function Kr(e){var t=1<arguments.length&&arguments[1]!==void 0?arguments[1]:!1,n=``,r=o_;throw r!==null&&(o_=null,n=Gt(r)),Qr(Fr(Error(`Hydration failed because the server rendered `+(t?`text`:`HTML`)+` didn't match the client. As a result this tree will be regenerated on the client. This can happen if a SSR-ed Client Component used:

- A server/client branch \`if (typeof window !== 'undefined')\`.
- Variable input such as \`Date.now()\` or \`Math.random()\` which changes each time it's called.
- Date formatting in a user's locale which doesn't match the server.
- External changing data without sending a snapshot of it along with the HTML.
- Invalid HTML tag nesting.

It can also happen if the client has a browser extension installed which messes with the HTML before React loaded.

https://react.dev/link/hydration-mismatch`+n),e)),l_}function qr(e){var t=e.stateNode,n=e.type,r=e.memoizedProps;switch(t[Zp]=e,t[Qp]=r,Cu(n,r),n){case`dialog`:M(`cancel`,t),M(`close`,t);break;case`iframe`:case`object`:case`embed`:M(`load`,t);break;case`video`:case`audio`:for(n=0;n<pS.length;n++)M(pS[n],t);break;case`source`:M(`error`,t);break;case`img`:case`image`:case`link`:M(`error`,t),M(`load`,t);break;case`details`:M(`toggle`,t);break;case`input`:ot(`input`,r),M(`invalid`,t),yt(t,r),xt(t,r.value,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name,!0);break;case`option`:Ct(t,r);break;case`select`:ot(`select`,r),M(`invalid`,t),Et(t,r);break;case`textarea`:ot(`textarea`,r),M(`invalid`,t),Dt(t,r),kt(t,r.value,r.defaultValue,r.children)}n=r.children,typeof n!=`string`&&typeof n!=`number`&&typeof n!=`bigint`||t.textContent===``+n||!0===r.suppressHydrationWarning||ku(t.textContent,n)?(r.popover!=null&&(M(`beforetoggle`,t),M(`toggle`,t)),r.onScroll!=null&&M(`scroll`,t),r.onScrollEnd!=null&&M(`scrollend`,t),r.onClick!=null&&(t.onclick=dn),t=!0):t=!1,t||Kr(e,!0)}function Jr(e){for(r_=e.return;r_;)switch(r_.tag){case 5:case 31:case 13:c_=!1;return;case 27:case 3:c_=!0;return;default:r_=r_.return}}function Yr(e){if(e!==r_)return!1;if(!H)return Jr(e),H=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!==`form`&&n!==`button`)||Ju(e.type,e.memoizedProps)),n=!n),n&&i_){for(n=i_;n;){var r=Ur(e,0),i=wd(n);r.serverTail.push(i),n=i.type===`Suspense`?Ed(n):Cd(n.nextSibling)}Kr(e)}if(Jr(e),t===13){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(`Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.`);i_=Ed(e)}else if(t===31){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(`Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.`);i_=Ed(e)}else t===27?(t=i_,ad(e.type)?(e=rC,rC=null,i_=e):i_=t):i_=r_?Cd(e.stateNode.nextSibling):null;return!0}function Xr(){i_=r_=null,a_=H=!1}function Zr(){var e=s_;return e!==null&&(hx===null?hx=e:hx.push.apply(hx,e),s_=null),e}function Qr(e){s_===null?s_=[e]:s_.push(e)}function $r(){var e=o_;if(e!==null){o_=null;for(var t=Gt(e);0<e.children.length;)e=e.children[0];w(e.fiber,function(){console.error(`A tree hydrated but some attributes of the server rendered HTML didn't match the client properties. This won't be patched up. This can happen if a SSR-ed Client Component used:

- A server/client branch \`if (typeof window !== 'undefined')\`.
- Variable input such as \`Date.now()\` or \`Math.random()\` which changes each time it's called.
- Date formatting in a user's locale which doesn't match the server.
- External changing data without sending a snapshot of it along with the HTML.
- Invalid HTML tag nesting.

It can also happen if the client has a browser extension installed which messes with the HTML before React loaded.

%s%s`,`https://react.dev/link/hydration-mismatch`,t)})}}function ei(){m_=p_=null,h_=!1}function ti(e,t,n){C(u_,t._currentValue,e),t._currentValue=n,C(d_,t._currentRenderer,e),t._currentRenderer!==void 0&&t._currentRenderer!==null&&t._currentRenderer!==f_&&console.error(`Detected multiple renderers concurrently rendering the same context provider. This is currently unsupported.`),t._currentRenderer=f_}function ni(e,t){e._currentValue=u_.current;var n=d_.current;le(d_,t),e._currentRenderer=n,le(u_,t)}function ri(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)===t?r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t):(e.childLanes|=t,r!==null&&(r.childLanes|=t)),e===n)break;e=e.return}e!==n&&console.error(`Expected to find the propagation root when scheduling context work. This error is likely caused by a bug in React. Please file an issue.`)}function ii(e,t,n,r){var i=e.child;for(i!==null&&(i.return=e);i!==null;){var a=i.dependencies;if(a!==null){var o=i.child;a=a.firstContext;a:for(;a!==null;){var s=a;a=i;for(var c=0;c<t.length;c++)if(s.context===t[c]){a.lanes|=n,s=a.alternate,s!==null&&(s.lanes|=n),ri(a.return,n,e),r||(o=null);break a}a=s.next}}else if(i.tag===18){if(o=i.return,o===null)throw Error(`We just came from a parent so we must have had a parent. This is a bug in React.`);o.lanes|=n,a=o.alternate,a!==null&&(a.lanes|=n),ri(o,n,e),o=null}else o=i.child;if(o!==null)o.return=i;else for(o=i;o!==null;){if(o===e){o=null;break}if(i=o.sibling,i!==null){i.return=o.return,o=i;break}o=o.return}i=o}}function ai(e,t,n,r){e=null;for(var i=t,a=!1;i!==null;){if(!a){if(i.flags&524288)a=!0;else if(i.flags&262144)break}if(i.tag===10){var o=i.alternate;if(o===null)throw Error(`Should have a current fiber. This is a bug in React.`);if(o=o.memoizedProps,o!==null){var s=i.type;Yh(i.pendingProps.value,o.value)||(e===null?e=[s]:e.push(s))}}else if(i===sp.current){if(o=i.alternate,o===null)throw Error(`Should have a current fiber. This is a bug in React.`);o.memoizedState.memoizedState!==i.memoizedState.memoizedState&&(e===null?e=[xC]:e.push(xC))}i=i.return}e!==null&&ii(t,e,n,r),t.flags|=262144}function oi(e){for(e=e.firstContext;e!==null;){if(!Yh(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function si(e){p_=e,m_=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ci(e){return h_&&console.error(`Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().`),ui(p_,e)}function li(e,t){return p_===null&&si(e),ui(e,t)}function ui(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},m_===null){if(e===null)throw Error(`Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().`);m_=t,e.dependencies={lanes:0,firstContext:t,_debugThenableState:null},e.flags|=524288}else m_=m_.next=t;return n}function di(){return{controller:new g_,data:new Map,refCount:0}}function fi(e){e.controller.signal.aborted&&console.warn(`A cache instance was retained after it was already freed. This likely indicates a bug in React.`),e.refCount++}function pi(e){e.refCount--,0>e.refCount&&console.warn(`A cache instance was released after it was already freed. This likely indicates a bug in React.`),e.refCount===0&&__(v_,function(){e.controller.abort()})}function mi(e,t,n){e&127?0>P_&&(P_=b_(),F_=x_(t),L_=t,n!=null&&(R_=S(n)),(Y&(Rb|zb))!==Lb&&(M_=!0,I_=S_),e=Zu(),t=Xu(),e!==V_||t!==B_?V_=-1.1:t!==null&&(I_=S_),z_=e,B_=t):e&4194048&&0>G_&&(G_=b_(),q_=x_(t),J_=t,n!=null&&(Y_=S(n)),0>W_)&&(e=Zu(),t=Xu(),(e!==Q_||t!==Z_)&&(Q_=-1.1),X_=e,Z_=t)}function hi(e){if(0>P_){P_=b_(),F_=e._debugTask==null?null:e._debugTask,(Y&(Rb|zb))!==Lb&&(I_=S_);var t=Zu(),n=Xu();t!==V_||n!==B_?V_=-1.1:n!==null&&(I_=S_),z_=t,B_=n}0>G_&&(G_=b_(),q_=e._debugTask==null?null:e._debugTask,0>W_)&&(e=Zu(),t=Xu(),(e!==Q_||t!==Z_)&&(Q_=-1.1),X_=e,Z_=t)}function gi(){var e=k_;return k_=0,e}function _i(e){var t=k_;return k_=e,t}function vi(e){var t=k_;return k_+=e,t}function yi(){W=U=-1.1}function bi(){var e=U;return U=-1.1,e}function xi(e){0<=e&&(U=e)}function Si(){var e=A_;return A_=-0,e}function Ci(e){0<=e&&(A_=e)}function wi(){var e=j_;return j_=null,e}function Ti(){var e=M_;return M_=!1,e}function Ei(e){O_=b_(),0>e.actualStartTime&&(e.actualStartTime=O_)}function Di(e){if(0<=O_){var t=b_()-O_;e.actualDuration+=t,e.selfBaseDuration=t,O_=-1}}function Oi(e){if(0<=O_){var t=b_()-O_;e.actualDuration+=t,O_=-1}}function ki(){if(0<=O_){var e=b_(),t=e-O_;O_=-1,k_+=t,A_+=t,W=e}}function Ai(e){j_===null&&(j_=[]),j_.push(e),D_===null&&(D_=[]),D_.push(e)}function ji(){O_=b_(),0>U&&(U=O_)}function Mi(e){for(var t=e.child;t;)e.actualDuration+=t.actualDuration,t=t.sibling}function Ni(e,t){if(cv===null){var n=cv=[];lv=0,uv=lu(),dv={status:`pending`,value:void 0,then:function(e){n.push(e)}}}return lv++,t.then(Pi,Pi),t}function Pi(){if(--lv===0&&(-1<G_||(W_=-1.1),cv!==null)){dv!==null&&(dv.status=`fulfilled`);var e=cv;cv=null,uv=0,dv=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Fi(e,t){var n=[],r={status:`pending`,value:null,reason:null,then:function(e){n.push(e)}};return e.then(function(){r.status=`fulfilled`,r.value=t;for(var e=0;e<n.length;e++)(0,n[e])(t)},function(e){for(r.status=`rejected`,r.reason=e,e=0;e<n.length;e++)(0,n[e])(void 0)}),r}function Ii(){var e=pv.current;return e===null?X.pooledCache:e}function Li(e,t){t===null?C(pv,pv.current,e):C(pv,t.pool,e)}function Ri(){var e=Ii();return e===null?null:{parent:y_._currentValue,pool:e}}function zi(){return{didWarnAboutUncachedPromise:!1,thenables:[]}}function Bi(e){return e=e.status,e===`fulfilled`||e===`rejected`}function Vi(e,t,n){F.actQueue!==null&&(F.didUsePromise=!0);var r=e.thenables;if(n=r[n],n===void 0?r.push(t):n!==t&&(e.didWarnAboutUncachedPromise||(e.didWarnAboutUncachedPromise=!0,console.error(`A component was suspended by an uncached promise. Creating promises inside a Client Component or hook is not yet supported, except via a Suspense-compatible library or framework.`)),t.then(dn,dn),t=n),t._debugInfo===void 0){e=performance.now(),r=t.displayName;var i={name:typeof r==`string`?r:`Promise`,start:e,end:e,value:t};t._debugInfo=[{awaited:i}],t.status!==`fulfilled`&&t.status!==`rejected`&&(e=function(){i.end=performance.now()},t.then(e,e))}switch(t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,Wi(e),e;default:if(typeof t.status==`string`)t.then(dn,dn);else{if(e=X,e!==null&&100<e.shellSuspendCounter)throw Error("An unknown Component is an async Client Component. Only Server Components can be async at the moment. This error is often caused by accidentally adding `'use client'` to a module that was originally written for the server.");e=t,e.status=`pending`,e.then(function(e){if(t.status===`pending`){var n=t;n.status=`fulfilled`,n.value=e}},function(e){if(t.status===`pending`){var n=t;n.status=`rejected`,n.reason=e}})}switch(t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,Wi(e),e}throw Kv=t,qv=!0,Hv}}function Hi(e){try{return Vv(e)}catch(e){throw typeof e==`object`&&e&&typeof e.then==`function`?(Kv=e,qv=!0,Hv):e}}function Ui(){if(Kv===null)throw Error(`Expected a suspended thenable. This is a bug in React. Please file an issue.`);var e=Kv;return Kv=null,qv=!1,e}function Wi(e){if(e===Hv||e===Wv)throw Error("Hooks are not supported inside an async component. This error is often caused by accidentally adding `'use client'` to a module that was originally written for the server.")}function Gi(e){var t=G;return e!=null&&(G=t===null?e:t.concat(e)),t}function Ki(){var e=G;if(e!=null){for(var t=e.length-1;0<=t;t--)if(e[t].name!=null){var n=e[t].debugTask;if(n!=null)return n}}return null}function qi(e,t,n){for(var r=Object.keys(e.props),i=0;i<r.length;i++){var a=r[i];if(a!==`children`&&a!==`key`){t===null&&(t=Ar(e,n.mode,0),t._debugInfo=G,t.return=n),w(t,function(e){console.error("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.",e)},a);break}}}function Ji(e){var t=Yv;return Yv+=1,Jv===null&&(Jv=zi()),Vi(Jv,e,t)}function Yi(e,t){t=t.props.ref,e.ref=t===void 0?null:t}function Xi(e,t){throw t.$$typeof===If?Error(`A React Element from an older version of React was rendered. This is not supported. It can happen if:
- Multiple copies of the "react" package is used.
- A library pre-bundled an old copy of "react" or "react/jsx-runtime".
- A compiler tries to "inline" JSX instead of using the runtime.`):(e=Object.prototype.toString.call(t),Error(`Objects are not valid as a React child (found: `+(e===`[object Object]`?`object with keys {`+Object.keys(t).join(`, `)+`}`:e)+`). If you meant to render a collection of children, use an array instead.`))}function Zi(e,t){var n=Ki();n===null?Xi(e,t):n.run(Xi.bind(null,e,t))}function Qi(e,t){var n=S(e)||`Component`;$v[n]||($v[n]=!0,t=t.displayName||t.name||`Component`,e.tag===3?console.error(`Functions are not valid as a React child. This may happen if you return %s instead of <%s /> from render. Or maybe you meant to call this function rather than return it.
  root.render(%s)`,t,t,t):console.error(`Functions are not valid as a React child. This may happen if you return %s instead of <%s /> from render. Or maybe you meant to call this function rather than return it.
  <%s>{%s}</%s>`,t,t,n,t,n))}function $i(e,t){var n=Ki();n===null?Qi(e,t):n.run(Qi.bind(null,e,t))}function ea(e,t){var n=S(e)||`Component`;ey[n]||(ey[n]=!0,t=String(t),e.tag===3?console.error(`Symbols are not valid as a React child.
  root.render(%s)`,t):console.error(`Symbols are not valid as a React child.
  <%s>%s</%s>`,n,t,n))}function ta(e,t){var n=Ki();n===null?ea(e,t):n.run(ea.bind(null,e,t))}function na(e){function t(t,n){if(e){var r=t.deletions;r===null?(t.deletions=[n],t.flags|=16):r.push(n)}}function n(n,r){if(!e)return null;for(;r!==null;)t(n,r),r=r.sibling;return null}function r(e){for(var t=new Map;e!==null;)e.key===null?t.set(e.index,e):t.set(e.key,e),e=e.sibling;return t}function i(e,t){return e=Dr(e,t),e.index=0,e.sibling=null,e}function a(t,n,r){return t.index=r,e?(r=t.alternate,r===null?(t.flags|=67108866,n):(r=r.index,r<n?(t.flags|=67108866,n):r)):(t.flags|=1048576,n)}function o(t){return e&&t.alternate===null&&(t.flags|=67108866),t}function s(e,t,n,r){return t===null||t.tag!==6?(t=Mr(n,e.mode,r),t.return=e,t._debugOwner=e,t._debugTask=e._debugTask,t._debugInfo=G,t):(t=i(t,n),t.return=e,t._debugInfo=G,t)}function c(e,t,n,r){var a=n.type;return a===zf?(t=u(e,t,n.props.children,r,n.key),qi(n,t,e),t):t!==null&&(t.elementType===a||Sr(t,n)||typeof a==`object`&&a&&a.$$typeof===Jf&&Hi(a)===t.type)?(t=i(t,n.props),Yi(t,n),t.return=e,t._debugOwner=n._owner,t._debugInfo=G,t):(t=Ar(n,e.mode,r),Yi(t,n),t.return=e,t._debugInfo=G,t)}function l(e,t,n,r){return t===null||t.tag!==4||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=Pr(n,e.mode,r),t.return=e,t._debugInfo=G,t):(t=i(t,n.children||[]),t.return=e,t._debugInfo=G,t)}function u(e,t,n,r,a){return t===null||t.tag!==7?(t=jr(n,e.mode,r,a),t.return=e,t._debugOwner=e,t._debugTask=e._debugTask,t._debugInfo=G,t):(t=i(t,n),t.return=e,t._debugInfo=G,t)}function d(e,t,n){if(typeof t==`string`&&t!==``||typeof t==`number`||typeof t==`bigint`)return t=Mr(``+t,e.mode,n),t.return=e,t._debugOwner=e,t._debugTask=e._debugTask,t._debugInfo=G,t;if(typeof t==`object`&&t){switch(t.$$typeof){case Lf:return n=Ar(t,e.mode,n),Yi(n,t),n.return=e,e=Gi(t._debugInfo),n._debugInfo=G,G=e,n;case Rf:return t=Pr(t,e.mode,n),t.return=e,t._debugInfo=G,t;case Jf:var r=Gi(t._debugInfo);return t=Hi(t),e=d(e,t,n),G=r,e}if($f(t)||oe(t))return n=jr(t,e.mode,n,null),n.return=e,n._debugOwner=e,n._debugTask=e._debugTask,e=Gi(t._debugInfo),n._debugInfo=G,G=e,n;if(typeof t.then==`function`)return r=Gi(t._debugInfo),e=d(e,Ji(t),n),G=r,e;if(t.$$typeof===Uf)return d(e,li(e,t),n);Zi(e,t)}return typeof t==`function`&&$i(e,t),typeof t==`symbol`&&ta(e,t),null}function f(e,t,n,r){var i=t===null?null:t.key;if(typeof n==`string`&&n!==``||typeof n==`number`||typeof n==`bigint`)return i===null?s(e,t,``+n,r):null;if(typeof n==`object`&&n){switch(n.$$typeof){case Lf:return n.key===i?(i=Gi(n._debugInfo),e=c(e,t,n,r),G=i,e):null;case Rf:return n.key===i?l(e,t,n,r):null;case Jf:return i=Gi(n._debugInfo),n=Hi(n),e=f(e,t,n,r),G=i,e}if($f(n)||oe(n))return i===null?(i=Gi(n._debugInfo),e=u(e,t,n,r,null),G=i,e):null;if(typeof n.then==`function`)return i=Gi(n._debugInfo),e=f(e,t,Ji(n),r),G=i,e;if(n.$$typeof===Uf)return f(e,t,li(e,n),r);Zi(e,n)}return typeof n==`function`&&$i(e,n),typeof n==`symbol`&&ta(e,n),null}function m(e,t,n,r,i){if(typeof r==`string`&&r!==``||typeof r==`number`||typeof r==`bigint`)return e=e.get(n)||null,s(t,e,``+r,i);if(typeof r==`object`&&r){switch(r.$$typeof){case Lf:return n=e.get(r.key===null?n:r.key)||null,e=Gi(r._debugInfo),t=c(t,n,r,i),G=e,t;case Rf:return e=e.get(r.key===null?n:r.key)||null,l(t,e,r,i);case Jf:var a=Gi(r._debugInfo);return r=Hi(r),t=m(e,t,n,r,i),G=a,t}if($f(r)||oe(r))return n=e.get(n)||null,e=Gi(r._debugInfo),t=u(t,n,r,i,null),G=e,t;if(typeof r.then==`function`)return a=Gi(r._debugInfo),t=m(e,t,n,Ji(r),i),G=a,t;if(r.$$typeof===Uf)return m(e,t,n,li(t,r),i);Zi(t,r)}return typeof r==`function`&&$i(t,r),typeof r==`symbol`&&ta(t,r),null}function h(e,t,n,r){if(typeof n!=`object`||!n)return r;switch(n.$$typeof){case Lf:case Rf:p(e,t,n);var i=n.key;if(typeof i!=`string`)break;if(r===null){r=new Set,r.add(i);break}if(!r.has(i)){r.add(i);break}w(t,function(){console.error("Encountered two children with the same key, `%s`. Keys should be unique so that components maintain their identity across updates. Non-unique keys may cause children to be duplicated and/or omitted — the behavior is unsupported and could change in a future version.",i)});break;case Jf:n=Hi(n),h(e,t,n,r)}return r}function _(i,o,s,c){for(var l=null,u=null,p=null,g=o,_=o=0,v=null;g!==null&&_<s.length;_++){g.index>_?(v=g,g=null):v=g.sibling;var y=f(i,g,s[_],c);if(y===null){g===null&&(g=v);break}l=h(i,y,s[_],l),e&&g&&y.alternate===null&&t(i,g),o=a(y,o,_),p===null?u=y:p.sibling=y,p=y,g=v}if(_===s.length)return n(i,g),H&&Ir(i,_),u;if(g===null){for(;_<s.length;_++)g=d(i,s[_],c),g!==null&&(l=h(i,g,s[_],l),o=a(g,o,_),p===null?u=g:p.sibling=g,p=g);return H&&Ir(i,_),u}for(g=r(g);_<s.length;_++)v=m(g,i,_,s[_],c),v!==null&&(l=h(i,v,s[_],l),e&&v.alternate!==null&&g.delete(v.key===null?_:v.key),o=a(v,o,_),p===null?u=v:p.sibling=v,p=v);return e&&g.forEach(function(e){return t(i,e)}),H&&Ir(i,_),u}function v(i,o,s,c){if(s==null)throw Error(`An iterable object provided no iterator.`);for(var l=null,u=null,p=o,g=o=0,_=null,v=null,y=s.next();p!==null&&!y.done;g++,y=s.next()){p.index>g?(_=p,p=null):_=p.sibling;var b=f(i,p,y.value,c);if(b===null){p===null&&(p=_);break}v=h(i,b,y.value,v),e&&p&&b.alternate===null&&t(i,p),o=a(b,o,g),u===null?l=b:u.sibling=b,u=b,p=_}if(y.done)return n(i,p),H&&Ir(i,g),l;if(p===null){for(;!y.done;g++,y=s.next())p=d(i,y.value,c),p!==null&&(v=h(i,p,y.value,v),o=a(p,o,g),u===null?l=p:u.sibling=p,u=p);return H&&Ir(i,g),l}for(p=r(p);!y.done;g++,y=s.next())_=m(p,i,g,y.value,c),_!==null&&(v=h(i,_,y.value,v),e&&_.alternate!==null&&p.delete(_.key===null?g:_.key),o=a(_,o,g),u===null?l=_:u.sibling=_,u=_);return e&&p.forEach(function(e){return t(i,e)}),H&&Ir(i,g),l}function y(e,r,a,s){if(typeof a==`object`&&a&&a.type===zf&&a.key===null&&(qi(a,null,e),a=a.props.children),typeof a==`object`&&a){switch(a.$$typeof){case Lf:var c=Gi(a._debugInfo);a:{for(var l=a.key;r!==null;){if(r.key===l){if(l=a.type,l===zf){if(r.tag===7){n(e,r.sibling),s=i(r,a.props.children),s.return=e,s._debugOwner=a._owner,s._debugInfo=G,qi(a,s,e),e=s;break a}}else if(r.elementType===l||Sr(r,a)||typeof l==`object`&&l&&l.$$typeof===Jf&&Hi(l)===r.type){n(e,r.sibling),s=i(r,a.props),Yi(s,a),s.return=e,s._debugOwner=a._owner,s._debugInfo=G,e=s;break a}n(e,r);break}else t(e,r);r=r.sibling}a.type===zf?(s=jr(a.props.children,e.mode,s,a.key),s.return=e,s._debugOwner=e,s._debugTask=e._debugTask,s._debugInfo=G,qi(a,s,e),e=s):(s=Ar(a,e.mode,s),Yi(s,a),s.return=e,s._debugInfo=G,e=s)}return e=o(e),G=c,e;case Rf:a:{for(c=a,a=c.key;r!==null;){if(r.key===a)if(r.tag===4&&r.stateNode.containerInfo===c.containerInfo&&r.stateNode.implementation===c.implementation){n(e,r.sibling),s=i(r,c.children||[]),s.return=e,e=s;break a}else{n(e,r);break}else t(e,r);r=r.sibling}s=Pr(c,e.mode,s),s.return=e,e=s}return o(e);case Jf:return c=Gi(a._debugInfo),a=Hi(a),e=y(e,r,a,s),G=c,e}if($f(a))return c=Gi(a._debugInfo),e=_(e,r,a,s),G=c,e;if(oe(a)){if(c=Gi(a._debugInfo),l=oe(a),typeof l!=`function`)throw Error(`An object is not an iterable. This error is likely caused by a bug in React. Please file an issue.`);var u=l.call(a);return u===a?(e.tag!==0||Object.prototype.toString.call(e.type)!==`[object GeneratorFunction]`||Object.prototype.toString.call(u)!==`[object Generator]`)&&(Zv||console.error("Using Iterators as children is unsupported and will likely yield unexpected results because enumerating a generator mutates it. You may convert it to an array with `Array.from()` or the `[...spread]` operator before rendering. You can also use an Iterable that can iterate multiple times over the same items."),Zv=!0):a.entries!==l||Xv||(console.error(`Using Maps as children is not supported. Use an array of keyed ReactElements instead.`),Xv=!0),e=v(e,r,u,s),G=c,e}if(typeof a.then==`function`)return c=Gi(a._debugInfo),e=y(e,r,Ji(a),s),G=c,e;if(a.$$typeof===Uf)return y(e,r,li(e,a),s);Zi(e,a)}return typeof a==`string`&&a!==``||typeof a==`number`||typeof a==`bigint`?(c=``+a,r!==null&&r.tag===6?(n(e,r.sibling),s=i(r,c),s.return=e,e=s):(n(e,r),s=Mr(c,e.mode,s),s.return=e,s._debugOwner=e,s._debugTask=e._debugTask,s._debugInfo=G,e=s),o(e)):(typeof a==`function`&&$i(e,a),typeof a==`symbol`&&ta(e,a),n(e,r))}return function(e,t,n,r){var i=G;G=null;try{Yv=0;var a=y(e,t,n,r);return Jv=null,a}catch(t){if(t===Hv||t===Wv)throw t;var o=g(29,t,null,e.mode);o.lanes=r,o.return=e;var s=o._debugInfo=G;if(o._debugOwner=e._debugOwner,o._debugTask=e._debugTask,s!=null){for(var c=s.length-1;0<=c;c--)if(typeof s[c].stack==`string`){o._debugOwner=s[c],o._debugTask=s[c].debugTask;break}}return o}finally{G=i}}}function ra(e,t){var n=$f(e);return e=!n&&typeof oe(e)==`function`,n||e?(n=n?`array`:`iterable`,console.error(`A nested %s was passed to row #%s in <SuspenseList />. Wrap it in an additional SuspenseList to configure its revealOrder: <SuspenseList revealOrder=...> ... <SuspenseList revealOrder=...>{%s}</SuspenseList> ... </SuspenseList>`,n,t,n),!1):!0}function ia(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function aa(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function oa(e){return{lane:e,tag:ry,payload:null,callback:null,next:null}}function sa(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,ly===r&&!cy){var i=S(e);console.error(`An update (setState, replaceState, or forceUpdate) was scheduled from inside an update function. Update functions should be pure, with zero side-effects. Consider using componentDidUpdate or a callback.

Please update the following component: %s`,i),cy=!0}return(Y&Rb)===Lb?(hr(e,r,t,n),yr(e)):(i=r.pending,i===null?t.next=t:(t.next=i.next,i.next=t),r.pending=t,t=yr(e),vr(e,null,n),t)}function ca(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,n&4194048)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,We(e,n)}}function la(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var o={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};a===null?i=a=o:a=a.next=o,n=n.next}while(n!==null);a===null?i=a=t:a=a.next=t}else i=a=t;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:a,shared:r.shared,callbacks:r.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function ua(){if(uy){var e=dv;if(e!==null)throw e}}function da(e,t,n,r){uy=!1;var i=e.updateQueue;sy=!1,ly=i.shared;var a=i.firstBaseUpdate,o=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var c=s,l=c.next;c.next=null,o===null?a=l:o.next=l,o=c;var u=e.alternate;u!==null&&(u=u.updateQueue,s=u.lastBaseUpdate,s!==o&&(s===null?u.firstBaseUpdate=l:s.next=l,u.lastBaseUpdate=c))}if(a!==null){var d=i.baseState;o=0,u=l=c=null,s=a;do{var f=s.lane&-536870913,p=f!==s.lane;if(p?(Q&f)===f:(r&f)===f){f!==0&&f===uv&&(uy=!0),u!==null&&(u=u.next={lane:0,tag:s.tag,payload:s.payload,callback:null,next:null});a:{f=e;var m=s,h=t,g=n;switch(m.tag){case iy:if(m=m.payload,typeof m==`function`){h_=!0;var _=m.call(g,d,h);if(f.mode&Hg){E(!0);try{m.call(g,d,h)}finally{E(!1)}}h_=!1,d=_;break a}d=m;break a;case oy:f.flags=f.flags&-65537|128;case ry:if(_=m.payload,typeof _==`function`){if(h_=!0,m=_.call(g,d,h),f.mode&Hg){E(!0);try{_.call(g,d,h)}finally{E(!1)}}h_=!1}else m=_;if(m==null)break a;d=P({},d,m);break a;case ay:sy=!0}}f=s.callback,f!==null&&(e.flags|=64,p&&(e.flags|=8192),p=i.callbacks,p===null?i.callbacks=[f]:p.push(f))}else p={lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},u===null?(l=u=p,c=d):u=u.next=p,o|=f;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;p=s,s=p.next,p.next=null,i.lastBaseUpdate=p,i.shared.pending=null}}while(1);u===null&&(c=d),i.baseState=c,i.firstBaseUpdate=l,i.lastBaseUpdate=u,a===null&&(i.shared.lanes=0),lx|=o,e.lanes=o,e.memoizedState=d}ly=null}function fa(e,t){if(typeof e!=`function`)throw Error(`Invalid argument passed as callback. Expected a function. Instead received: `+e);e.call(t)}function pa(e,t){var n=e.shared.hiddenCallbacks;if(n!==null)for(e.shared.hiddenCallbacks=null,e=0;e<n.length;e++)fa(n[e],t)}function ma(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)fa(n[e],t)}function ha(e,t){var n=sx;C(fy,n,e),C(dy,t,e),sx=n|t.baseLanes}function ga(e){C(fy,sx,e),C(dy,dy.current,e)}function _a(e){sx=fy.current,le(dy,e),le(fy,e)}function va(e){var t=e.alternate;C(_y,_y.current&hy,e),C(py,e,e),my===null&&(t===null||dy.current!==null||t.memoizedState!==null)&&(my=e)}function ya(e){C(_y,_y.current,e),C(py,e,e),my===null&&(my=e)}function ba(e){e.tag===22?(C(_y,_y.current,e),C(py,e,e),my===null&&(my=e)):xa(e)}function xa(e){C(_y,_y.current,e),C(py,py.current,e)}function Sa(e){le(py,e),my===e&&(my=null),le(_y,e)}function Ca(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||bd(n)||xd(n)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder===`forwards`||t.memoizedProps.revealOrder===`backwards`||t.memoizedProps.revealOrder===`unstable_legacy-backwards`||t.memoizedProps.revealOrder===`together`)){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}function D(){var e=J;Ry===null?Ry=[e]:Ry.push(e)}function O(){var e=J;if(Ry!==null&&(zy++,Ry[zy]!==e)){var t=S(K);if(!wy.has(t)&&(wy.add(t),Ry!==null)){for(var n=``,r=0;r<=zy;r++){var i=Ry[r],a=r===zy?e:i;for(i=r+1+`. `+i;30>i.length;)i+=` `;i+=a+`
`,n+=i}console.error(`React has detected a change in the order of Hooks called by %s. This will lead to bugs and errors if not fixed. For more information, read the Rules of Hooks: https://react.dev/link/rules-of-hooks

   Previous render            Next render
   ------------------------------------------------------
%s   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
`,t,n)}}}function wa(e){e==null||$f(e)||console.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.",J,typeof e)}function Ta(){var e=S(K);Dy.has(e)||(Dy.add(e),console.error(`ReactDOM.useFormState has been renamed to React.useActionState. Please update %s to use React.useActionState.`,e))}function Ea(){throw Error(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.`)}function Da(e,t){if(By)return!1;if(t===null)return console.error(`%s received a final argument during this render, but not during the previous render. Even though the final argument is optional, its type cannot change between renders.`,J),!1;e.length!==t.length&&console.error(`The final argument passed to %s changed size between renders. The order and size of this array must remain constant.

Previous: %s
Incoming: %s`,J,`[`+t.join(`, `)+`]`,`[`+e.join(`, `)+`]`);for(var n=0;n<t.length&&n<e.length;n++)if(!Yh(e[n],t[n]))return!1;return!0}function Oa(e,t,n,r,i,a){Oy=a,K=t,Ry=e===null?null:e._debugHookTypes,zy=-1,By=e!==null&&e.type!==t.type,(Object.prototype.toString.call(n)===`[object AsyncFunction]`||Object.prototype.toString.call(n)===`[object AsyncGeneratorFunction]`)&&(a=S(K),Ey.has(a)||(Ey.add(a),console.error("%s is an async Client Component. Only Server Components can be async at the moment. This error is often caused by accidentally adding `'use client'` to a module that was originally written for the server.",a===null?`An unknown Component`:`<`+a+`>`))),t.memoizedState=null,t.updateQueue=null,t.lanes=0,F.H=e!==null&&e.memoizedState!==null?Wy:Ry===null?Hy:Uy,My=a=(t.mode&Hg)!==B;var o=Tv(n,r,i);if(My=!1,jy&&(o=Aa(t,n,r,i)),a){E(!0);try{o=Aa(t,n,r,i)}finally{E(!1)}}return ka(e,t),o}function ka(e,t){t._debugHookTypes=Ry,t.dependencies===null?Fy!==null&&(t.dependencies={lanes:0,firstContext:null,_debugThenableState:Fy}):t.dependencies._debugThenableState=Fy,F.H=Vy;var n=q!==null&&q.next!==null;if(Oy=0,Ry=J=ky=q=K=null,zy=-1,e!==null&&(e.flags&65011712)!=(t.flags&65011712)&&console.error(`Internal React error: Expected static flag was missing. Please notify the React team.`),Ay=!1,Py=0,Fy=null,n)throw Error(`Rendered fewer hooks than expected. This may be caused by an accidental early return statement.`);e===null||ub||(e=e.dependencies,e!==null&&oi(e)&&(ub=!0)),qv?(qv=!1,e=!0):e=!1,e&&(t=S(t)||`Unknown`,Ty.has(t)||Ey.has(t)||(Ty.add(t),console.error("`use` was called from inside a try/catch block. This is not allowed and can lead to unexpected behavior. To handle errors triggered by `use`, wrap your component in a error boundary.")))}function Aa(e,t,n,r){K=e;var i=0;do{if(jy&&(Fy=null),Py=0,jy=!1,i>=Ly)throw Error(`Too many re-renders. React limits the number of renders to prevent an infinite loop.`);if(i+=1,By=!1,ky=q=null,e.updateQueue!=null){var a=e.updateQueue;a.lastEffect=null,a.events=null,a.stores=null,a.memoCache!=null&&(a.memoCache.index=0)}zy=-1,F.H=Gy,a=Tv(t,n,r)}while(jy);return a}function ja(){var e=F.H,t=e.useState()[0];return t=typeof t.then==`function`?La(t):t,e=e.useState()[0],(q===null?null:q.memoizedState)!==e&&(K.flags|=1024),t}function Ma(){var e=Ny!==0;return Ny=0,e}function Na(e,t,n){t.updateQueue=e.updateQueue,t.flags=(t.mode&Ug)===B?t.flags&-2053:t.flags&-402655237,e.lanes&=~n}function Pa(e){if(Ay){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Ay=!1}Oy=0,Ry=ky=q=K=null,zy=-1,J=null,jy=!1,Py=Ny=0,Fy=null}function Fa(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return ky===null?K.memoizedState=ky=e:ky=ky.next=e,ky}function k(){if(q===null){var e=K.alternate;e=e===null?null:e.memoizedState}else e=q.next;var t=ky===null?K.memoizedState:ky.next;if(t!==null)ky=t,q=e;else{if(e===null)throw K.alternate===null?Error(`Update hook called on initial render. This is likely a bug in React. Please file an issue.`):Error(`Rendered more hooks than during the previous render.`);q=e,e={memoizedState:q.memoizedState,baseState:q.baseState,baseQueue:q.baseQueue,queue:q.queue,next:null},ky===null?K.memoizedState=ky=e:ky=ky.next=e}return ky}function Ia(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function La(e){var t=Py;return Py+=1,Fy===null&&(Fy=zi()),e=Vi(Fy,e,t),t=K,(ky===null?t.memoizedState:ky.next)===null&&(t=t.alternate,F.H=t!==null&&t.memoizedState!==null?Wy:Hy),e}function Ra(e){if(typeof e==`object`&&e){if(typeof e.then==`function`)return La(e);if(e.$$typeof===Uf)return ci(e)}throw Error(`An unsupported type was passed to use(): `+String(e))}function za(e){var t=null,n=K.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var r=K.alternate;r!==null&&(r=r.updateQueue,r!==null&&(r=r.memoCache,r!=null&&(t={data:r.data.map(function(e){return e.slice()}),index:0})))}if(t??={data:[],index:0},n===null&&(n=Ia(),K.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0||By)for(n=t.data[t.index]=Array(e),r=0;r<e;r++)n[r]=Xf;else n.length!==e&&console.error(`Expected a constant size argument for each invocation of useMemoCache. The previous cache was allocated with size %s but size %s was requested.`,n.length,e);return t.index++,n}function Ba(e,t){return typeof t==`function`?t(e):t}function Va(e,t,n){var r=Fa();if(n!==void 0){var i=n(t);if(My){E(!0);try{n(t)}finally{E(!1)}}}else i=t;return r.memoizedState=r.baseState=i,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:i},r.queue=e,e=e.dispatch=Xo.bind(null,K,e),[r.memoizedState,e]}function Ha(e){return Ua(k(),q,e)}function Ua(e,t,n){var r=e.queue;if(r===null)throw Error(`Should have a queue. You are likely calling Hooks conditionally, which is not allowed. (https://react.dev/link/invalid-hook-call)`);r.lastRenderedReducer=n;var i=e.baseQueue,a=r.pending;if(a!==null){if(i!==null){var o=i.next;i.next=a.next,a.next=o}t.baseQueue!==i&&console.error(`Internal error: Expected work-in-progress queue to be a clone. This is a bug in React.`),t.baseQueue=i=a,r.pending=null}if(a=e.baseState,i===null)e.memoizedState=a;else{t=i.next;var s=o=null,c=null,l=t,u=!1;do{var d=l.lane&-536870913;if(d===l.lane?(Oy&d)===d:(Q&d)===d){var f=l.revertLane;if(f===0)c!==null&&(c=c.next={lane:0,revertLane:0,gesture:null,action:l.action,hasEagerState:l.hasEagerState,eagerState:l.eagerState,next:null}),d===uv&&(u=!0);else if((Oy&f)===f){l=l.next,f===uv&&(u=!0);continue}else d={lane:0,revertLane:l.revertLane,gesture:null,action:l.action,hasEagerState:l.hasEagerState,eagerState:l.eagerState,next:null},c===null?(s=c=d,o=a):c=c.next=d,K.lanes|=f,lx|=f;d=l.action,My&&n(a,d),a=l.hasEagerState?l.eagerState:n(a,d)}else f={lane:d,revertLane:l.revertLane,gesture:l.gesture,action:l.action,hasEagerState:l.hasEagerState,eagerState:l.eagerState,next:null},c===null?(s=c=f,o=a):c=c.next=f,K.lanes|=d,lx|=d;l=l.next}while(l!==null&&l!==t);if(c===null?o=a:c.next=s,!Yh(a,e.memoizedState)&&(ub=!0,u&&(n=dv,n!==null)))throw n;e.memoizedState=a,e.baseState=o,e.baseQueue=c,r.lastRenderedState=a}return i===null&&(r.lanes=0),[e.memoizedState,r.dispatch]}function Wa(e){var t=k(),n=t.queue;if(n===null)throw Error(`Should have a queue. You are likely calling Hooks conditionally, which is not allowed. (https://react.dev/link/invalid-hook-call)`);n.lastRenderedReducer=e;var r=n.dispatch,i=n.pending,a=t.memoizedState;if(i!==null){n.pending=null;var o=i=i.next;do a=e(a,o.action),o=o.next;while(o!==i);Yh(a,t.memoizedState)||(ub=!0),t.memoizedState=a,t.baseQueue===null&&(t.baseState=a),n.lastRenderedState=a}return[a,r]}function Ga(e,t,n){var r=K,i=Fa();if(H){if(n===void 0)throw Error(`Missing getServerSnapshot, which is required for server-rendered content. Will revert to client rendering.`);var a=n();Cy||a===n()||(console.error(`The result of getServerSnapshot should be cached to avoid an infinite loop`),Cy=!0)}else{if(a=t(),Cy||(n=t(),Yh(a,n)||(console.error(`The result of getSnapshot should be cached to avoid an infinite loop`),Cy=!0)),X===null)throw Error(`Expected a work-in-progress root. This is a bug in React. Please file an issue.`);Q&127||qa(r,t,a)}return i.memoizedState=a,n={value:a,getSnapshot:t},i.queue=n,xo(Ya.bind(null,r,n,e),[e]),r.flags|=2048,_o(yy|Sy,{destroy:void 0},Ja.bind(null,r,n,a,t),null),a}function Ka(e,t,n){var r=K,i=k(),a=H;if(a){if(n===void 0)throw Error(`Missing getServerSnapshot, which is required for server-rendered content. Will revert to client rendering.`);n=n()}else if(n=t(),!Cy){var o=t();Yh(n,o)||(console.error(`The result of getSnapshot should be cached to avoid an infinite loop`),Cy=!0)}if((o=!Yh((q||i).memoizedState,n))&&(i.memoizedState=n,ub=!0),i=i.queue,bo(2048,Sy,Ya.bind(null,r,i,e),[e]),i.getSnapshot!==t||o||ky!==null&&ky.memoizedState.tag&yy){if(r.flags|=2048,_o(yy|Sy,{destroy:void 0},Ja.bind(null,r,i,n,t),null),X===null)throw Error(`Expected a work-in-progress root. This is a bug in React. Please file an issue.`);a||Oy&127||qa(r,t,n)}return n}function qa(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=K.updateQueue,t===null?(t=Ia(),K.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Ja(e,t,n,r){t.value=n,t.getSnapshot=r,Xa(t)&&Za(e)}function Ya(e,t,n){return n(function(){Xa(t)&&(mi(2,`updateSyncExternalStore()`,e),Za(e))})}function Xa(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Yh(e,n)}catch{return!0}}function Za(e){var t=_r(e,2);t!==null&&cl(t,e,2)}function Qa(e){var t=Fa();if(typeof e==`function`){var n=e;if(e=n(),My){E(!0);try{n()}finally{E(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ba,lastRenderedState:e},t}function $a(e){e=Qa(e);var t=e.queue,n=Zo.bind(null,K,t);return t.dispatch=n,[e.memoizedState,n]}function eo(e){var t=Fa();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=$o.bind(null,K,!0,n),n.dispatch=t,[e,t]}function to(e,t){return no(k(),q,e,t)}function no(e,t,n,r){return e.baseState=n,Ua(e,q,typeof r==`function`?r:Ba)}function ro(e,t){var n=k();return q===null?(n.baseState=e,[e,n.queue.dispatch]):no(n,q,e,t)}function io(e,t,n,r,i){if(es(e))throw Error(`Cannot update form state while rendering.`);if(e=t.action,e!==null){var a={payload:i,action:e,next:null,isTransition:!0,status:`pending`,value:null,reason:null,listeners:[],then:function(e){a.listeners.push(e)}};F.T===null?a.isTransition=!1:n(!0),r(a),n=t.pending,n===null?(a.next=t.pending=a,ao(t,a)):(a.next=n.next,t.pending=n.next=a)}}function ao(e,t){var n=t.action,r=t.payload,i=e.state;if(t.isTransition){var a=F.T,o={};o._updatedFibers=new Set,F.T=o;try{var s=n(i,r),c=F.S;c!==null&&c(o,s),oo(e,t,s)}catch(n){co(e,t,n)}finally{a!==null&&o.types!==null&&(a.types!==null&&a.types!==o.types&&console.error(`We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React.`),a.types=o.types),F.T=a,a===null&&o._updatedFibers&&(e=o._updatedFibers.size,o._updatedFibers.clear(),10<e&&console.warn(`Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.`))}}else try{o=n(i,r),oo(e,t,o)}catch(n){co(e,t,n)}}function oo(e,t,n){typeof n==`object`&&n&&typeof n.then==`function`?(F.asyncTransitions++,n.then(Ro,Ro),n.then(function(n){so(e,t,n)},function(n){return co(e,t,n)}),t.isTransition||console.error("An async function with useActionState was called outside of a transition. This is likely not what you intended (for example, isPending will not update correctly). Either call the returned function inside startTransition, or pass it to an `action` or `formAction` prop.")):so(e,t,n)}function so(e,t,n){t.status=`fulfilled`,t.value=n,lo(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,ao(e,n)))}function co(e,t,n){var r=e.pending;if(e.pending=null,r!==null){r=r.next;do t.status=`rejected`,t.reason=n,lo(t),t=t.next;while(t!==r)}e.action=null}function lo(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function uo(e,t){return t}function fo(e,t){if(H){var n=X.formState;if(n!==null){a:{var r=K;if(H){if(i_){b:{for(var i=i_,a=c_;i.nodeType!==8;){if(!a){i=null;break b}if(i=Cd(i.nextSibling),i===null){i=null;break b}}a=i.data,i=a===BS||a===VS?i:null}if(i){i_=Cd(i.nextSibling),r=i.data===BS;break a}}Kr(r)}r=!1}r&&(t=n[0])}}return n=Fa(),n.memoizedState=n.baseState=t,r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:uo,lastRenderedState:t},n.queue=r,n=Zo.bind(null,K,r),r.dispatch=n,r=Qa(!1),a=$o.bind(null,K,!1,r.queue),r=Fa(),i={state:t,dispatch:null,action:e,pending:null},r.queue=i,n=io.bind(null,K,i,a,n),i.dispatch=n,r.memoizedState=e,[t,n,!1]}function po(e){return mo(k(),q,e)}function mo(e,t,n){if(t=Ua(e,t,uo)[0],e=Ha(Ba)[0],typeof t==`object`&&t&&typeof t.then==`function`)try{var r=La(t)}catch(e){throw e===Hv?Wv:e}else r=t;t=k();var i=t.queue,a=i.dispatch;return n!==t.memoizedState&&(K.flags|=2048,_o(yy|Sy,{destroy:void 0},ho.bind(null,i,n),null)),[r,a,e]}function ho(e,t){e.action=t}function go(e){var t=k(),n=q;if(n!==null)return mo(t,n,e);k(),t=t.memoizedState,n=k();var r=n.queue.dispatch;return n.memoizedState=e,[t,r,!1]}function _o(e,t,n,r){return e={tag:e,create:n,deps:r,inst:t,next:null},t=K.updateQueue,t===null&&(t=Ia(),K.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e),e}function vo(e){var t=Fa();return e={current:e},t.memoizedState=e}function yo(e,t,n,r){var i=Fa();K.flags|=e,i.memoizedState=_o(yy|t,{destroy:void 0},n,r===void 0?null:r)}function bo(e,t,n,r){var i=k();r=r===void 0?null:r;var a=i.memoizedState.inst;q!==null&&r!==null&&Da(r,q.memoizedState.deps)?i.memoizedState=_o(t,a,n,r):(K.flags|=e,i.memoizedState=_o(yy|t,a,n,r))}function xo(e,t){(K.mode&Ug)===B?yo(8390656,Sy,e,t):yo(276826112,Sy,e,t)}function So(e){K.flags|=4;var t=K.updateQueue;if(t===null)t=Ia(),K.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function Co(e){var t=Fa(),n={impl:e};return t.memoizedState=n,function(){if((Y&Rb)!==Lb)throw Error(`A function wrapped in useEffectEvent can't be called during rendering.`);return n.impl.apply(void 0,arguments)}}function wo(e){var t=k().memoizedState;return So({ref:t,nextImpl:e}),function(){if((Y&Rb)!==Lb)throw Error(`A function wrapped in useEffectEvent can't be called during rendering.`);return t.impl.apply(void 0,arguments)}}function To(e,t){var n=4194308;return(K.mode&Ug)!==B&&(n|=134217728),yo(n,xy,e,t)}function Eo(e,t){if(typeof t==`function`){e=e();var n=t(e);return function(){typeof n==`function`?n():t(null)}}if(t!=null)return t.hasOwnProperty(`current`)||console.error(`Expected useImperativeHandle() first argument to either be a ref callback or React.createRef() object. Instead received: %s.`,`an object with keys {`+Object.keys(t).join(`, `)+`}`),e=e(),t.current=e,function(){t.current=null}}function Do(e,t,n){typeof t!=`function`&&console.error(`Expected useImperativeHandle() second argument to be a function that creates a handle. Instead received: %s.`,t===null?`null`:typeof t),n=n==null?null:n.concat([e]);var r=4194308;(K.mode&Ug)!==B&&(r|=134217728),yo(r,xy,Eo.bind(null,t,e),n)}function Oo(e,t,n){typeof t!=`function`&&console.error(`Expected useImperativeHandle() second argument to be a function that creates a handle. Instead received: %s.`,t===null?`null`:typeof t),n=n==null?null:n.concat([e]),bo(4,xy,Eo.bind(null,t,e),n)}function ko(e,t){return Fa().memoizedState=[e,t===void 0?null:t],e}function Ao(e,t){var n=k();t=t===void 0?null:t;var r=n.memoizedState;return t!==null&&Da(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function jo(e,t){var n=Fa();t=t===void 0?null:t;var r=e();if(My){E(!0);try{e()}finally{E(!1)}}return n.memoizedState=[r,t],r}function Mo(e,t){var n=k();t=t===void 0?null:t;var r=n.memoizedState;if(t!==null&&Da(t,r[1]))return r[0];if(r=e(),My){E(!0);try{e()}finally{E(!1)}}return n.memoizedState=[r,t],r}function No(e,t){return Io(Fa(),e,t)}function Po(e,t){return Lo(k(),q.memoizedState,e,t)}function Fo(e,t){var n=k();return q===null?Io(n,e,t):Lo(n,q.memoizedState,e,t)}function Io(e,t,n){return n===void 0||Oy&1073741824&&!(Q&261930)?e.memoizedState=t:(e.memoizedState=n,e=sl(),K.lanes|=e,lx|=e,n)}function Lo(e,t,n,r){return Yh(n,t)?n:dy.current===null?!(Oy&42)||Oy&1073741824&&!(Q&261930)?(ub=!0,e.memoizedState=n):(e=sl(),K.lanes|=e,lx|=e,t):(e=Io(e,n,r),Yh(e,t)||(ub=!0),e)}function Ro(){F.asyncTransitions--}function zo(e,t,n,r,i){var a=I.p;I.p=a!==0&&a<qp?a:qp;var o=F.T,s={};s._updatedFibers=new Set,F.T=s,$o(e,!1,t,n);try{var c=i(),l=F.S;if(l!==null&&l(s,c),typeof c==`object`&&c&&typeof c.then==`function`){F.asyncTransitions++,c.then(Ro,Ro);var u=Fi(c,r);Qo(e,t,u,ol(e))}else Qo(e,t,r,ol(e))}catch(n){Qo(e,t,{then:function(){},status:`rejected`,reason:n},ol(e))}finally{I.p=a,o!==null&&s.types!==null&&(o.types!==null&&o.types!==s.types&&console.error(`We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React.`),o.types=s.types),F.T=o,o===null&&s._updatedFibers&&(e=s._updatedFibers.size,s._updatedFibers.clear(),10<e&&console.warn(`Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.`))}}function Bo(e,t,n,r){if(e.tag!==5)throw Error(`Expected the form instance to be a HostComponent. This is a bug in React.`);var i=Vo(e).queue;hi(e),zo(e,i,t,bC,n===null?d:function(){return Ho(e),n(r)})}function Vo(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:bC,baseState:bC,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ba,lastRenderedState:bC},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ba,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function Ho(e){F.T===null&&console.error(`requestFormReset was called outside a transition or action. To fix, move to an action, or wrap with startTransition.`);var t=Vo(e);t.next===null&&(t=e.alternate.memoizedState),Qo(e,t.next.queue,{},ol(e))}function Uo(){var e=Qa(!1);return e=zo.bind(null,K,e.queue,!0,!1),Fa().memoizedState=e,[!1,e]}function Wo(){var e=Ha(Ba)[0],t=k().memoizedState;return[typeof e==`boolean`?e:La(e),t]}function Go(){var e=Wa(Ba)[0],t=k().memoizedState;return[typeof e==`boolean`?e:La(e),t]}function Ko(){return ci(xC)}function qo(){var e=Fa(),t=X.identifierPrefix;if(H){var n=n_,r=t_;n=(r&~(1<<32-Bp(r)-1)).toString(32)+n,t=`_`+t+`R_`+n,n=Ny++,0<n&&(t+=`H`+n.toString(32)),t+=`_`}else n=Iy++,t=`_`+t+`r_`+n.toString(32)+`_`;return e.memoizedState=t}function Jo(){return Fa().memoizedState=Yo.bind(null,K)}function Yo(e,t){for(var n=e.return;n!==null;){switch(n.tag){case 24:case 3:var r=ol(n),i=oa(r),a=sa(n,i,r);a!==null&&(mi(r,`refresh()`,e),cl(a,n,r),ca(a,n,r)),e=di(),t!=null&&a!==null&&console.error(`The seed argument is not enabled outside experimental channels.`),i.payload={cache:e};return}n=n.return}}function Xo(e,t,n){var r=arguments;typeof r[3]==`function`&&console.error(`State updates from the useState() and useReducer() Hooks don't support the second callback argument. To execute a side effect after rendering, declare it in the component body with useEffect().`),r=ol(e);var i={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};es(e)?ts(t,i):(i=gr(e,t,i,r),i!==null&&(mi(r,`dispatch()`,e),cl(i,e,r),ns(i,t,r)))}function Zo(e,t,n){var r=arguments;typeof r[3]==`function`&&console.error(`State updates from the useState() and useReducer() Hooks don't support the second callback argument. To execute a side effect after rendering, declare it in the component body with useEffect().`),r=ol(e),Qo(e,t,n,r)&&mi(r,`setState()`,e)}function Qo(e,t,n,r){var i={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(es(e))ts(t,i);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=t.lastRenderedReducer,a!==null)){var o=F.H;F.H=qy;try{var s=t.lastRenderedState,c=a(s,n);if(i.hasEagerState=!0,i.eagerState=c,Yh(c,s))return hr(e,t,i,0),X===null&&mr(),!1}catch{}finally{F.H=o}}if(n=gr(e,t,i,r),n!==null)return cl(n,e,r),ns(n,t,r),!0}return!1}function $o(e,t,n,r){if(F.T===null&&uv===0&&console.error(`An optimistic state update occurred outside a transition or action. To fix, move the update to an action, or wrap with startTransition.`),r={lane:2,revertLane:lu(),gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},es(e)){if(t)throw Error(`Cannot update optimistic state while rendering.`);console.error(`Cannot call startTransition while rendering.`)}else t=gr(e,n,r,2),t!==null&&(mi(2,`setOptimistic()`,e),cl(t,e,2))}function es(e){var t=e.alternate;return e===K||t!==null&&t===K}function ts(e,t){jy=Ay=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function ns(e,t,n){if(n&4194048){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,We(e,n)}}function rs(e){if(e!==null&&typeof e!=`function`){var t=String(e);ab.has(t)||(ab.add(t),console.error("Expected the last optional `callback` argument to be a function. Instead received: %s.",e))}}function is(e,t,n,r){var i=e.memoizedState,a=n(r,i);if(e.mode&Hg){E(!0);try{a=n(r,i)}finally{E(!1)}}a===void 0&&(t=x(t)||`Component`,tb.has(t)||(tb.add(t),console.error(`%s.getDerivedStateFromProps(): A valid state object (or null) must be returned. You have returned undefined.`,t))),i=a==null?i:P({},i,a),e.memoizedState=i,e.lanes===0&&(e.updateQueue.baseState=i)}function as(e,t,n,r,i,a,o){var s=e.stateNode;if(typeof s.shouldComponentUpdate==`function`){if(n=s.shouldComponentUpdate(r,a,o),e.mode&Hg){E(!0);try{n=s.shouldComponentUpdate(r,a,o)}finally{E(!1)}}return n===void 0&&console.error(`%s.shouldComponentUpdate(): Returned undefined instead of a boolean value. Make sure to return true or false.`,x(t)||`Component`),n}return t.prototype&&t.prototype.isPureReactComponent?!Bn(n,r)||!Bn(i,a):!0}function os(e,t,n,r){var i=t.state;typeof t.componentWillReceiveProps==`function`&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps==`function`&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==i&&(e=S(e)||`Component`,Xy.has(e)||(Xy.add(e),console.error(`%s.componentWillReceiveProps(): Assigning directly to this.state is deprecated (except inside a component's constructor). Use setState instead.`,e)),ob.enqueueReplaceState(t,t.state,null))}function ss(e,t){var n=t;if(`ref`in t)for(var r in n={},t)r!==`ref`&&(n[r]=t[r]);if(e=e.defaultProps)for(var i in n===t&&(n=P({},n)),e)n[i]===void 0&&(n[i]=e[i]);return n}function cs(e){_g(e),console.warn(`%s

%s
`,sb?`An error occurred in the <`+sb+`> component.`:`An error occurred in one of your React components.`,`Consider adding an error boundary to your tree to customize error handling behavior.
Visit https://react.dev/link/error-boundaries to learn more about error boundaries.`)}function ls(e){var t=sb?`The above error occurred in the <`+sb+`> component.`:`The above error occurred in one of your React components.`,n=`React will try to recreate this component tree from scratch using the error boundary you provided, `+((cb||`Anonymous`)+`.`);if(typeof e==`object`&&e&&typeof e.environmentName==`string`){var r=e.environmentName;e=[`%o

%s

%s
`,e,t,n].slice(0),typeof e[0]==`string`?e.splice(0,1,SC+` `+e[0],CC,TC+r+TC,wC):e.splice(0,0,SC,CC,TC+r+TC,wC),e.unshift(console),r=EC.apply(console.error,e),r()}else console.error(`%o

%s

%s
`,e,t,n)}function us(e){_g(e)}function ds(e,t){try{sb=t.source?S(t.source):null,cb=null;var n=t.value;if(F.actQueue!==null)F.thrownErrors.push(n);else{var r=e.onUncaughtError;r(n,{componentStack:t.stack})}}catch(e){setTimeout(function(){throw e})}}function fs(e,t,n){try{sb=n.source?S(n.source):null,cb=S(t);var r=e.onCaughtError;r(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(e){setTimeout(function(){throw e})}}function ps(e,t,n){return n=oa(n),n.tag=oy,n.payload={element:null},n.callback=function(){w(t.source,ds,e,t)},n}function ms(e){return e=oa(e),e.tag=oy,e}function hs(e,t,n,r){var i=n.type.getDerivedStateFromError;if(typeof i==`function`){var a=r.value;e.payload=function(){return i(a)},e.callback=function(){Cr(n),w(r.source,fs,t,n,r)}}var o=n.stateNode;o!==null&&typeof o.componentDidCatch==`function`&&(e.callback=function(){Cr(n),w(r.source,fs,t,n,r),typeof i!=`function`&&(wx===null?wx=new Set([this]):wx.add(this)),Nv(this,r),typeof i==`function`||!(n.lanes&2)&&console.error(`%s: Error boundaries should implement getDerivedStateFromError(). In that method, return a state update to display an error message or fallback UI.`,S(n)||`Unknown`)})}function gs(e,t,n,r,i){if(n.flags|=32768,zp&&Zl(e,i),typeof r==`object`&&r&&typeof r.then==`function`){if(t=n.alternate,t!==null&&ai(t,n,i,!0),H&&(a_=!0),n=py.current,n!==null){switch(n.tag){case 31:case 13:return my===null?Sl():n.alternate===null&&cx===Bb&&(cx=Ub),n.flags&=-257,n.flags|=65536,n.lanes=i,r===Gv?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([r]):t.add(r),Hl(e,r,i)),!1;case 22:return n.flags|=65536,r===Gv?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([r])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([r]):n.add(r)),Hl(e,r,i)),!1}throw Error(`Unexpected Suspense handler tag (`+n.tag+`). This is a bug in React.`)}return Hl(e,r,i),Sl(),!1}if(H)return a_=!0,t=py.current,t===null?(r!==l_&&Qr(Fr(Error(`There was an error while hydrating but React was able to recover by instead client rendering the entire root.`,{cause:r}),n)),e=e.current.alternate,e.flags|=65536,i&=-i,e.lanes|=i,r=Fr(r,n),i=ps(e.stateNode,r,i),la(e,i),cx!==Wb&&(cx=Hb)):(!(t.flags&65536)&&(t.flags|=256),t.flags|=65536,t.lanes=i,r!==l_&&Qr(Fr(Error(`There was an error while hydrating but React was able to recover by instead client rendering from the nearest Suspense boundary.`,{cause:r}),n))),!1;var a=Fr(Error(`There was an error during concurrent rendering but React was able to recover by instead synchronously rendering the entire root.`,{cause:r}),n);if(mx===null?mx=[a]:mx.push(a),cx!==Wb&&(cx=Hb),t===null)return!0;r=Fr(r,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=i&-i,n.lanes|=e,e=ps(n.stateNode,r,e),la(n,e),!1;case 1:if(t=n.type,a=n.stateNode,!(n.flags&128)&&(typeof t.getDerivedStateFromError==`function`||a!==null&&typeof a.componentDidCatch==`function`&&(wx===null||!wx.has(a))))return n.flags|=65536,i&=-i,n.lanes|=i,i=ms(i),hs(i,e,n,r),la(n,i),!1}n=n.return}while(n!==null);return!1}function _s(e,t,n,r){t.child=e===null?ny(t,null,n,r):ty(t,e.child,n,r)}function vs(e,t,n,r,i){n=n.render;var a=t.ref;if(`ref`in r){var o={};for(var s in r)s!==`ref`&&(o[s]=r[s])}else o=r;return si(t),r=Oa(e,t,n,o,a,i),s=Ma(),e!==null&&!ub?(Na(e,t,i),Hs(e,t,i)):(H&&s&&Rr(t),t.flags|=1,_s(e,t,r,i),t.child)}function ys(e,t,n,r,i){if(e===null){var a=n.type;return typeof a==`function`&&!Er(a)&&a.defaultProps===void 0&&n.compare===null?(n=br(a),t.tag=15,t.type=n,Ms(t,a),bs(e,t,n,r,i)):(e=kr(n.type,null,r,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(a=e.child,!Us(e,i)){var o=a.memoizedProps;if(n=n.compare,n=n===null?Bn:n,n(o,r)&&e.ref===t.ref)return Hs(e,t,i)}return t.flags|=1,e=Dr(a,r),e.ref=t.ref,e.return=t,t.child=e}function bs(e,t,n,r,i){if(e!==null){var a=e.memoizedProps;if(Bn(a,r)&&e.ref===t.ref&&t.type===e.type)if(ub=!1,t.pendingProps=r=a,Us(e,i))e.flags&131072&&(ub=!0);else return t.lanes=e.lanes,Hs(e,t,i)}return Os(e,t,n,r,i)}function xs(e,t,n,r){var i=r.children,a=e===null?null:e.memoizedState;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:Ng,_pendingMarkers:null,_retryCache:null,_transitions:null}),r.mode===`hidden`){if(t.flags&128){if(a=a===null?n:a.baseLanes|n,e!==null){for(r=t.child=e.child,i=0;r!==null;)i=i|r.lanes|r.childLanes,r=r.sibling;r=i&~a}else r=0,t.child=null;return Cs(e,t,a,n,r)}if(n&536870912)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&Li(t,a===null?null:a.cachePool),a===null?ga(t):ha(t,a),ba(t);else return r=t.lanes=536870912,Cs(e,t,a===null?n:a.baseLanes|n,n,r)}else a===null?(e!==null&&Li(t,null),ga(t),xa(t)):(Li(t,a.cachePool),ha(t,a),xa(t),t.memoizedState=null);return _s(e,t,i,n),t.child}function Ss(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:Ng,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Cs(e,t,n,r,i){var a=Ii();return a=a===null?null:{parent:y_._currentValue,pool:a},t.memoizedState={baseLanes:n,cachePool:a},e!==null&&Li(t,null),ga(t),ba(t),e!==null&&ai(e,t,r,!0),t.childLanes=i,null}function ws(e,t){var n=t.hidden;return n!==void 0&&console.error(`<Activity> doesn't accept a hidden prop. Use mode="hidden" instead.
- <Activity %s>
+ <Activity %s>`,!0===n?`hidden`:!1===n?`hidden={false}`:`hidden={...}`,n?`mode="hidden"`:`mode="visible"`),t=Ls({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function Ts(e,t,n){return ty(t,e.child,null,n),e=ws(t,t.pendingProps),e.flags|=2,Sa(t),t.memoizedState=null,e}function Es(e,t,n){var r=t.pendingProps,i=(t.flags&128)!=0;if(t.flags&=-129,e===null){if(H){if(r.mode===`hidden`)return e=ws(t,r),t.lanes=536870912,Ss(null,e);if(ya(t),(e=i_)?(n=yd(e,c_),n=n!==null&&n.data===AS?n:null,n!==null&&(r={dehydrated:n,treeContext:Br(),retryLane:536870912,hydrationErrors:null},t.memoizedState=r,r=Nr(n),r.return=t,t.child=r,r_=t,i_=null)):n=null,n===null)throw Gr(t,e),Kr(t);return t.lanes=536870912,null}return ws(t,r)}var a=e.memoizedState;if(a!==null){var o=a.dehydrated;if(ya(t),i)if(t.flags&256)t.flags&=-257,t=Ts(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(`Client rendering an Activity suspended it again. This is a bug in React.`);else if(Wr(),n&536870912&&xl(t),ub||ai(e,t,n,!1),i=(n&e.childLanes)!==0,ub||i){if(r=X,r!==null&&(o=Ge(r,n),o!==0&&o!==a.retryLane))throw a.retryLane=o,_r(e,o),cl(r,e,o),lb;Sl(),t=Ts(e,t,n)}else e=a.treeContext,i_=Cd(o.nextSibling),r_=t,H=!0,s_=null,a_=!1,o_=null,c_=!1,e!==null&&Vr(t,e),t=ws(t,r),t.flags|=4096;return t}return a=e.child,r={mode:r.mode,children:r.children},n&536870912&&(n&e.lanes)!==0&&xl(t),e=Dr(a,r),e.ref=t.ref,t.child=e,e.return=t,e}function Ds(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!=`function`&&typeof n!=`object`)throw Error(`Expected ref to be a function, an object returned by React.createRef(), or undefined/null.`);(e===null||e.ref!==n)&&(t.flags|=4194816)}}function Os(e,t,n,r,i){if(n.prototype&&typeof n.prototype.render==`function`){var a=x(n)||`Unknown`;db[a]||(console.error(`The <%s /> component appears to have a render method, but doesn't extend React.Component. This is likely to cause errors. Change %s to extend React.Component instead.`,a,a),db[a]=!0)}return t.mode&Hg&&mv.recordLegacyContextWarning(t,null),e===null&&(Ms(t,t.type),n.contextTypes&&(a=x(n)||`Unknown`,pb[a]||(pb[a]=!0,console.error(`%s uses the legacy contextTypes API which was removed in React 19. Use React.createContext() with React.useContext() instead. (https://react.dev/link/legacy-context)`,a)))),si(t),n=Oa(e,t,n,r,void 0,i),r=Ma(),e!==null&&!ub?(Na(e,t,i),Hs(e,t,i)):(H&&r&&Rr(t),t.flags|=1,_s(e,t,n,i),t.child)}function ks(e,t,n,r,i,a){return si(t),zy=-1,By=e!==null&&e.type!==t.type,t.updateQueue=null,n=Aa(t,r,n,i),ka(e,t),r=Ma(),e!==null&&!ub?(Na(e,t,a),Hs(e,t,a)):(H&&r&&Rr(t),t.flags|=1,_s(e,t,n,a),t.child)}function As(e,t,n,r,i){switch(s(t)){case!1:var a=t.stateNode,o=new t.type(t.memoizedProps,a.context).state;a.updater.enqueueSetState(a,o,null);break;case!0:t.flags|=128,t.flags|=65536,a=Error(`Simulated error coming from DevTools`);var c=i&-i;if(t.lanes|=c,o=X,o===null)throw Error(`Expected a work-in-progress root. This is a bug in React. Please file an issue.`);c=ms(c),hs(c,o,t,Fr(a,t)),la(t,c)}if(si(t),t.stateNode===null){if(o=Rg,a=n.contextType,`contextType`in n&&a!==null&&(a===void 0||a.$$typeof!==Uf)&&!ib.has(n)&&(ib.add(n),c=a===void 0?` However, it is set to undefined. This can be caused by a typo or by mixing up named and default imports. This can also happen due to a circular dependency, so try moving the createContext() call to a separate file.`:typeof a==`object`?a.$$typeof===Hf?` Did you accidentally pass the Context.Consumer instead?`:` However, it is set to an object with keys {`+Object.keys(a).join(`, `)+`}.`:` However, it is set to a `+typeof a+`.`,console.error(`%s defines an invalid contextType. contextType should point to the Context object returned by React.createContext().%s`,x(n)||`Component`,c)),typeof a==`object`&&a&&(o=ci(a)),a=new n(r,o),t.mode&Hg){E(!0);try{a=new n(r,o)}finally{E(!1)}}if(o=t.memoizedState=a.state!==null&&a.state!==void 0?a.state:null,a.updater=ob,t.stateNode=a,a._reactInternals=t,a._reactInternalInstance=Yy,typeof n.getDerivedStateFromProps==`function`&&o===null&&(o=x(n)||`Component`,Zy.has(o)||(Zy.add(o),console.error("`%s` uses `getDerivedStateFromProps` but its initial state is %s. This is not recommended. Instead, define the initial state by assigning an object to `this.state` in the constructor of `%s`. This ensures that `getDerivedStateFromProps` arguments have a consistent shape.",o,a.state===null?`null`:`undefined`,o))),typeof n.getDerivedStateFromProps==`function`||typeof a.getSnapshotBeforeUpdate==`function`){var l=c=o=null;if(typeof a.componentWillMount==`function`&&!0!==a.componentWillMount.__suppressDeprecationWarning?o=`componentWillMount`:typeof a.UNSAFE_componentWillMount==`function`&&(o=`UNSAFE_componentWillMount`),typeof a.componentWillReceiveProps==`function`&&!0!==a.componentWillReceiveProps.__suppressDeprecationWarning?c=`componentWillReceiveProps`:typeof a.UNSAFE_componentWillReceiveProps==`function`&&(c=`UNSAFE_componentWillReceiveProps`),typeof a.componentWillUpdate==`function`&&!0!==a.componentWillUpdate.__suppressDeprecationWarning?l=`componentWillUpdate`:typeof a.UNSAFE_componentWillUpdate==`function`&&(l=`UNSAFE_componentWillUpdate`),o!==null||c!==null||l!==null){a=x(n)||`Component`;var u=typeof n.getDerivedStateFromProps==`function`?`getDerivedStateFromProps()`:`getSnapshotBeforeUpdate()`;$y.has(a)||($y.add(a),console.error(`Unsafe legacy lifecycles will not be called for components using new component APIs.

%s uses %s but also contains the following legacy lifecycles:%s%s%s

The above lifecycles should be removed. Learn more about this warning here:
https://react.dev/link/unsafe-component-lifecycles`,a,u,o===null?``:`
  `+o,c===null?``:`
  `+c,l===null?``:`
  `+l))}}a=t.stateNode,o=x(n)||`Component`,a.render||(n.prototype&&typeof n.prototype.render==`function`?console.error("No `render` method found on the %s instance: did you accidentally return an object from the constructor?",o):console.error("No `render` method found on the %s instance: you may have forgotten to define `render`.",o)),!a.getInitialState||a.getInitialState.isReactClassApproved||a.state||console.error(`getInitialState was defined on %s, a plain JavaScript class. This is only supported for classes created using React.createClass. Did you mean to define a state property instead?`,o),a.getDefaultProps&&!a.getDefaultProps.isReactClassApproved&&console.error(`getDefaultProps was defined on %s, a plain JavaScript class. This is only supported for classes created using React.createClass. Use a static property to define defaultProps instead.`,o),a.contextType&&console.error(`contextType was defined as an instance property on %s. Use a static property to define contextType instead.`,o),n.childContextTypes&&!rb.has(n)&&(rb.add(n),console.error(`%s uses the legacy childContextTypes API which was removed in React 19. Use React.createContext() instead. (https://react.dev/link/legacy-context)`,o)),n.contextTypes&&!nb.has(n)&&(nb.add(n),console.error(`%s uses the legacy contextTypes API which was removed in React 19. Use React.createContext() with static contextType instead. (https://react.dev/link/legacy-context)`,o)),typeof a.componentShouldUpdate==`function`&&console.error(`%s has a method called componentShouldUpdate(). Did you mean shouldComponentUpdate()? The name is phrased as a question because the function is expected to return a value.`,o),n.prototype&&n.prototype.isPureReactComponent&&a.shouldComponentUpdate!==void 0&&console.error(`%s has a method called shouldComponentUpdate(). shouldComponentUpdate should not be used when extending React.PureComponent. Please extend React.Component if shouldComponentUpdate is used.`,x(n)||`A pure component`),typeof a.componentDidUnmount==`function`&&console.error(`%s has a method called componentDidUnmount(). But there is no such lifecycle method. Did you mean componentWillUnmount()?`,o),typeof a.componentDidReceiveProps==`function`&&console.error(`%s has a method called componentDidReceiveProps(). But there is no such lifecycle method. If you meant to update the state in response to changing props, use componentWillReceiveProps(). If you meant to fetch data or run side-effects or mutations after React has updated the UI, use componentDidUpdate().`,o),typeof a.componentWillRecieveProps==`function`&&console.error(`%s has a method called componentWillRecieveProps(). Did you mean componentWillReceiveProps()?`,o),typeof a.UNSAFE_componentWillRecieveProps==`function`&&console.error(`%s has a method called UNSAFE_componentWillRecieveProps(). Did you mean UNSAFE_componentWillReceiveProps()?`,o),c=a.props!==r,a.props!==void 0&&c&&console.error("When calling super() in `%s`, make sure to pass up the same props that your component's constructor was passed.",o),a.defaultProps&&console.error(`Setting defaultProps as an instance property on %s is not supported and will be ignored. Instead, define defaultProps as a static property on %s.`,o,o),typeof a.getSnapshotBeforeUpdate!=`function`||typeof a.componentDidUpdate==`function`||Qy.has(n)||(Qy.add(n),console.error(`%s: getSnapshotBeforeUpdate() should be used with componentDidUpdate(). This component defines getSnapshotBeforeUpdate() only.`,x(n))),typeof a.getDerivedStateFromProps==`function`&&console.error(`%s: getDerivedStateFromProps() is defined as an instance method and will be ignored. Instead, declare it as a static method.`,o),typeof a.getDerivedStateFromError==`function`&&console.error(`%s: getDerivedStateFromError() is defined as an instance method and will be ignored. Instead, declare it as a static method.`,o),typeof n.getSnapshotBeforeUpdate==`function`&&console.error(`%s: getSnapshotBeforeUpdate() is defined as a static method and will be ignored. Instead, declare it as an instance method.`,o),(c=a.state)&&(typeof c!=`object`||$f(c))&&console.error(`%s.state: must be set to an object or null`,o),typeof a.getChildContext==`function`&&typeof n.childContextTypes!=`object`&&console.error(`%s.getChildContext(): childContextTypes must be defined in order to use getChildContext().`,o),a=t.stateNode,a.props=r,a.state=t.memoizedState,a.refs={},ia(t),o=n.contextType,a.context=typeof o==`object`&&o?ci(o):Rg,a.state===r&&(o=x(n)||`Component`,eb.has(o)||(eb.add(o),console.error(`%s: It is not recommended to assign props directly to state because updates to props won't be reflected in state. In most cases, it is better to use props directly.`,o))),t.mode&Hg&&mv.recordLegacyContextWarning(t,a),mv.recordUnsafeLifecycleWarnings(t,a),a.state=t.memoizedState,o=n.getDerivedStateFromProps,typeof o==`function`&&(is(t,n,o,r),a.state=t.memoizedState),typeof n.getDerivedStateFromProps==`function`||typeof a.getSnapshotBeforeUpdate==`function`||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(o=a.state,typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount(),o!==a.state&&(console.error(`%s.componentWillMount(): Assigning directly to this.state is deprecated (except inside a component's constructor). Use setState instead.`,S(t)||`Component`),ob.enqueueReplaceState(a,a.state,null)),da(t,r,a,i),ua(),a.state=t.memoizedState),typeof a.componentDidMount==`function`&&(t.flags|=4194308),(t.mode&Ug)!==B&&(t.flags|=134217728),a=!0}else if(e===null){a=t.stateNode;var d=t.memoizedProps;c=ss(n,d),a.props=c;var f=a.context;l=n.contextType,o=Rg,typeof l==`object`&&l&&(o=ci(l)),u=n.getDerivedStateFromProps,l=typeof u==`function`||typeof a.getSnapshotBeforeUpdate==`function`,d=t.pendingProps!==d,l||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(d||f!==o)&&os(t,a,r,o),sy=!1;var p=t.memoizedState;a.state=p,da(t,r,a,i),ua(),f=t.memoizedState,d||p!==f||sy?(typeof u==`function`&&(is(t,n,u,r),f=t.memoizedState),(c=sy||as(t,n,c,r,p,f,o))?(l||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount()),typeof a.componentDidMount==`function`&&(t.flags|=4194308),(t.mode&Ug)!==B&&(t.flags|=134217728)):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),(t.mode&Ug)!==B&&(t.flags|=134217728),t.memoizedProps=r,t.memoizedState=f),a.props=r,a.state=f,a.context=o,a=c):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),(t.mode&Ug)!==B&&(t.flags|=134217728),a=!1)}else{a=t.stateNode,aa(e,t),o=t.memoizedProps,l=ss(n,o),a.props=l,u=t.pendingProps,p=a.context,f=n.contextType,c=Rg,typeof f==`object`&&f&&(c=ci(f)),d=n.getDerivedStateFromProps,(f=typeof d==`function`||typeof a.getSnapshotBeforeUpdate==`function`)||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(o!==u||p!==c)&&os(t,a,r,c),sy=!1,p=t.memoizedState,a.state=p,da(t,r,a,i),ua();var m=t.memoizedState;o!==u||p!==m||sy||e!==null&&e.dependencies!==null&&oi(e.dependencies)?(typeof d==`function`&&(is(t,n,d,r),m=t.memoizedState),(l=sy||as(t,n,l,r,p,m,c)||e!==null&&e.dependencies!==null&&oi(e.dependencies))?(f||typeof a.UNSAFE_componentWillUpdate!=`function`&&typeof a.componentWillUpdate!=`function`||(typeof a.componentWillUpdate==`function`&&a.componentWillUpdate(r,m,c),typeof a.UNSAFE_componentWillUpdate==`function`&&a.UNSAFE_componentWillUpdate(r,m,c)),typeof a.componentDidUpdate==`function`&&(t.flags|=4),typeof a.getSnapshotBeforeUpdate==`function`&&(t.flags|=1024)):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&p===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&p===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=m),a.props=r,a.state=m,a.context=c,a=l):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&p===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&p===e.memoizedState||(t.flags|=1024),a=!1)}if(c=a,Ds(e,t),o=(t.flags&128)!=0,c||o){if(c=t.stateNode,De(t),o&&typeof n.getDerivedStateFromError!=`function`)n=null,O_=-1;else if(n=Dv(c),t.mode&Hg){E(!0);try{Dv(c)}finally{E(!1)}}t.flags|=1,e!==null&&o?(t.child=ty(t,e.child,null,i),t.child=ty(t,null,n,i)):_s(e,t,n,i),t.memoizedState=c.state,e=t.child}else e=Hs(e,t,i);return i=t.stateNode,a&&i.props!==r&&(hb||console.error("It looks like %s is reassigning its own `this.props` while rendering. This is not supported and can lead to confusing bugs.",S(t)||`a component`),hb=!0),e}function js(e,t,n,r){return Xr(),t.flags|=256,_s(e,t,n,r),t.child}function Ms(e,t){t&&t.childContextTypes&&console.error(`childContextTypes cannot be defined on a function component.
  %s.childContextTypes = ...`,t.displayName||t.name||`Component`),typeof t.getDerivedStateFromProps==`function`&&(e=x(t)||`Unknown`,mb[e]||(console.error(`%s: Function components do not support getDerivedStateFromProps.`,e),mb[e]=!0)),typeof t.contextType==`object`&&t.contextType!==null&&(t=x(t)||`Unknown`,fb[t]||(console.error(`%s: Function components do not support contextType.`,t),fb[t]=!0))}function Ns(e){return{baseLanes:e,cachePool:Ri()}}function Ps(e,t,n){return e=e===null?0:e.childLanes&~n,t&&(e|=fx),e}function Fs(e,t,n){var r,i=t.pendingProps;o(t)&&(t.flags|=128);var a=!1,s=(t.flags&128)!=0;if((r=s)||(r=e!==null&&e.memoizedState===null?!1:(_y.current&gy)!==0),r&&(a=!0,t.flags&=-129),r=(t.flags&32)!=0,t.flags&=-33,e===null){if(H){if(a?va(t):xa(t),(e=i_)?(n=yd(e,c_),n=n!==null&&n.data!==AS?n:null,n!==null&&(r={dehydrated:n,treeContext:Br(),retryLane:536870912,hydrationErrors:null},t.memoizedState=r,r=Nr(n),r.return=t,t.child=r,r_=t,i_=null)):n=null,n===null)throw Gr(t,e),Kr(t);return xd(n)?t.lanes=32:t.lanes=536870912,null}var c=i.children;if(i=i.fallback,a){xa(t);var l=t.mode;return c=Ls({mode:`hidden`,children:c},l),i=jr(i,l,n,null),c.return=t,i.return=t,c.sibling=i,t.child=c,i=t.child,i.memoizedState=Ns(n),i.childLanes=Ps(e,r,n),t.memoizedState=vb,Ss(null,i)}return va(t),Is(t,c)}var u=e.memoizedState;if(u!==null){var d=u.dehydrated;if(d!==null){if(s)t.flags&256?(va(t),t.flags&=-257,t=Rs(e,t,n)):t.memoizedState===null?(xa(t),c=i.fallback,l=t.mode,i=Ls({mode:`visible`,children:i.children},l),c=jr(c,l,n,null),c.flags|=2,i.return=t,c.return=t,i.sibling=c,t.child=i,ty(t,e.child,null,n),i=t.child,i.memoizedState=Ns(n),i.childLanes=Ps(e,r,n),t.memoizedState=vb,t=Ss(null,i)):(xa(t),t.child=e.child,t.flags|=128,t=null);else if(va(t),Wr(),n&536870912&&xl(t),xd(d)){if(r=d.nextSibling&&d.nextSibling.dataset,r){c=r.dgst;var f=r.msg;l=r.stck;var p=r.cstck}a=f,r=c,i=l,d=p,c=a,l=d,c=Error(c||`The server could not finish this Suspense boundary, likely due to an error during server rendering. Switched to client rendering.`),c.stack=i||``,c.digest=r,r=l===void 0?null:l,i={value:c,source:null,stack:r},typeof r==`string`&&qg.set(c,i),Qr(i),t=Rs(e,t,n)}else if(ub||ai(e,t,n,!1),r=(n&e.childLanes)!==0,ub||r){if(r=X,r!==null&&(i=Ge(r,n),i!==0&&i!==u.retryLane))throw u.retryLane=i,_r(e,i),cl(r,e,i),lb;bd(d)||Sl(),t=Rs(e,t,n)}else bd(d)?(t.flags|=192,t.child=e.child,t=null):(e=u.treeContext,i_=Cd(d.nextSibling),r_=t,H=!0,s_=null,a_=!1,o_=null,c_=!1,e!==null&&Vr(t,e),t=Is(t,i.children),t.flags|=4096);return t}}return a?(xa(t),c=i.fallback,l=t.mode,p=e.child,d=p.sibling,i=Dr(p,{mode:`hidden`,children:i.children}),i.subtreeFlags=p.subtreeFlags&65011712,d===null?(c=jr(c,l,n,null),c.flags|=2):c=Dr(d,c),c.return=t,i.return=t,i.sibling=c,t.child=i,Ss(null,i),i=t.child,c=e.child.memoizedState,c===null?c=Ns(n):(l=c.cachePool,l===null?l=Ri():(p=y_._currentValue,l=l.parent===p?l:{parent:p,pool:p}),c={baseLanes:c.baseLanes|n,cachePool:l}),i.memoizedState=c,i.childLanes=Ps(e,r,n),t.memoizedState=vb,Ss(e.child,i)):(u!==null&&(n&62914560)===n&&(n&e.lanes)!==0&&xl(t),va(t),n=e.child,e=n.sibling,n=Dr(n,{mode:`visible`,children:i.children}),n.return=t,n.sibling=null,e!==null&&(r=t.deletions,r===null?(t.deletions=[e],t.flags|=16):r.push(e)),t.child=n,t.memoizedState=null,n)}function Is(e,t){return t=Ls({mode:`visible`,children:t},e.mode),t.return=e,e.child=t}function Ls(e,t){return e=g(22,e,null,t),e.lanes=0,e}function Rs(e,t,n){return ty(t,e.child,null,n),e=Is(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function zs(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),ri(e.return,t,n)}function Bs(e,t,n,r,i,a){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i,treeForkCount:a}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=r,o.tail=n,o.tailMode=i,o.treeForkCount=a)}function Vs(e,t,n){var r=t.pendingProps,i=r.revealOrder,a=r.tail,o=r.children,s=_y.current;if((r=(s&gy)!==0)?(s=s&hy|gy,t.flags|=128):s&=hy,C(_y,s,t),s=i??`null`,i!==`forwards`&&i!==`unstable_legacy-backwards`&&i!==`together`&&i!==`independent`&&!gb[s])if(gb[s]=!0,i==null)console.error(`The default for the <SuspenseList revealOrder="..."> prop is changing. To be future compatible you must explictly specify either "independent" (the current default), "together", "forwards" or "legacy_unstable-backwards".`);else if(i===`backwards`)console.error(`The rendering order of <SuspenseList revealOrder="backwards"> is changing. To be future compatible you must specify revealOrder="legacy_unstable-backwards" instead.`);else if(typeof i==`string`)switch(i.toLowerCase()){case`together`:case`forwards`:case`backwards`:case`independent`:console.error(`"%s" is not a valid value for revealOrder on <SuspenseList />. Use lowercase "%s" instead.`,i,i.toLowerCase());break;case`forward`:case`backward`:console.error(`"%s" is not a valid value for revealOrder on <SuspenseList />. React uses the -s suffix in the spelling. Use "%ss" instead.`,i,i.toLowerCase());break;default:console.error(`"%s" is not a supported revealOrder on <SuspenseList />. Did you mean "independent", "together", "forwards" or "backwards"?`,i)}else console.error(`%s is not a supported value for revealOrder on <SuspenseList />. Did you mean "independent", "together", "forwards" or "backwards"?`,i);s=a??`null`,_b[s]||(a==null?(i===`forwards`||i===`backwards`||i===`unstable_legacy-backwards`)&&(_b[s]=!0,console.error(`The default for the <SuspenseList tail="..."> prop is changing. To be future compatible you must explictly specify either "visible" (the current default), "collapsed" or "hidden".`)):a!==`visible`&&a!==`collapsed`&&a!==`hidden`?(_b[s]=!0,console.error(`"%s" is not a supported value for tail on <SuspenseList />. Did you mean "visible", "collapsed" or "hidden"?`,a)):i!==`forwards`&&i!==`backwards`&&i!==`unstable_legacy-backwards`&&(_b[s]=!0,console.error(`<SuspenseList tail="%s" /> is only valid if revealOrder is "forwards" or "backwards". Did you mean to specify revealOrder="forwards"?`,a)));a:if((i===`forwards`||i===`backwards`||i===`unstable_legacy-backwards`)&&o!=null&&!1!==o)if($f(o)){for(s=0;s<o.length;s++)if(!ra(o[s],s))break a}else if(s=oe(o),typeof s==`function`){if(s=s.call(o))for(var c=s.next(),l=0;!c.done;c=s.next()){if(!ra(c.value,l))break a;l++}}else console.error(`A single row was passed to a <SuspenseList revealOrder="%s" />. This is not useful since it needs multiple rows. Did you mean to pass multiple children or an array?`,i);if(_s(e,t,o,n),H?(Hr(),o=Zg):o=0,!r&&e!==null&&e.flags&128)a:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&zs(e,n,t);else if(e.tag===19)zs(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break a;for(;e.sibling===null;){if(e.return===null||e.return===t)break a;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(i){case`forwards`:for(n=t.child,i=null;n!==null;)e=n.alternate,e!==null&&Ca(e)===null&&(i=n),n=n.sibling;n=i,n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),Bs(t,!1,i,n,a,o);break;case`backwards`:case`unstable_legacy-backwards`:for(n=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&Ca(e)===null){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}Bs(t,!0,n,null,a,o);break;case`together`:Bs(t,!1,null,null,void 0,o);break;default:t.memoizedState=null}return t.child}function Hs(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),O_=-1,lx|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(ai(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(`Resuming work not yet implemented.`);if(t.child!==null){for(e=t.child,n=Dr(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=Dr(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function Us(e,t){return(e.lanes&t)===0?(e=e.dependencies,!!(e!==null&&oi(e))):!0}function Ws(e,t,n){switch(t.tag){case 3:de(t,t.stateNode.containerInfo),ti(t,y_,e.memoizedState.cache),Xr();break;case 27:case 5:me(t);break;case 4:de(t,t.stateNode.containerInfo);break;case 10:ti(t,t.type,t.memoizedProps.value);break;case 12:(n&t.childLanes)!==0&&(t.flags|=4),t.flags|=2048;var r=t.stateNode;r.effectDuration=-0,r.passiveEffectDuration=-0;break;case 31:if(t.memoizedState!==null)return t.flags|=128,ya(t),null;break;case 13:if(r=t.memoizedState,r!==null)return r.dehydrated===null?(n&t.child.childLanes)===0?(va(t),e=Hs(e,t,n),e===null?null:e.sibling):Fs(e,t,n):(va(t),t.flags|=128,null);va(t);break;case 19:var i=(e.flags&128)!=0;if(r=(n&t.childLanes)!==0,r||=(ai(e,t,n,!1),(n&t.childLanes)!==0),i){if(r)return Vs(e,t,n);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),C(_y,_y.current,t),r)break;return null;case 22:return t.lanes=0,xs(e,t,n,t.pendingProps);case 24:ti(t,y_,e.memoizedState.cache)}return Hs(e,t,n)}function Gs(e,t,n){if(t._debugNeedsRemount&&e!==null){n=kr(t.type,t.key,t.pendingProps,t._debugOwner||null,t.mode,t.lanes),n._debugStack=t._debugStack,n._debugTask=t._debugTask;var r=t.return;if(r===null)throw Error(`Cannot swap the root fiber.`);if(e.alternate=null,t.alternate=null,n.index=t.index,n.sibling=t.sibling,n.return=t.return,n.ref=t.ref,n._debugInfo=t._debugInfo,t===r.child)r.child=n;else{var i=r.child;if(i===null)throw Error(`Expected parent to have a child.`);for(;i.sibling!==t;)if(i=i.sibling,i===null)throw Error(`Expected to find the previous sibling.`);i.sibling=n}return t=r.deletions,t===null?(r.deletions=[e],r.flags|=16):t.push(e),n.flags|=2,n}if(e!==null)if(e.memoizedProps!==t.pendingProps||t.type!==e.type)ub=!0;else{if(!Us(e,n)&&!(t.flags&128))return ub=!1,Ws(e,t,n);ub=!!(e.flags&131072)}else ub=!1,(r=H)&&(Hr(),r=(t.flags&1048576)!=0),r&&(r=t.index,Hr(),Lr(t,Zg,r));switch(t.lanes=0,t.tag){case 16:a:if(r=t.pendingProps,e=Hi(t.elementType),t.type=e,typeof e==`function`)Er(e)?(r=ss(e,r),t.tag=1,t.type=e=br(e),t=As(null,t,e,r,n)):(t.tag=0,Ms(t,e),t.type=e=br(e),t=Os(null,t,e,r,n));else{if(e!=null){if(i=e.$$typeof,i===Wf){t.tag=11,t.type=e=xr(e),t=vs(null,t,e,r,n);break a}else if(i===qf){t.tag=14,t=ys(null,t,e,r,n);break a}}throw t=``,typeof e==`object`&&e&&e.$$typeof===Jf&&(t=` Did you wrap a component in React.lazy() more than once?`),n=x(e)||e,Error(`Element type is invalid. Received a promise that resolves to: `+n+`. Lazy element type must resolve to a class or function.`+t)}return t;case 0:return Os(e,t,t.type,t.pendingProps,n);case 1:return r=t.type,i=ss(r,t.pendingProps),As(e,t,r,i,n);case 3:a:{if(de(t,t.stateNode.containerInfo),e===null)throw Error(`Should have a current fiber. This is a bug in React.`);r=t.pendingProps;var a=t.memoizedState;i=a.element,aa(e,t),da(t,r,null,n);var o=t.memoizedState;if(r=o.cache,ti(t,y_,r),r!==a.cache&&ii(t,[y_],n,!0),ua(),r=o.element,a.isDehydrated)if(a={element:r,isDehydrated:!1,cache:o.cache},t.updateQueue.baseState=a,t.memoizedState=a,t.flags&256){t=js(e,t,r,n);break a}else if(r!==i){i=Fr(Error(`This root received an early update, before anything was able hydrate. Switched the entire root to client rendering.`),t),Qr(i),t=js(e,t,r,n);break a}else{switch(e=t.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName===`HTML`?e.ownerDocument.body:e}for(i_=Cd(e.firstChild),r_=t,H=!0,s_=null,a_=!1,o_=null,c_=!0,n=ny(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling}else{if(Xr(),r===i){t=Hs(e,t,n);break a}_s(e,t,r,n)}t=t.child}return t;case 26:return Ds(e,t),e===null?(n=Id(t.type,null,t.pendingProps,null))?t.memoizedState=n:H||(n=t.type,e=t.pendingProps,r=ue(op.current),r=Gu(r).createElement(n),r[Zp]=t,r[Qp]=e,ju(r,n,e),rt(r),t.stateNode=r):t.memoizedState=Id(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return me(t),e===null&&H&&(r=ue(op.current),i=pe(),r=t.stateNode=jd(t.type,t.pendingProps,r,i,!1),a_||(i=Vu(r,t.type,t.pendingProps,i),i!==null&&(Ur(t,0).serverProps=i)),r_=t,c_=!0,i=i_,ad(t.type)?(rC=i,i_=Cd(r.firstChild)):i_=i),_s(e,t,t.pendingProps.children,n),Ds(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&H&&(a=pe(),r=Zt(t.type,a.ancestorInfo),i=i_,(o=!i)||(o=_d(i,t.type,t.pendingProps,c_),o===null?a=!1:(t.stateNode=o,a_||(a=Vu(o,t.type,t.pendingProps,a),a!==null&&(Ur(t,0).serverProps=a)),r_=t,i_=Cd(o.firstChild),c_=!1,a=!0),o=!a),o&&(r&&Gr(t,i),Kr(t))),me(t),i=t.type,a=t.pendingProps,o=e===null?null:e.memoizedProps,r=a.children,Ju(i,a)?r=null:o!==null&&Ju(i,o)&&(t.flags|=32),t.memoizedState!==null&&(i=Oa(e,t,ja,null,null,n),xC._currentValue=i),Ds(e,t),_s(e,t,r,n),t.child;case 6:return e===null&&H&&(n=t.pendingProps,e=pe(),r=e.ancestorInfo.current,n=r==null?!0:Qt(n,r.tag,e.ancestorInfo.implicitRootScope),e=i_,(r=!e)||(r=vd(e,t.pendingProps,c_),r===null?r=!1:(t.stateNode=r,r_=t,i_=null,r=!0),r=!r),r&&(n&&Gr(t,e),Kr(t))),null;case 13:return Fs(e,t,n);case 4:return de(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=ty(t,null,r,n):_s(e,t,r,n),t.child;case 11:return vs(e,t,t.type,t.pendingProps,n);case 7:return _s(e,t,t.pendingProps,n),t.child;case 8:return _s(e,t,t.pendingProps.children,n),t.child;case 12:return t.flags|=4,t.flags|=2048,r=t.stateNode,r.effectDuration=-0,r.passiveEffectDuration=-0,_s(e,t,t.pendingProps.children,n),t.child;case 10:return r=t.type,i=t.pendingProps,a=i.value,`value`in i||yb||(yb=!0,console.error("The `value` prop is required for the `<Context.Provider>`. Did you misspell it or forget to pass it?")),ti(t,r,a),_s(e,t,i.children,n),t.child;case 9:return i=t.type._context,r=t.pendingProps.children,typeof r!=`function`&&console.error(`A context consumer was rendered with multiple children, or a child that isn't a function. A context consumer expects a single child that is a function. If you did pass a function, make sure there is no trailing or leading whitespace around it.`),si(t),i=ci(i),r=Tv(r,i,void 0),t.flags|=1,_s(e,t,r,n),t.child;case 14:return ys(e,t,t.type,t.pendingProps,n);case 15:return bs(e,t,t.type,t.pendingProps,n);case 19:return Vs(e,t,n);case 31:return Es(e,t,n);case 22:return xs(e,t,n,t.pendingProps);case 24:return si(t),r=ci(y_),e===null?(i=Ii(),i===null&&(i=X,a=di(),i.pooledCache=a,fi(a),a!==null&&(i.pooledCacheLanes|=n),i=a),t.memoizedState={parent:r,cache:i},ia(t),ti(t,y_,i)):((e.lanes&n)!==0&&(aa(e,t),da(t,null,null,n),ua()),i=e.memoizedState,a=t.memoizedState,i.parent===r?(r=a.cache,ti(t,y_,r),r!==i.cache&&ii(t,[y_],n,!0)):(i={parent:r,cache:r},t.memoizedState=i,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=i),ti(t,y_,r))),_s(e,t,t.pendingProps.children,n),t.child;case 29:throw t.pendingProps}throw Error(`Unknown unit of work tag (`+t.tag+`). This error is likely caused by a bug in React. Please file an issue.`)}function Ks(e){e.flags|=4}function qs(e,t,n,r,i){if((t=(e.mode&Wg)!==B)&&(t=!1),t){if(e.flags|=16777216,(i&335544128)===i)if(e.stateNode.complete)e.flags|=8192;else if(vl())e.flags|=8192;else throw Kv=Gv,Uv}else e.flags&=-16777217}function Js(e,t){if(t.type!==`stylesheet`||(t.state.loading&cC)!==iC)e.flags&=-16777217;else if(e.flags|=16777216,!Zd(t))if(vl())e.flags|=8192;else throw Kv=Gv,Uv}function Ys(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag===22?536870912:ze(),e.lanes|=t,px|=t)}function Xs(e,t){if(!H)switch(e.tailMode){case`hidden`:t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case`collapsed`:n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function A(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)if((e.mode&V)!==B){for(var i=e.selfBaseDuration,a=e.child;a!==null;)n|=a.lanes|a.childLanes,r|=a.subtreeFlags&65011712,r|=a.flags&65011712,i+=a.treeBaseDuration,a=a.sibling;e.treeBaseDuration=i}else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&65011712,r|=i.flags&65011712,i.return=e,i=i.sibling;else if((e.mode&V)!==B){i=e.actualDuration,a=e.selfBaseDuration;for(var o=e.child;o!==null;)n|=o.lanes|o.childLanes,r|=o.subtreeFlags,r|=o.flags,i+=o.actualDuration,a+=o.treeBaseDuration,o=o.sibling;e.actualDuration=i,e.treeBaseDuration=a}else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function Zs(e,t,n){var r=t.pendingProps;switch(zr(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return A(t),null;case 1:return A(t),null;case 3:return n=t.stateNode,r=null,e!==null&&(r=e.memoizedState.cache),t.memoizedState.cache!==r&&(t.flags|=2048),ni(y_,t),fe(t),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(Yr(t)?($r(),Ks(t)):e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,Zr())),A(t),null;case 26:var i=t.type,a=t.memoizedState;return e===null?(Ks(t),a===null?(A(t),qs(t,i,null,r,n)):(A(t),Js(t,a))):a?a===e.memoizedState?(A(t),t.flags&=-16777217):(Ks(t),A(t),Js(t,a)):(e=e.memoizedProps,e!==r&&Ks(t),A(t),qs(t,i,e,r,n)),null;case 27:if(he(t),n=ue(op.current),i=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==r&&Ks(t);else{if(!r){if(t.stateNode===null)throw Error(`We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.`);return A(t),null}e=pe(),Yr(t)?qr(t,e):(e=jd(i,r,n,e,!0),t.stateNode=e,Ks(t))}return A(t),null;case 5:if(he(t),i=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==r&&Ks(t);else{if(!r){if(t.stateNode===null)throw Error(`We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.`);return A(t),null}var o=pe();if(Yr(t))qr(t,o);else{switch(a=ue(op.current),Zt(i,o.ancestorInfo),o=o.context,a=Gu(a),o){case GS:a=a.createElementNS(Vm,i);break;case KS:a=a.createElementNS(Bm,i);break;default:switch(i){case`svg`:a=a.createElementNS(Vm,i);break;case`math`:a=a.createElementNS(Bm,i);break;case`script`:a=a.createElement(`div`),a.innerHTML=`<script><\/script>`,a=a.removeChild(a.firstChild);break;case`select`:a=typeof r.is==`string`?a.createElement(`select`,{is:r.is}):a.createElement(`select`),r.multiple?a.multiple=!0:r.size&&(a.size=r.size);break;default:a=typeof r.is==`string`?a.createElement(i,{is:r.is}):a.createElement(i),i.indexOf(`-`)===-1&&(i!==i.toLowerCase()&&console.error(`<%s /> is using incorrect casing. Use PascalCase for React components, or lowercase for HTML elements.`,i),Object.prototype.toString.call(a)!==`[object HTMLUnknownElement]`||Sp.call(YS,i)||(YS[i]=!0,console.error(`The tag <%s> is unrecognized in this browser. If you meant to render a React component, start its name with an uppercase letter.`,i)))}}a[Zp]=t,a[Qp]=r;a:for(o=t.child;o!==null;){if(o.tag===5||o.tag===6)a.appendChild(o.stateNode);else if(o.tag!==4&&o.tag!==27&&o.child!==null){o.child.return=o,o=o.child;continue}if(o===t)break a;for(;o.sibling===null;){if(o.return===null||o.return===t)break a;o=o.return}o.sibling.return=o.return,o=o.sibling}t.stateNode=a;a:switch(ju(a,i,r),i){case`button`:case`input`:case`select`:case`textarea`:r=!!r.autoFocus;break a;case`img`:r=!0;break a;default:r=!1}r&&Ks(t)}}return A(t),qs(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==r&&Ks(t);else{if(typeof r!=`string`&&t.stateNode===null)throw Error(`We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.`);if(e=ue(op.current),n=pe(),Yr(t)){if(e=t.stateNode,n=t.memoizedProps,i=!a_,r=null,a=r_,a!==null)switch(a.tag){case 3:i&&(i=Td(e,n,r),i!==null&&(Ur(t,0).serverProps=i));break;case 27:case 5:r=a.memoizedProps,i&&(i=Td(e,n,r),i!==null&&(Ur(t,0).serverProps=i))}e[Zp]=t,e=!!(e.nodeValue===n||r!==null&&!0===r.suppressHydrationWarning||ku(e.nodeValue,n)),e||Kr(t,!0)}else i=n.ancestorInfo.current,i!=null&&Qt(r,i.tag,n.ancestorInfo.implicitRootScope),e=Gu(e).createTextNode(r),e[Zp]=t,t.stateNode=e}return A(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(r=Yr(t),n!==null){if(e===null){if(!r)throw Error(`A dehydrated suspense component was completed without a hydrated node. This is probably a bug in React.`);if(e=t.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(`Expected to have a hydrated activity instance. This error is likely caused by a bug in React. Please file an issue.`);e[Zp]=t,A(t),(t.mode&V)!==B&&n!==null&&(e=t.child,e!==null&&(t.treeBaseDuration-=e.treeBaseDuration))}else $r(),Xr(),!(t.flags&128)&&(n=t.memoizedState=null),t.flags|=4,A(t),(t.mode&V)!==B&&n!==null&&(e=t.child,e!==null&&(t.treeBaseDuration-=e.treeBaseDuration));e=!1}else n=Zr(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(Sa(t),t):(Sa(t),null);if(t.flags&128)throw Error(`Client rendering an Activity suspended it again. This is a bug in React.`)}return A(t),null;case 13:if(r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(i=r,a=Yr(t),i!==null&&i.dehydrated!==null){if(e===null){if(!a)throw Error(`A dehydrated suspense component was completed without a hydrated node. This is probably a bug in React.`);if(a=t.memoizedState,a=a===null?null:a.dehydrated,!a)throw Error(`Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.`);a[Zp]=t,A(t),(t.mode&V)!==B&&i!==null&&(i=t.child,i!==null&&(t.treeBaseDuration-=i.treeBaseDuration))}else $r(),Xr(),!(t.flags&128)&&(i=t.memoizedState=null),t.flags|=4,A(t),(t.mode&V)!==B&&i!==null&&(i=t.child,i!==null&&(t.treeBaseDuration-=i.treeBaseDuration));i=!1}else i=Zr(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=i),i=!0;if(!i)return t.flags&256?(Sa(t),t):(Sa(t),null)}return Sa(t),t.flags&128?(t.lanes=n,(t.mode&V)!==B&&Mi(t),t):(n=r!==null,e=e!==null&&e.memoizedState!==null,n&&(r=t.child,i=null,r.alternate!==null&&r.alternate.memoizedState!==null&&r.alternate.memoizedState.cachePool!==null&&(i=r.alternate.memoizedState.cachePool.pool),a=null,r.memoizedState!==null&&r.memoizedState.cachePool!==null&&(a=r.memoizedState.cachePool.pool),a!==i&&(r.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),Ys(t,t.updateQueue),A(t),(t.mode&V)!==B&&n&&(e=t.child,e!==null&&(t.treeBaseDuration-=e.treeBaseDuration)),null);case 4:return fe(t),e===null&&gu(t.stateNode.containerInfo),A(t),null;case 10:return ni(t.type,t),A(t),null;case 19:if(le(_y,t),r=t.memoizedState,r===null)return A(t),null;if(i=(t.flags&128)!=0,a=r.rendering,a===null)if(i)Xs(r,!1);else{if(cx!==Bb||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(a=Ca(e),a!==null){for(t.flags|=128,Xs(r,!1),e=a.updateQueue,t.updateQueue=e,Ys(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)Or(n,e),n=n.sibling;return C(_y,_y.current&hy|gy,t),H&&Ir(t,r.treeForkCount),t.child}e=e.sibling}r.tail!==null&&Dp()>bx&&(t.flags|=128,i=!0,Xs(r,!1),t.lanes=4194304)}else{if(!i)if(e=Ca(a),e!==null){if(t.flags|=128,i=!0,e=e.updateQueue,t.updateQueue=e,Ys(t,e),Xs(r,!0),r.tail===null&&r.tailMode===`hidden`&&!a.alternate&&!H)return A(t),null}else 2*Dp()-r.renderingStartTime>bx&&n!==536870912&&(t.flags|=128,i=!0,Xs(r,!1),t.lanes=4194304);r.isBackwards?(a.sibling=t.child,t.child=a):(e=r.last,e===null?t.child=a:e.sibling=a,r.last=a)}return r.tail===null?(A(t),null):(e=r.tail,r.rendering=e,r.tail=e.sibling,r.renderingStartTime=Dp(),e.sibling=null,n=_y.current,n=i?n&hy|gy:n&hy,C(_y,n,t),H&&Ir(t,r.treeForkCount),e);case 22:case 23:return Sa(t),_a(t),r=t.memoizedState!==null,e===null?r&&(t.flags|=8192):e.memoizedState!==null!==r&&(t.flags|=8192),r?n&536870912&&!(t.flags&128)&&(A(t),t.subtreeFlags&6&&(t.flags|=8192)):A(t),n=t.updateQueue,n!==null&&Ys(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),r=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(r=t.memoizedState.cachePool.pool),r!==n&&(t.flags|=2048),e!==null&&le(pv,t),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),ni(y_,t),A(t),null;case 25:return null;case 30:return null}throw Error(`Unknown unit of work tag (`+t.tag+`). This error is likely caused by a bug in React. Please file an issue.`)}function Qs(e,t){switch(zr(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,(t.mode&V)!==B&&Mi(t),t):null;case 3:return ni(y_,t),fe(t),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return he(t),null;case 31:if(t.memoizedState!==null){if(Sa(t),t.alternate===null)throw Error(`Threw in newly mounted dehydrated component. This is likely a bug in React. Please file an issue.`);Xr()}return e=t.flags,e&65536?(t.flags=e&-65537|128,(t.mode&V)!==B&&Mi(t),t):null;case 13:if(Sa(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(`Threw in newly mounted dehydrated component. This is likely a bug in React. Please file an issue.`);Xr()}return e=t.flags,e&65536?(t.flags=e&-65537|128,(t.mode&V)!==B&&Mi(t),t):null;case 19:return le(_y,t),null;case 4:return fe(t),null;case 10:return ni(t.type,t),null;case 22:case 23:return Sa(t),_a(t),e!==null&&le(pv,t),e=t.flags,e&65536?(t.flags=e&-65537|128,(t.mode&V)!==B&&Mi(t),t):null;case 24:return ni(y_,t),null;case 25:return null;default:return null}}function $s(e,t){switch(zr(t),t.tag){case 3:ni(y_,t),fe(t);break;case 26:case 27:case 5:he(t);break;case 4:fe(t);break;case 31:t.memoizedState!==null&&Sa(t);break;case 13:Sa(t);break;case 19:le(_y,t);break;case 10:ni(t.type,t);break;case 22:case 23:Sa(t),_a(t),e!==null&&le(pv,t);break;case 24:ni(y_,t)}}function ec(e){return(e.mode&V)!==B}function tc(e,t){ec(e)?(ji(),rc(t,e),ki()):rc(t,e)}function nc(e,t,n){ec(e)?(ji(),ic(n,e,t),ki()):ic(n,e,t)}function rc(e,t){try{var n=t.updateQueue,r=n===null?null:n.lastEffect;if(r!==null){var i=r.next;n=i;do{if((n.tag&e)===e&&(r=void 0,(e&by)!==vy&&(eS=!0),r=w(t,Lv,n),(e&by)!==vy&&(eS=!1),r!==void 0&&typeof r!=`function`)){var a=void 0;a=(n.tag&xy)===0?(n.tag&by)===0?`useEffect`:`useInsertionEffect`:`useLayoutEffect`;var o=void 0;o=r===null?` You returned null. If your effect does not require clean up, return undefined (or nothing).`:typeof r.then==`function`?`

It looks like you wrote `+a+`(async () => ...) or returned a Promise. Instead, write the async function inside your effect and call it immediately:

`+a+`(() => {
  async function fetchData() {
    // You can await here
    const response = await MyAPI.getData(someId);
    // ...
  }
  fetchData();
}, [someId]); // Or [] if effect doesn't need props or state

Learn more about data fetching with Hooks: https://react.dev/link/hooks-data-fetching`:` You returned: `+r,w(t,function(e,t){console.error(`%s must not return anything besides a function, which is used for clean-up.%s`,e,t)},a,o)}n=n.next}while(n!==i)}}catch(e){j(t,t.return,e)}}function ic(e,t,n){try{var r=t.updateQueue,i=r===null?null:r.lastEffect;if(i!==null){var a=i.next;r=a;do{if((r.tag&e)===e){var o=r.inst,s=o.destroy;s!==void 0&&(o.destroy=void 0,(e&by)!==vy&&(eS=!0),i=t,w(i,zv,i,n,s),(e&by)!==vy&&(eS=!1))}r=r.next}while(r!==a)}}catch(e){j(t,t.return,e)}}function ac(e,t){ec(e)?(ji(),rc(t,e),ki()):rc(t,e)}function oc(e,t,n){ec(e)?(ji(),ic(n,e,t),ki()):ic(n,e,t)}function sc(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;e.type.defaultProps||`ref`in e.memoizedProps||hb||(n.props!==e.memoizedProps&&console.error("Expected %s props to match memoized props before processing the update queue. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.",S(e)||`instance`),n.state!==e.memoizedState&&console.error("Expected %s state to match memoized state before processing the update queue. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.",S(e)||`instance`));try{w(e,ma,t,n)}catch(t){j(e,e.return,t)}}}function cc(e,t,n){return e.getSnapshotBeforeUpdate(t,n)}function lc(e,t){var n=t.memoizedProps,r=t.memoizedState;t=e.stateNode,e.type.defaultProps||`ref`in e.memoizedProps||hb||(t.props!==e.memoizedProps&&console.error("Expected %s props to match memoized props before getSnapshotBeforeUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.",S(e)||`instance`),t.state!==e.memoizedState&&console.error("Expected %s state to match memoized state before getSnapshotBeforeUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.",S(e)||`instance`));try{var i=ss(e.type,n),a=w(e,cc,t,i,r);n=bb,a!==void 0||n.has(e.type)||(n.add(e.type),w(e,function(){console.error(`%s.getSnapshotBeforeUpdate(): A snapshot value (or null) must be returned. You have returned undefined.`,S(e))})),t.__reactInternalSnapshotBeforeUpdate=a}catch(t){j(e,e.return,t)}}function uc(e,t,n){n.props=ss(e.type,e.memoizedProps),n.state=e.memoizedState,ec(e)?(ji(),w(e,Fv,e,t,n),ki()):w(e,Fv,e,t,n)}function dc(e){var t=e.ref;if(t!==null){switch(e.tag){case 26:case 27:case 5:var n=e.stateNode;break;case 30:n=e.stateNode;break;default:n=e.stateNode}if(typeof t==`function`)if(ec(e))try{ji(),e.refCleanup=t(n)}finally{ki()}else e.refCleanup=t(n);else typeof t==`string`?console.error(`String refs are no longer supported.`):t.hasOwnProperty(`current`)||console.error(`Unexpected ref object provided for %s. Use either a ref-setter function or React.createRef().`,S(e)),t.current=n}}function fc(e,t){try{w(e,dc,e)}catch(n){j(e,t,n)}}function pc(e,t){var n=e.ref,r=e.refCleanup;if(n!==null)if(typeof r==`function`)try{if(ec(e))try{ji(),w(e,r)}finally{ki(e)}else w(e,r)}catch(n){j(e,t,n)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n==`function`)try{if(ec(e))try{ji(),w(e,n,null)}finally{ki(e)}else w(e,n,null)}catch(n){j(e,t,n)}else n.current=null}function mc(e,t,n,r){var i=e.memoizedProps,a=i.id,o=i.onCommit;i=i.onRender,t=t===null?`mount`:`update`,ov&&(t=`nested-update`),typeof i==`function`&&i(a,t,e.actualDuration,e.treeBaseDuration,e.actualStartTime,n),typeof o==`function`&&o(a,t,r,n)}function hc(e,t,n,r){var i=e.memoizedProps;e=i.id,i=i.onPostCommit,t=t===null?`mount`:`update`,ov&&(t=`nested-update`),typeof i==`function`&&i(e,t,r,n)}function gc(e){var t=e.type,n=e.memoizedProps,r=e.stateNode;try{w(e,$u,r,t,n,e)}catch(t){j(e,e.return,t)}}function _c(e,t,n){try{w(e,td,e.stateNode,e.type,n,t,e)}catch(t){j(e,e.return,t)}}function vc(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&ad(e.type)||e.tag===4}function yc(e){a:for(;;){for(;e.sibling===null;){if(e.return===null||vc(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&ad(e.type)||e.flags&2||e.child===null||e.tag===4)continue a;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function bc(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?(id(n),(n.nodeType===9?n.body:n.nodeName===`HTML`?n.ownerDocument.body:n).insertBefore(e,t)):(id(n),t=n.nodeType===9?n.body:n.nodeName===`HTML`?n.ownerDocument.body:n,t.appendChild(e),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=dn));else if(r!==4&&(r===27&&ad(e.type)&&(n=e.stateNode,t=null),e=e.child,e!==null))for(bc(e,t,n),e=e.sibling;e!==null;)bc(e,t,n),e=e.sibling}function xc(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(r===27&&ad(e.type)&&(n=e.stateNode),e=e.child,e!==null))for(xc(e,t,n),e=e.sibling;e!==null;)xc(e,t,n),e=e.sibling}function Sc(e){for(var t,n=e.return;n!==null;){if(vc(n)){t=n;break}n=n.return}if(t==null)throw Error(`Expected to find a host parent. This error is likely caused by a bug in React. Please file an issue.`);switch(t.tag){case 27:t=t.stateNode,n=yc(e),xc(e,n,t);break;case 5:n=t.stateNode,t.flags&32&&(nd(n),t.flags&=-33),t=yc(e),xc(e,t,n);break;case 3:case 4:t=t.stateNode.containerInfo,n=yc(e),bc(e,n,t);break;default:throw Error(`Invalid host parent fiber. This error is likely caused by a bug in React. Please file an issue.`)}}function Cc(e){var t=e.stateNode,n=e.memoizedProps;try{w(e,Md,e.type,n,t,e)}catch(t){j(e,e.return,t)}}function wc(e,t){return t.tag===31?(t=t.memoizedState,e.memoizedState!==null&&t===null):t.tag===13?(e=e.memoizedState,t=t.memoizedState,e!==null&&e.dehydrated!==null&&(t===null||t.dehydrated===null)):t.tag===3?e.memoizedState.isDehydrated&&(t.flags&256)==0:!1}function Tc(e,t){if(e=e.containerInfo,qS=RC,e=Wn(e),Gn(e)){if(`selectionStart`in e)var n={start:e.selectionStart,end:e.selectionEnd};else a:{n=(n=e.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var i=r.anchorOffset,a=r.focusNode;r=r.focusOffset;try{n.nodeType,a.nodeType}catch{n=null;break a}var o=0,s=-1,c=-1,l=0,u=0,d=e,f=null;b:for(;;){for(var p;d!==n||i!==0&&d.nodeType!==3||(s=o+i),d!==a||r!==0&&d.nodeType!==3||(c=o+r),d.nodeType===3&&(o+=d.nodeValue.length),(p=d.firstChild)!==null;)f=d,d=p;for(;;){if(d===e)break b;if(f===n&&++l===i&&(s=o),f===a&&++u===r&&(c=o),(p=d.nextSibling)!==null)break;d=f,f=d.parentNode}d=p}n=s===-1||c===-1?null:{start:s,end:c}}else n=null}n||={start:0,end:0}}else n=null;for(JS={focusedElem:e,selectionRange:n},RC=!1,Tb=t;Tb!==null;)if(t=Tb,e=t.child,t.subtreeFlags&1028&&e!==null)e.return=t,Tb=e;else for(;Tb!==null;){switch(e=t=Tb,n=e.alternate,i=e.flags,e.tag){case 0:if(i&4&&(e=e.updateQueue,e=e===null?null:e.events,e!==null))for(n=0;n<e.length;n++)i=e[n],i.ref.impl=i.nextImpl;break;case 11:case 15:break;case 1:i&1024&&n!==null&&lc(e,n);break;case 3:if(i&1024){if(e=e.stateNode.containerInfo,n=e.nodeType,n===9)gd(e);else if(n===1)switch(e.nodeName){case`HEAD`:case`HTML`:case`BODY`:gd(e);break;default:e.textContent=``}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if(i&1024)throw Error(`This unit of work tag should not have side-effects. This error is likely caused by a bug in React. Please file an issue.`)}if(e=t.sibling,e!==null){e.return=t.return,Tb=e;break}Tb=t.return}}function Ec(e,t,n){var r=bi(),i=Si(),a=wi(),o=Ti(),s=n.flags;switch(n.tag){case 0:case 11:case 15:Rc(e,n),s&4&&tc(n,xy|yy);break;case 1:if(Rc(e,n),s&4)if(e=n.stateNode,t===null)n.type.defaultProps||`ref`in n.memoizedProps||hb||(e.props!==n.memoizedProps&&console.error("Expected %s props to match memoized props before componentDidMount. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.",S(n)||`instance`),e.state!==n.memoizedState&&console.error("Expected %s state to match memoized state before componentDidMount. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.",S(n)||`instance`)),ec(n)?(ji(),w(n,kv,n,e),ki()):w(n,kv,n,e);else{var c=ss(n.type,t.memoizedProps);t=t.memoizedState,n.type.defaultProps||`ref`in n.memoizedProps||hb||(e.props!==n.memoizedProps&&console.error("Expected %s props to match memoized props before componentDidUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.",S(n)||`instance`),e.state!==n.memoizedState&&console.error("Expected %s state to match memoized state before componentDidUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.",S(n)||`instance`)),ec(n)?(ji(),w(n,jv,n,e,c,t,e.__reactInternalSnapshotBeforeUpdate),ki()):w(n,jv,n,e,c,t,e.__reactInternalSnapshotBeforeUpdate)}s&64&&sc(n),s&512&&fc(n,n.return);break;case 3:if(t=gi(),Rc(e,n),s&64&&(s=n.updateQueue,s!==null)){if(c=null,n.child!==null)switch(n.child.tag){case 27:case 5:c=n.child.stateNode;break;case 1:c=n.child.stateNode}try{w(n,ma,s,c)}catch(e){j(n,n.return,e)}}e.effectDuration+=_i(t);break;case 27:t===null&&s&4&&Cc(n);case 26:case 5:if(Rc(e,n),t===null){if(s&4)gc(n);else if(s&64){e=n.type,t=n.memoizedProps,c=n.stateNode;try{w(n,ed,c,e,t,n)}catch(e){j(n,n.return,e)}}}s&512&&fc(n,n.return);break;case 12:if(s&4){s=gi(),Rc(e,n),e=n.stateNode,e.effectDuration+=vi(s);try{w(n,mc,n,t,T_,e.effectDuration)}catch(e){j(n,n.return,e)}}else Rc(e,n);break;case 31:Rc(e,n),s&4&&Ac(e,n);break;case 13:Rc(e,n),s&4&&jc(e,n),s&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(s=Gl.bind(null,n),Sd(e,s))));break;case 22:if(s=n.memoizedState!==null||xb,!s){t=t!==null&&t.memoizedState!==null||Sb,c=xb;var l=Sb;xb=s,(Sb=t)&&!l?(Hc(e,n,(n.subtreeFlags&8772)!=0),(n.mode&V)!==B&&0<=U&&0<=W&&.05<W-U&&nr(n,U,W)):Rc(e,n),xb=c,Sb=l}break;case 30:break;default:Rc(e,n)}(n.mode&V)!==B&&0<=U&&0<=W&&((M_||.05<A_)&&ar(n,U,W,A_,j_),n.alternate===null&&n.return!==null&&n.return.alternate!==null&&.05<W-U&&(wc(n.return.alternate,n.return)||tr(n,U,W,`Mount`))),xi(r),Ci(i),j_=a,M_=o}function Dc(e){var t=e.alternate;t!==null&&(e.alternate=null,Dc(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&Qe(t)),e.stateNode=null,e._debugOwner=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function Oc(e,t,n){for(n=n.child;n!==null;)kc(e,t,n),n=n.sibling}function kc(e,t,n){if(Lp&&typeof Lp.onCommitFiberUnmount==`function`)try{Lp.onCommitFiberUnmount(Ip,n)}catch(e){Rp||(Rp=!0,console.error(`React instrumentation encountered an error: %o`,e))}var r=bi(),i=Si(),a=wi(),o=Ti();switch(n.tag){case 26:Sb||pc(n,t),Oc(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&(e=n.stateNode,e.parentNode.removeChild(e));break;case 27:Sb||pc(n,t);var s=Ob,c=kb;ad(n.type)&&(Ob=n.stateNode,kb=!1),Oc(e,t,n),w(n,Nd,n.stateNode),Ob=s,kb=c;break;case 5:Sb||pc(n,t);case 6:if(s=Ob,c=kb,Ob=null,Oc(e,t,n),Ob=s,kb=c,Ob!==null)if(kb)try{w(n,sd,Ob,n.stateNode)}catch(e){j(n,t,e)}else try{w(n,od,Ob,n.stateNode)}catch(e){j(n,t,e)}break;case 18:Ob!==null&&(kb?(e=Ob,cd(e.nodeType===9?e.body:e.nodeName===`HTML`?e.ownerDocument.body:e,n.stateNode),Of(e)):cd(Ob,n.stateNode));break;case 4:s=Ob,c=kb,Ob=n.stateNode.containerInfo,kb=!0,Oc(e,t,n),Ob=s,kb=c;break;case 0:case 11:case 14:case 15:ic(by,n,t),Sb||nc(n,t,xy),Oc(e,t,n);break;case 1:Sb||(pc(n,t),s=n.stateNode,typeof s.componentWillUnmount==`function`&&uc(n,t,s)),Oc(e,t,n);break;case 21:Oc(e,t,n);break;case 22:Sb=(s=Sb)||n.memoizedState!==null,Oc(e,t,n),Sb=s;break;default:Oc(e,t,n)}(n.mode&V)!==B&&0<=U&&0<=W&&(M_||.05<A_)&&ar(n,U,W,A_,j_),xi(r),Ci(i),j_=a,M_=o}function Ac(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{w(t,kd,e)}catch(e){j(t,t.return,e)}}}function jc(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{w(t,Ad,e)}catch(e){j(t,t.return,e)}}function Mc(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new wb),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new wb),t;default:throw Error(`Unexpected Suspense handler tag (`+e.tag+`). This is a bug in React.`)}}function Nc(e,t){var n=Mc(e);t.forEach(function(t){if(!n.has(t)){if(n.add(t),zp)if(Eb!==null&&Db!==null)Zl(Db,Eb);else throw Error(`Expected finished root and lanes to be set. This is a bug in React.`);var r=Kl.bind(null,e,t);t.then(r,r)}})}function Pc(e,t){var n=t.deletions;if(n!==null)for(var r=0;r<n.length;r++){var i=e,a=t,o=n[r],s=bi(),c=a;a:for(;c!==null;){switch(c.tag){case 27:if(ad(c.type)){Ob=c.stateNode,kb=!1;break a}break;case 5:Ob=c.stateNode,kb=!1;break a;case 3:case 4:Ob=c.stateNode.containerInfo,kb=!0;break a}c=c.return}if(Ob===null)throw Error(`Expected to find a host parent. This error is likely caused by a bug in React. Please file an issue.`);kc(i,a,o),Ob=null,kb=!1,(o.mode&V)!==B&&0<=U&&0<=W&&.05<W-U&&tr(o,U,W,`Unmount`),xi(s),i=o,a=i.alternate,a!==null&&(a.return=null),i.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)Fc(t,e),t=t.sibling}function Fc(e,t){var n=bi(),r=Si(),i=wi(),a=Ti(),o=e.alternate,s=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:Pc(t,e),Ic(e),s&4&&(ic(by|yy,e,e.return),rc(by|yy,e),nc(e,e.return,xy|yy));break;case 1:if(Pc(t,e),Ic(e),s&512&&(Sb||o===null||pc(o,o.return)),s&64&&xb&&(s=e.updateQueue,s!==null&&(o=s.callbacks,o!==null))){var c=s.shared.hiddenCallbacks;s.shared.hiddenCallbacks=c===null?o:c.concat(o)}break;case 26:if(c=Ab,Pc(t,e),Ic(e),s&512&&(Sb||o===null||pc(o,o.return)),s&4){var l=o===null?null:o.memoizedState;if(s=e.memoizedState,o===null)if(s===null)if(e.stateNode===null){a:{s=e.type,o=e.memoizedProps,c=c.ownerDocument||c;b:switch(s){case`title`:l=c.getElementsByTagName(`title`)[0],(!l||l[im]||l[Zp]||l.namespaceURI===Vm||l.hasAttribute(`itemprop`))&&(l=c.createElement(s),c.head.insertBefore(l,c.querySelector(`head > title`))),ju(l,s,o),l[Zp]=e,rt(l),s=l;break a;case`link`:var u=Jd(`link`,`href`,c).get(s+(o.href||``));if(u){for(var d=0;d<u.length;d++)if(l=u[d],l.getAttribute(`href`)===(o.href==null||o.href===``?null:o.href)&&l.getAttribute(`rel`)===(o.rel==null?null:o.rel)&&l.getAttribute(`title`)===(o.title==null?null:o.title)&&l.getAttribute(`crossorigin`)===(o.crossOrigin==null?null:o.crossOrigin)){u.splice(d,1);break b}}l=c.createElement(s),ju(l,s,o),c.head.appendChild(l);break;case`meta`:if(u=Jd(`meta`,`content`,c).get(s+(o.content||``))){for(d=0;d<u.length;d++)if(l=u[d],T(o.content,`content`),l.getAttribute(`content`)===(o.content==null?null:``+o.content)&&l.getAttribute(`name`)===(o.name==null?null:o.name)&&l.getAttribute(`property`)===(o.property==null?null:o.property)&&l.getAttribute(`http-equiv`)===(o.httpEquiv==null?null:o.httpEquiv)&&l.getAttribute(`charset`)===(o.charSet==null?null:o.charSet)){u.splice(d,1);break b}}l=c.createElement(s),ju(l,s,o),c.head.appendChild(l);break;default:throw Error(`getNodesForType encountered a type it did not expect: "`+s+`". This is a bug in React.`)}l[Zp]=e,rt(l),s=l}e.stateNode=s}else Yd(c,e.type,e.stateNode);else e.stateNode=Wd(c,s,e.memoizedProps);else l===s?s===null&&e.stateNode!==null&&_c(e,e.memoizedProps,o.memoizedProps):(l===null?o.stateNode!==null&&(o=o.stateNode,o.parentNode.removeChild(o)):l.count--,s===null?Yd(c,e.type,e.stateNode):Wd(c,s,e.memoizedProps))}break;case 27:Pc(t,e),Ic(e),s&512&&(Sb||o===null||pc(o,o.return)),o!==null&&s&4&&_c(e,e.memoizedProps,o.memoizedProps);break;case 5:if(Pc(t,e),Ic(e),s&512&&(Sb||o===null||pc(o,o.return)),e.flags&32){c=e.stateNode;try{w(e,nd,c)}catch(t){j(e,e.return,t)}}s&4&&e.stateNode!=null&&(c=e.memoizedProps,_c(e,c,o===null?c:o.memoizedProps)),s&1024&&(Cb=!0,e.type!==`form`&&console.error(`Unexpected host component type. Expected a form. This is a bug in React.`));break;case 6:if(Pc(t,e),Ic(e),s&4){if(e.stateNode===null)throw Error(`This should have a text node initialized. This error is likely caused by a bug in React. Please file an issue.`);s=e.memoizedProps,o=o===null?s:o.memoizedProps,c=e.stateNode;try{w(e,rd,c,o,s)}catch(t){j(e,e.return,t)}}break;case 3:if(c=gi(),pC=null,l=Ab,Ab=Pd(t.containerInfo),Pc(t,e),Ab=l,Ic(e),s&4&&o!==null&&o.memoizedState.isDehydrated)try{w(e,Od,t.containerInfo)}catch(t){j(e,e.return,t)}Cb&&(Cb=!1,Lc(e)),t.effectDuration+=_i(c);break;case 4:s=Ab,Ab=Pd(e.stateNode.containerInfo),Pc(t,e),Ic(e),Ab=s;break;case 12:s=gi(),Pc(t,e),Ic(e),e.stateNode.effectDuration+=vi(s);break;case 31:Pc(t,e),Ic(e),s&4&&(s=e.updateQueue,s!==null&&(e.updateQueue=null,Nc(e,s)));break;case 13:Pc(t,e),Ic(e),e.child.flags&8192&&e.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(_x=Dp()),s&4&&(s=e.updateQueue,s!==null&&(e.updateQueue=null,Nc(e,s)));break;case 22:c=e.memoizedState!==null;var f=o!==null&&o.memoizedState!==null,p=xb,m=Sb;if(xb=p||c,Sb=m||f,Pc(t,e),Sb=m,xb=p,f&&!c&&!p&&!m&&(e.mode&V)!==B&&0<=U&&0<=W&&.05<W-U&&nr(e,U,W),Ic(e),s&8192)a:for(t=e.stateNode,t._visibility=c?t._visibility&~Ng:t._visibility|Ng,!c||o===null||f||xb||Sb||(Bc(e),(e.mode&V)!==B&&0<=U&&0<=W&&.05<W-U&&tr(e,U,W,`Disconnect`)),o=null,t=e;;){if(t.tag===5||t.tag===26){if(o===null){f=o=t;try{l=f.stateNode,c?w(f,dd,l):w(f,md,f.stateNode,f.memoizedProps)}catch(e){j(f,f.return,e)}}}else if(t.tag===6){if(o===null){f=t;try{u=f.stateNode,c?w(f,fd,u):w(f,hd,u,f.memoizedProps)}catch(e){j(f,f.return,e)}}}else if(t.tag===18){if(o===null){f=t;try{d=f.stateNode,c?w(f,ud,d):w(f,pd,f.stateNode)}catch(e){j(f,f.return,e)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break a;for(;t.sibling===null;){if(t.return===null||t.return===e)break a;o===t&&(o=null),t=t.return}o===t&&(o=null),t.sibling.return=t.return,t=t.sibling}s&4&&(s=e.updateQueue,s!==null&&(o=s.retryQueue,o!==null&&(s.retryQueue=null,Nc(e,o))));break;case 19:Pc(t,e),Ic(e),s&4&&(s=e.updateQueue,s!==null&&(e.updateQueue=null,Nc(e,s)));break;case 30:break;case 21:break;default:Pc(t,e),Ic(e)}(e.mode&V)!==B&&0<=U&&0<=W&&((M_||.05<A_)&&ar(e,U,W,A_,j_),e.alternate===null&&e.return!==null&&e.return.alternate!==null&&.05<W-U&&(wc(e.return.alternate,e.return)||tr(e,U,W,`Mount`))),xi(n),Ci(r),j_=i,M_=a}function Ic(e){var t=e.flags;if(t&2){try{w(e,Sc,e)}catch(t){j(e,e.return,t)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Lc(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Lc(t),t.tag===5&&t.flags&1024&&t.stateNode.reset(),e=e.sibling}}function Rc(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)Ec(e,t.alternate,t),t=t.sibling}function zc(e){var t=bi(),n=Si(),r=wi(),i=Ti();switch(e.tag){case 0:case 11:case 14:case 15:nc(e,e.return,xy),Bc(e);break;case 1:pc(e,e.return);var a=e.stateNode;typeof a.componentWillUnmount==`function`&&uc(e,e.return,a),Bc(e);break;case 27:w(e,Nd,e.stateNode);case 26:case 5:pc(e,e.return),Bc(e);break;case 22:e.memoizedState===null&&Bc(e);break;case 30:Bc(e);break;default:Bc(e)}(e.mode&V)!==B&&0<=U&&0<=W&&(M_||.05<A_)&&ar(e,U,W,A_,j_),xi(t),Ci(n),j_=r,M_=i}function Bc(e){for(e=e.child;e!==null;)zc(e),e=e.sibling}function Vc(e,t,n,r){var i=bi(),a=Si(),o=wi(),s=Ti(),c=n.flags;switch(n.tag){case 0:case 11:case 15:Hc(e,n,r),tc(n,xy);break;case 1:if(Hc(e,n,r),t=n.stateNode,typeof t.componentDidMount==`function`&&w(n,kv,n,t),t=n.updateQueue,t!==null){e=n.stateNode;try{w(n,pa,t,e)}catch(e){j(n,n.return,e)}}r&&c&64&&sc(n),fc(n,n.return);break;case 27:Cc(n);case 26:case 5:Hc(e,n,r),r&&t===null&&c&4&&gc(n),fc(n,n.return);break;case 12:if(r&&c&4){c=gi(),Hc(e,n,r),r=n.stateNode,r.effectDuration+=vi(c);try{w(n,mc,n,t,T_,r.effectDuration)}catch(e){j(n,n.return,e)}}else Hc(e,n,r);break;case 31:Hc(e,n,r),r&&c&4&&Ac(e,n);break;case 13:Hc(e,n,r),r&&c&4&&jc(e,n);break;case 22:n.memoizedState===null&&Hc(e,n,r),fc(n,n.return);break;case 30:break;default:Hc(e,n,r)}(n.mode&V)!==B&&0<=U&&0<=W&&(M_||.05<A_)&&ar(n,U,W,A_,j_),xi(i),Ci(a),j_=o,M_=s}function Hc(e,t,n){for(n&&=(t.subtreeFlags&8772)!=0,t=t.child;t!==null;)Vc(e,t.alternate,t,n),t=t.sibling}function Uc(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&fi(e),n!=null&&pi(n))}function Wc(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(fi(t),e!=null&&pi(e))}function Gc(e,t,n,r,i){if(t.subtreeFlags&10256||t.actualDuration!==0&&(t.alternate===null||t.alternate.child!==t.child))for(t=t.child;t!==null;){var a=t.sibling;Kc(e,t,n,r,a===null?i:a.actualStartTime),t=a}}function Kc(e,t,n,r,i){var a=bi(),o=Si(),s=wi(),c=Ti(),l=Dg,u=t.flags;switch(t.tag){case 0:case 11:case 15:(t.mode&V)!==B&&0<t.actualStartTime&&t.flags&1&&rr(t,t.actualStartTime,i,jb,n),Gc(e,t,n,r,i),u&2048&&ac(t,Sy|yy);break;case 1:(t.mode&V)!==B&&0<t.actualStartTime&&(t.flags&128?ir(t,t.actualStartTime,i,[]):t.flags&1&&rr(t,t.actualStartTime,i,jb,n)),Gc(e,t,n,r,i);break;case 3:var d=gi(),f=jb;jb=t.alternate!==null&&t.alternate.memoizedState.isDehydrated&&(t.flags&256)==0,Gc(e,t,n,r,i),jb=f,u&2048&&(n=null,t.alternate!==null&&(n=t.alternate.memoizedState.cache),r=t.memoizedState.cache,r!==n&&(fi(r),n!=null&&pi(n))),e.passiveEffectDuration+=_i(d);break;case 12:if(u&2048){u=gi(),Gc(e,t,n,r,i),e=t.stateNode,e.passiveEffectDuration+=vi(u);try{w(t,hc,t,t.alternate,T_,e.passiveEffectDuration)}catch(e){j(t,t.return,e)}}else Gc(e,t,n,r,i);break;case 31:u=jb,d=t.alternate===null?null:t.alternate.memoizedState,f=t.memoizedState,d!==null&&f===null?(f=t.deletions,f!==null&&0<f.length&&f[0].tag===18?(jb=!1,d=d.hydrationErrors,d!==null&&ir(t,t.actualStartTime,i,d)):jb=!0):jb=!1,Gc(e,t,n,r,i),jb=u;break;case 13:u=jb,d=t.alternate===null?null:t.alternate.memoizedState,f=t.memoizedState,d===null||d.dehydrated===null||f!==null&&f.dehydrated!==null?jb=!1:(f=t.deletions,f!==null&&0<f.length&&f[0].tag===18?(jb=!1,d=d.hydrationErrors,d!==null&&ir(t,t.actualStartTime,i,d)):jb=!0),Gc(e,t,n,r,i),jb=u;break;case 23:break;case 22:f=t.stateNode,d=t.alternate,t.memoizedState===null?f._visibility&Pg?Gc(e,t,n,r,i):(f._visibility|=Pg,qc(e,t,n,r,(t.subtreeFlags&10256)!=0||t.actualDuration!==0&&(t.alternate===null||t.alternate.child!==t.child),i),(t.mode&V)===B||jb||(e=t.actualStartTime,0<=e&&.05<i-e&&nr(t,e,i),0<=U&&0<=W&&.05<W-U&&nr(t,U,W))):f._visibility&Pg?Gc(e,t,n,r,i):Yc(e,t,n,r,i),u&2048&&Uc(d,t);break;case 24:Gc(e,t,n,r,i),u&2048&&Wc(t.alternate,t);break;default:Gc(e,t,n,r,i)}(t.mode&V)!==B&&((e=!jb&&t.alternate===null&&t.return!==null&&t.return.alternate!==null)&&(n=t.actualStartTime,0<=n&&.05<i-n&&tr(t,n,i,`Mount`)),0<=U&&0<=W&&((M_||.05<A_)&&ar(t,U,W,A_,j_),e&&.05<W-U&&tr(t,U,W,`Mount`))),xi(a),Ci(o),j_=s,M_=c,Dg=l}function qc(e,t,n,r,i,a){for(i&&=(t.subtreeFlags&10256)!=0||t.actualDuration!==0&&(t.alternate===null||t.alternate.child!==t.child),t=t.child;t!==null;){var o=t.sibling;Jc(e,t,n,r,i,o===null?a:o.actualStartTime),t=o}}function Jc(e,t,n,r,i,a){var o=bi(),s=Si(),c=wi(),l=Ti(),u=Dg;i&&(t.mode&V)!==B&&0<t.actualStartTime&&t.flags&1&&rr(t,t.actualStartTime,a,jb,n);var d=t.flags;switch(t.tag){case 0:case 11:case 15:qc(e,t,n,r,i,a),ac(t,Sy);break;case 23:break;case 22:var f=t.stateNode;t.memoizedState===null?(f._visibility|=Pg,qc(e,t,n,r,i,a)):f._visibility&Pg?qc(e,t,n,r,i,a):Yc(e,t,n,r,a),i&&d&2048&&Uc(t.alternate,t);break;case 24:qc(e,t,n,r,i,a),i&&d&2048&&Wc(t.alternate,t);break;default:qc(e,t,n,r,i,a)}(t.mode&V)!==B&&0<=U&&0<=W&&(M_||.05<A_)&&ar(t,U,W,A_,j_),xi(o),Ci(s),j_=c,M_=l,Dg=u}function Yc(e,t,n,r,i){if(t.subtreeFlags&10256||t.actualDuration!==0&&(t.alternate===null||t.alternate.child!==t.child))for(var a=t.child;a!==null;){t=a.sibling;var o=e,s=n,c=r,l=t===null?i:t.actualStartTime,u=Dg;(a.mode&V)!==B&&0<a.actualStartTime&&a.flags&1&&rr(a,a.actualStartTime,l,jb,s);var d=a.flags;switch(a.tag){case 22:Yc(o,a,s,c,l),d&2048&&Uc(a.alternate,a);break;case 24:Yc(o,a,s,c,l),d&2048&&Wc(a.alternate,a);break;default:Yc(o,a,s,c,l)}Dg=u,a=t}}function Xc(e,t,n){if(e.subtreeFlags&Mb)for(e=e.child;e!==null;)Zc(e,t,n),e=e.sibling}function Zc(e,t,n){switch(e.tag){case 26:Xc(e,t,n),e.flags&Mb&&e.memoizedState!==null&&Qd(n,Ab,e.memoizedState,e.memoizedProps);break;case 5:Xc(e,t,n);break;case 3:case 4:var r=Ab;Ab=Pd(e.stateNode.containerInfo),Xc(e,t,n),Ab=r;break;case 22:e.memoizedState===null&&(r=e.alternate,r!==null&&r.memoizedState!==null?(r=Mb,Mb=16777216,Xc(e,t,n),Mb=r):Xc(e,t,n));break;default:Xc(e,t,n)}}function Qc(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function $c(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n],i=bi();Tb=r,rl(r,e),(r.mode&V)!==B&&0<=U&&0<=W&&.05<W-U&&tr(r,U,W,`Unmount`),xi(i)}Qc(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)el(e),e=e.sibling}function el(e){var t=bi(),n=Si(),r=wi(),i=Ti();switch(e.tag){case 0:case 11:case 15:$c(e),e.flags&2048&&oc(e,e.return,Sy|yy);break;case 3:var a=gi();$c(e),e.stateNode.passiveEffectDuration+=_i(a);break;case 12:a=gi(),$c(e),e.stateNode.passiveEffectDuration+=vi(a);break;case 22:a=e.stateNode,e.memoizedState!==null&&a._visibility&Pg&&(e.return===null||e.return.tag!==13)?(a._visibility&=~Pg,tl(e),(e.mode&V)!==B&&0<=U&&0<=W&&.05<W-U&&tr(e,U,W,`Disconnect`)):$c(e);break;default:$c(e)}(e.mode&V)!==B&&0<=U&&0<=W&&(M_||.05<A_)&&ar(e,U,W,A_,j_),xi(t),Ci(n),M_=i,j_=r}function tl(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n],i=bi();Tb=r,rl(r,e),(r.mode&V)!==B&&0<=U&&0<=W&&.05<W-U&&tr(r,U,W,`Unmount`),xi(i)}Qc(e)}for(e=e.child;e!==null;)nl(e),e=e.sibling}function nl(e){var t=bi(),n=Si(),r=wi(),i=Ti();switch(e.tag){case 0:case 11:case 15:oc(e,e.return,Sy),tl(e);break;case 22:var a=e.stateNode;a._visibility&Pg&&(a._visibility&=~Pg,tl(e));break;default:tl(e)}(e.mode&V)!==B&&0<=U&&0<=W&&(M_||.05<A_)&&ar(e,U,W,A_,j_),xi(t),Ci(n),M_=i,j_=r}function rl(e,t){for(;Tb!==null;){var n=Tb,r=n,i=t,a=bi(),o=Si(),s=wi(),c=Ti();switch(r.tag){case 0:case 11:case 15:oc(r,i,Sy);break;case 23:case 22:r.memoizedState!==null&&r.memoizedState.cachePool!==null&&(i=r.memoizedState.cachePool.pool,i!=null&&fi(i));break;case 24:pi(r.memoizedState.cache)}if((r.mode&V)!==B&&0<=U&&0<=W&&(M_||.05<A_)&&ar(r,U,W,A_,j_),xi(a),Ci(o),M_=c,j_=s,r=n.child,r!==null)r.return=n,Tb=r;else a:for(n=e;Tb!==null;){if(r=Tb,a=r.sibling,o=r.return,Dc(r),r===n){Tb=null;break a}if(a!==null){a.return=o,Tb=a;break a}Tb=o}}}function il(){Fb.forEach(function(e){return e()})}function al(){var e=typeof IS_REACT_ACT_ENVIRONMENT<`u`?IS_REACT_ACT_ENVIRONMENT:void 0;return e||F.actQueue===null||console.error(`The current testing environment is not configured to support act(...)`),e}function ol(e){if((Y&Rb)!==Lb&&Q!==0)return Q&-Q;var t=F.T;return t===null?Xe():(t._updatedFibers||=new Set,t._updatedFibers.add(e),lu())}function sl(){if(fx===0)if(!(Q&536870912)||H){var e=Wp;Wp<<=1,!(Wp&3932160)&&(Wp=262144),fx=e}else fx=536870912;return e=py.current,e!==null&&(e.flags|=32),fx}function cl(e,t,n){if(eS&&console.error(`useInsertionEffect must not schedule updates.`),Yx&&(Xx=!0),(e===X&&($===Yb||$===nx)||e.cancelPendingCommit!==null)&&(gl(e,0),fl(e,Q,fx,!1)),Ve(e,n),(Y&Rb)!==Lb&&e===X){if(xp)switch(t.tag){case 0:case 11:case 15:e=Z&&S(Z)||`Unknown`,rS.has(e)||(rS.add(e),t=S(t)||`Unknown`,console.error("Cannot update a component (`%s`) while rendering a different component (`%s`). To locate the bad setState() call inside `%s`, follow the stack trace as described in https://react.dev/link/setstate-in-render",t,e,e));break;case 1:nS||=(console.error("Cannot update during an existing state transition (such as within `render`). Render methods should be a pure function of props and state."),!0)}}else zp&&qe(e,t,n),$l(t),e===X&&((Y&Rb)===Lb&&(ux|=n),cx===Wb&&fl(e,Q,fx,!1)),eu(e)}function ll(e,t,n){if((Y&(Rb|zb))!==Lb)throw Error(`Should not already be working.`);if(Q!==0&&Z!==null){var r=Z,i=Dp();switch(iv){case Xb:case Yb:var a=av;L&&((r=r._debugTask)?r.run(console.timeStamp.bind(console,`Suspended`,a,i,Eg,void 0,`primary-light`)):console.timeStamp(`Suspended`,a,i,Eg,void 0,`primary-light`));break;case nx:a=av,L&&((r=r._debugTask)?r.run(console.timeStamp.bind(console,`Action`,a,i,Eg,void 0,`primary-light`)):console.timeStamp(`Action`,a,i,Eg,void 0,`primary-light`));break;default:L&&(r=i-av,3>r||console.timeStamp(`Blocked`,av,i,Eg,void 0,5>r?`primary-light`:10>r?`primary`:100>r?`primary-dark`:`error`))}}a=(n=!n&&(t&127)==0&&(t&e.expiredLanes)===0||Le(e,t))?Tl(e,t):Cl(e,t,!0);var o=n;do{if(a===Bb){ax&&!n&&fl(e,t,0,!1),t=$,av=b_(),iv=t;break}else{if(r=Dp(),i=e.current.alternate,o&&!dl(i)){er(t),i=w_,a=r,!L||a<=i||(Cx?Cx.run(console.timeStamp.bind(console,`Teared Render`,i,a,z,R,`error`)):console.timeStamp(`Teared Render`,i,a,z,R,`error`)),hl(t,r),a=Cl(e,t,!1),o=!1;continue}if(a===Hb){if(o=t,e.errorRecoveryDisabledLanes&o)var s=0;else s=e.pendingLanes&-536870913,s=s===0?s&536870912?536870912:0:s;if(s!==0){er(t),ur(w_,r,t,Cx),hl(t,r),t=s;a:{r=e,a=o,o=mx;var c=r.current.memoizedState.isDehydrated;if(c&&(gl(r,s).flags|=256),s=Cl(r,s,!1),s!==Hb){if(ox&&!c){r.errorRecoveryDisabledLanes|=a,ux|=a,a=Wb;break a}r=hx,hx=o,r!==null&&(hx===null?hx=r:hx.push.apply(hx,r))}a=s}if(o=!1,a!==Hb)continue;r=Dp()}}if(a===Vb){er(t),ur(w_,r,t,Cx),hl(t,r),gl(e,0),fl(e,t,0,!0);break}a:{switch(n=e,a){case Bb:case Vb:throw Error(`Root did not complete. This is a bug in React.`);case Wb:if((t&4194048)!==t)break;case Gb:er(t),sr(w_,r,t,Cx),hl(t,r),i=t,i&127?H_=r:i&4194048&&($_=r),fl(n,t,fx,!ix);break a;case Hb:hx=null;break;case Ub:case Kb:break;default:throw Error(`Unknown root exit status.`)}if(F.actQueue!==null)Nl(n,i,t,hx,Sx,gx,fx,ux,px,a,null,null,w_,r);else{if((t&62914560)===t&&(o=_x+yx-Dp(),10<o)){if(fl(n,t,fx,!ix),Ie(n,0,!0)!==0)break a;Rx=t,n.timeoutHandle=QS(ul.bind(null,n,i,hx,Sx,gx,t,fx,ux,px,ix,a,`Throttled`,w_,r),o);break a}ul(n,i,hx,Sx,gx,t,fx,ux,px,ix,a,null,w_,r)}}}break}while(1);eu(e)}function ul(e,t,n,r,i,a,o,s,c,l,u,d,f,p){e.timeoutHandle=eC;var m=t.subtreeFlags,h=null;if((m&8192||(m&16785408)==16785408)&&(h={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:dn},Zc(t,a,h),m=(a&62914560)===a?_x-Dp():(a&4194048)===a?vx-Dp():0,m=$d(h,m),m!==null)){Rx=a,e.cancelPendingCommit=m(Nl.bind(null,e,t,a,n,r,i,o,s,c,u,h,h.waitingForViewTransition?`Waiting for the previous Animation`:0<h.count?0<h.imgCount?`Suspended on CSS and Images`:`Suspended on CSS`:h.imgCount===1?`Suspended on an Image`:0<h.imgCount?`Suspended on Images`:null,f,p)),fl(e,a,o,!l);return}Nl(e,t,a,n,r,i,o,s,c,u,h,d,f,p)}function dl(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var r=0;r<n.length;r++){var i=n[r],a=i.getSnapshot;i=i.value;try{if(!Yh(a(),i))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function fl(e,t,n,r){t&=~dx,t&=~ux,e.suspendedLanes|=t,e.pingedLanes&=~t,r&&(e.warmLanes|=t),r=e.expirationTimes;for(var i=t;0<i;){var a=31-Bp(i),o=1<<a;r[a]=-1,i&=~o}n!==0&&Ue(e,n,t)}function pl(){return(Y&(Rb|zb))===Lb?(tu(0,!1),!1):!0}function ml(){if(Z!==null){if($===qb)var e=Z.return;else e=Z,ei(),Pa(e),Jv=null,Yv=0,e=Z;for(;e!==null;)$s(e.alternate,e),e=e.return;Z=null}}function hl(e,t){e&127&&(N_=t),e&4194048&&(U_=t),e&62914560&&(ev=t),e&2080374784&&(tv=t)}function gl(e,t){L&&(console.timeStamp(`Blocking Track`,.003,.003,`Blocking`,R,`primary-light`),console.timeStamp(`Transition Track`,.003,.003,`Transition`,R,`primary-light`),console.timeStamp(`Suspense Track`,.003,.003,`Suspense`,R,`primary-light`),console.timeStamp(`Idle Track`,.003,.003,`Idle`,R,`primary-light`));var n=w_;if(w_=b_(),Q!==0&&0<n){if(er(Q),cx===Ub||cx===Wb)sr(n,w_,t,Cx);else{var r=w_,i=Cx;if(L&&!(r<=n)){var a=(t&738197653)===t?`tertiary-dark`:`primary-dark`,o=(t&536870912)===t?`Prewarm`:(t&201326741)===t?`Interrupted Hydration`:`Interrupted Render`;i?i.run(console.timeStamp.bind(console,o,n,r,z,R,a)):console.timeStamp(o,n,r,z,R,a)}}hl(Q,w_)}if(n=Cx,Cx=null,t&127){Cx=F_,i=0<=P_&&P_<N_?N_:P_,r=0<=z_&&z_<N_?N_:z_,a=0<=r?r:0<=i?i:w_,0<=H_?(er(2),cr(H_,a,t,n)):nv&127&&(er(2),pr(N_,a,rv)),n=i;var s=r,c=B_,l=0<V_,u=I_===S_,d=I_===C_;if(i=w_,r=F_,a=L_,o=R_,L){if(z=`Blocking`,0<n?n>i&&(n=i):n=i,0<s?s>n&&(s=n):s=n,c!==null&&n>s){var f=l?`secondary-light`:`warning`;r?r.run(console.timeStamp.bind(console,l?`Consecutive`:`Event: `+c,s,n,z,R,f)):console.timeStamp(l?`Consecutive`:`Event: `+c,s,n,z,R,f)}i>n&&(s=u?`error`:(t&738197653)===t?`tertiary-light`:`primary-light`,u=d?`Promise Resolved`:u?`Cascading Update`:5<i-n?`Update Blocked`:`Update`,d=[],o!=null&&d.push([`Component name`,o]),a!=null&&d.push([`Method name`,a]),n={start:n,end:i,detail:{devtools:{properties:d,track:z,trackGroup:R,color:s}}},r?r.run(performance.measure.bind(performance,u,n)):performance.measure(u,n))}P_=-1.1,I_=0,R_=L_=null,H_=-1.1,V_=z_,z_=-1.1,N_=b_()}if(t&4194048&&(Cx=q_,i=0<=W_&&W_<U_?U_:W_,n=0<=G_&&G_<U_?U_:G_,r=0<=X_&&X_<U_?U_:X_,a=0<=r?r:0<=n?n:w_,0<=$_?(er(256),cr($_,a,t,Cx)):nv&4194048&&(er(256),pr(U_,a,rv)),d=r,s=Z_,c=0<Q_,l=K_===C_,a=w_,r=q_,o=J_,u=Y_,L&&(z=`Transition`,0<n?n>a&&(n=a):n=a,0<i?i>n&&(i=n):i=n,0<d?d>i&&(d=i):d=i,i>d&&s!==null&&(f=c?`secondary-light`:`warning`,r?r.run(console.timeStamp.bind(console,c?`Consecutive`:`Event: `+s,d,i,z,R,f)):console.timeStamp(c?`Consecutive`:`Event: `+s,d,i,z,R,f)),n>i&&(r?r.run(console.timeStamp.bind(console,`Action`,i,n,z,R,`primary-dark`)):console.timeStamp(`Action`,i,n,z,R,`primary-dark`)),a>n&&(i=l?`Promise Resolved`:5<a-n?`Update Blocked`:`Update`,d=[],u!=null&&d.push([`Component name`,u]),o!=null&&d.push([`Method name`,o]),n={start:n,end:a,detail:{devtools:{properties:d,track:z,trackGroup:R,color:`primary-light`}}},r?r.run(performance.measure.bind(performance,i,n)):performance.measure(i,n))),G_=W_=-1.1,K_=0,$_=-1.1,Q_=X_,X_=-1.1,U_=b_()),t&62914560&&nv&62914560&&(er(4194304),pr(ev,w_,rv)),t&2080374784&&nv&2080374784&&(er(268435456),pr(tv,w_,rv)),n=e.timeoutHandle,n!==eC&&(e.timeoutHandle=eC,$S(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),Rx=0,ml(),X=e,Z=n=Dr(e.current,null),Q=t,$=qb,rx=null,ix=!1,ax=Le(e,t),ox=!1,cx=Bb,px=fx=dx=ux=lx=0,hx=mx=null,gx=!1,t&8&&(t|=t&32),r=e.entangledLanes,r!==0)for(e=e.entanglements,r&=t;0<r;)i=31-Bp(r),a=1<<i,t|=e[i],r&=~a;return sx=t,mr(),e=hg(),1e3<e-pg&&(F.recentlyCreatedOwnerStacks=0,pg=e),mv.discardPendingWarnings(),n}function _l(e,t){K=null,F.H=Vy,F.getCurrentStack=null,xp=!1,bp=null,t===Hv||t===Wv?(t=Ui(),$=Xb):t===Uv?(t=Ui(),$=Zb):$=t===lb?tx:typeof t==`object`&&t&&typeof t.then==`function`?$b:Jb,rx=t;var n=Z;n===null?(cx=Vb,ds(e,Fr(t,e.current))):n.mode&V&&Di(n)}function vl(){var e=py.current;return e===null?!0:(Q&4194048)===Q?my===null:(Q&62914560)===Q||Q&536870912?e===my:!1}function yl(){var e=F.H;return F.H=Vy,e===null?Vy:e}function bl(){var e=F.A;return F.A=Nb,e}function xl(e){Cx===null&&(Cx=e._debugTask==null?null:e._debugTask)}function Sl(){cx=Wb,ix||(Q&4194048)!==Q&&py.current!==null||(ax=!0),!(lx&134217727)&&!(ux&134217727)||X===null||fl(X,Q,fx,!1)}function Cl(e,t,n){var r=Y;Y|=Rb;var i=yl(),a=bl();if(X!==e||Q!==t){if(zp){var o=e.memoizedUpdaters;0<o.size&&(Zl(e,Q),o.clear()),Je(e,t)}Sx=null,gl(e,t)}t=!1,o=cx;a:do try{if($!==qb&&Z!==null){var s=Z,c=rx;switch($){case tx:ml(),o=Gb;break a;case Xb:case Yb:case nx:case $b:py.current===null&&(t=!0);var l=$;if($=qb,rx=null,Al(e,s,c,l),n&&ax){o=Bb;break a}break;default:l=$,$=qb,rx=null,Al(e,s,c,l)}}wl(),o=cx;break}catch(t){_l(e,t)}while(1);return t&&e.shellSuspendCounter++,ei(),Y=r,F.H=i,F.A=a,Z===null&&(X=null,Q=0,mr()),o}function wl(){for(;Z!==null;)Dl(Z)}function Tl(e,t){var n=Y;Y|=Rb;var r=yl(),i=bl();if(X!==e||Q!==t){if(zp){var a=e.memoizedUpdaters;0<a.size&&(Zl(e,Q),a.clear()),Je(e,t)}Sx=null,bx=Dp()+xx,gl(e,t)}else ax=Le(e,t);a:do try{if($!==qb&&Z!==null)b:switch(t=Z,a=rx,$){case Jb:$=qb,rx=null,Al(e,t,a,Jb);break;case Yb:case nx:if(Bi(a)){$=qb,rx=null,Ol(t);break}t=function(){$!==Yb&&$!==nx||X!==e||($=ex),eu(e)},a.then(t,t);break a;case Xb:$=ex;break a;case Zb:$=Qb;break a;case ex:Bi(a)?($=qb,rx=null,Ol(t)):($=qb,rx=null,Al(e,t,a,ex));break;case Qb:var o=null;switch(Z.tag){case 26:o=Z.memoizedState;case 5:case 27:var s=Z;if(o?Zd(o):s.stateNode.complete){$=qb,rx=null;var c=s.sibling;if(c!==null)Z=c;else{var l=s.return;l===null?Z=null:(Z=l,jl(l))}break b}break;default:console.error(`Unexpected type of fiber triggered a suspensey commit. This is a bug in React.`)}$=qb,rx=null,Al(e,t,a,Qb);break;case $b:$=qb,rx=null,Al(e,t,a,$b);break;case tx:ml(),cx=Gb;break a;default:throw Error(`Unexpected SuspendedReason. This is a bug in React.`)}F.actQueue===null?El():wl();break}catch(t){_l(e,t)}while(1);return ei(),F.H=r,F.A=i,Y=n,Z===null?(X=null,Q=0,mr(),cx):Bb}function El(){for(;Z!==null&&!Tp();)Dl(Z)}function Dl(e){var t=e.alternate;(e.mode&V)===B?t=w(e,Gs,t,e,sx):(Ei(e),t=w(e,Gs,t,e,sx),Di(e)),e.memoizedProps=e.pendingProps,t===null?jl(e):Z=t}function Ol(e){var t=w(e,kl,e);e.memoizedProps=e.pendingProps,t===null?jl(e):Z=t}function kl(e){var t=e.alternate,n=(e.mode&V)!==B;switch(n&&Ei(e),e.tag){case 15:case 0:t=ks(t,e,e.pendingProps,e.type,void 0,Q);break;case 11:t=ks(t,e,e.pendingProps,e.type.render,e.ref,Q);break;case 5:Pa(e);default:$s(t,e),e=Z=Or(e,sx),t=Gs(t,e,sx)}return n&&Di(e),t}function Al(e,t,n,r){ei(),Pa(t),Jv=null,Yv=0;var i=t.return;try{if(gs(e,i,t,n,Q)){cx=Vb,ds(e,Fr(n,e.current)),Z=null;return}}catch(t){if(i!==null)throw Z=i,t;cx=Vb,ds(e,Fr(n,e.current)),Z=null;return}t.flags&32768?(H||r===Jb?e=!0:ax||Q&536870912?e=!1:(ix=e=!0,(r===Yb||r===nx||r===Xb||r===$b)&&(r=py.current,r!==null&&r.tag===13&&(r.flags|=16384))),Ml(t,e)):jl(t)}function jl(e){var t=e;do{if(t.flags&32768){Ml(t,ix);return}var n=t.alternate;if(e=t.return,Ei(t),n=w(t,Zs,n,t,sx),(t.mode&V)!==B&&Oi(t),n!==null){Z=n;return}if(t=t.sibling,t!==null){Z=t;return}Z=t=e}while(t!==null);cx===Bb&&(cx=Kb)}function Ml(e,t){do{var n=Qs(e.alternate,e);if(n!==null){n.flags&=32767,Z=n;return}if((e.mode&V)!==B){Oi(e),n=e.actualDuration;for(var r=e.child;r!==null;)n+=r.actualDuration,r=r.sibling;e.actualDuration=n}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){Z=e;return}Z=e=n}while(e!==null);cx=Gb,Z=null}function Nl(e,t,n,r,i,a,o,s,c,l,u,d,f,p){e.cancelPendingCommit=null;do zl();while(Fx!==kx);if(mv.flushLegacyContextWarning(),mv.flushPendingUnsafeLifecycleWarnings(),(Y&(Rb|zb))!==Lb)throw Error(`Should not already be working.`);if(er(n),l===Hb?ur(f,p,n,Cx):r===null?or(f,p,n,Cx):lr(f,p,n,r,t!==null&&t.alternate!==null&&t.alternate.memoizedState.isDehydrated&&(t.flags&256)!=0,Cx),t!==null){if(n===0&&console.error(`finishedLanes should not be empty during a commit. This is a bug in React.`),t===e.current)throw Error(`Cannot commit the same tree as before. This error is likely caused by a bug in React. Please file an issue.`);if(a=t.lanes|t.childLanes,a|=Lg,He(e,n,a,o,s,c),e===X&&(Z=X=null,Q=0),Lx=t,Ix=e,Rx=n,zx=a,Vx=i,Hx=r,Bx=p,Ux=d,Wx=Tx,Gx=null,t.actualDuration!==0||t.subtreeFlags&10256||t.flags&10256?(e.callbackNode=null,e.callbackPriority=0,Ql(jp,function(){return ZS=window.event,Wx===Tx&&(Wx=Dx),Bl(),null})):(e.callbackNode=null,e.callbackPriority=0),D_=null,T_=b_(),d!==null&&dr(p,T_,d,Cx),r=(t.flags&13878)!=0,t.subtreeFlags&13878||r){r=F.T,F.T=null,i=I.p,I.p=Kp,o=Y,Y|=zb;try{Tc(e,t,n)}finally{Y=o,I.p=i,F.T=r}}Fx=Ax,Pl(),Fl(),Il()}}function Pl(){if(Fx===Ax){Fx=kx;var e=Ix,t=Lx,n=Rx,r=(t.flags&13878)!=0;if(t.subtreeFlags&13878||r){r=F.T,F.T=null;var i=I.p;I.p=Kp;var a=Y;Y|=zb;try{Eb=n,Db=e,yi(),Fc(t,e),Db=Eb=null,n=JS;var o=Wn(e.containerInfo),s=n.focusedElem,c=n.selectionRange;if(o!==s&&s&&s.ownerDocument&&Un(s.ownerDocument.documentElement,s)){if(c!==null&&Gn(s)){var l=c.start,u=c.end;if(u===void 0&&(u=l),`selectionStart`in s)s.selectionStart=l,s.selectionEnd=Math.min(u,s.value.length);else{var d=s.ownerDocument||document,f=d&&d.defaultView||window;if(f.getSelection){var p=f.getSelection(),m=s.textContent.length,h=Math.min(c.start,m),g=c.end===void 0?h:Math.min(c.end,m);!p.extend&&h>g&&(o=g,g=h,h=o);var _=Hn(s,h),v=Hn(s,g);if(_&&v&&(p.rangeCount!==1||p.anchorNode!==_.node||p.anchorOffset!==_.offset||p.focusNode!==v.node||p.focusOffset!==v.offset)){var y=d.createRange();y.setStart(_.node,_.offset),p.removeAllRanges(),h>g?(p.addRange(y),p.extend(v.node,v.offset)):(y.setEnd(v.node,v.offset),p.addRange(y))}}}}for(d=[],p=s;p=p.parentNode;)p.nodeType===1&&d.push({element:p,left:p.scrollLeft,top:p.scrollTop});for(typeof s.focus==`function`&&s.focus(),s=0;s<d.length;s++){var b=d[s];b.element.scrollLeft=b.left,b.element.scrollTop=b.top}}RC=!!qS,JS=qS=null}finally{Y=a,I.p=i,F.T=r}}e.current=t,Fx=jx}}function Fl(){if(Fx===jx){Fx=kx;var e=Gx;if(e!==null){T_=b_();var t=E_,n=T_;!L||n<=t||(rv?rv.run(console.timeStamp.bind(console,e,t,n,z,R,`secondary-light`)):console.timeStamp(e,t,n,z,R,`secondary-light`))}e=Ix,t=Lx,n=Rx;var r=(t.flags&8772)!=0;if(t.subtreeFlags&8772||r){r=F.T,F.T=null;var i=I.p;I.p=Kp;var a=Y;Y|=zb;try{Eb=n,Db=e,yi(),Ec(e,t.alternate,t),Db=Eb=null}finally{Y=a,I.p=i,F.T=r}}e=Bx,t=Ux,E_=b_(),e=t===null?e:T_,t=E_,n=Wx===Ex,r=Cx,D_===null?!L||t<=e||(r?r.run(console.timeStamp.bind(console,n?`Commit Interrupted View Transition`:`Commit`,e,t,z,R,n?`error`:`secondary-dark`)):console.timeStamp(n?`Commit Interrupted View Transition`:`Commit`,e,t,z,R,n?`error`:`secondary-dark`)):fr(e,t,D_,!1,r),Fx=Mx}}function Il(){if(Fx===Nx||Fx===Mx){if(Fx===Nx){var e=E_;E_=b_();var t=E_,n=Wx===Ex;!L||t<=e||(rv?rv.run(console.timeStamp.bind(console,n?`Interrupted View Transition`:`Starting Animation`,e,t,z,R,n?`error`:`secondary-light`)):console.timeStamp(n?`Interrupted View Transition`:`Starting Animation`,e,t,z,R,n?` error`:`secondary-light`)),Wx!==Ex&&(Wx=Ox)}Fx=kx,Ep(),e=Ix;var r=Lx;t=Rx,n=Hx;var i=r.actualDuration!==0||(r.subtreeFlags&10256)!=0||(r.flags&10256)!=0;i?Fx=Px:(Fx=kx,Lx=Ix=null,Rl(e,e.pendingLanes),Qx=0,$x=null);var a=e.pendingLanes;if(a===0&&(wx=null),i||Yl(e),a=Ye(t),r=r.stateNode,Lp&&typeof Lp.onCommitFiberRoot==`function`)try{var o=(r.current.flags&128)==128;switch(a){case Kp:var s=kp;break;case qp:s=Ap;break;case Jp:s=jp;break;case Yp:s=Np;break;default:s=jp}Lp.onCommitFiberRoot(Ip,r,s,o)}catch(e){Rp||(Rp=!0,console.error(`React instrumentation encountered an error: %o`,e))}if(zp&&e.memoizedUpdaters.clear(),il(),n!==null){o=F.T,s=I.p,I.p=Kp,F.T=null;try{var c=e.onRecoverableError;for(r=0;r<n.length;r++){var l=n[r],u=Ll(l.stack);w(l.source,c,l.value,u)}}finally{F.T=o,I.p=s}}Rx&3&&zl(),eu(e),a=e.pendingLanes,t&261930&&a&42?(sv=!0,e===Jx?qx++:(qx=0,Jx=e)):qx=0,i||hl(t,E_),tu(0,!1)}}function Ll(e){return e={componentStack:e},Object.defineProperty(e,`digest`,{get:function(){console.error(`You are accessing "digest" from the errorInfo object passed to onRecoverableError. This property is no longer provided as part of errorInfo but can be accessed as a property of the Error instance itself.`)}}),e}function Rl(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,pi(t)))}function zl(){return Pl(),Fl(),Il(),Bl()}function Bl(){if(Fx!==Px)return!1;var e=Ix,t=zx;zx=0;var n=Ye(Rx),r=Jp===0||Jp>n?Jp:n;n=F.T;var i=I.p;try{I.p=r,F.T=null;var a=Vx;Vx=null,r=Ix;var o=Rx;if(Fx=kx,Lx=Ix=null,Rx=0,(Y&(Rb|zb))!==Lb)throw Error(`Cannot flush passive effects while already rendering.`);er(o),Yx=!0,Xx=!1;var s=0;if(D_=null,s=Dp(),Wx===Ox)pr(E_,s,rv);else{var c=E_,l=s,u=Wx===Dx;!L||l<=c||(Cx?Cx.run(console.timeStamp.bind(console,u?`Waiting for Paint`:`Waiting`,c,l,z,R,`secondary-light`)):console.timeStamp(u?`Waiting for Paint`:`Waiting`,c,l,z,R,`secondary-light`))}c=Y,Y|=zb;var d=r.current;yi(),el(d);var f=r.current;d=Bx,yi(),Kc(r,f,o,a,d),Yl(r),Y=c;var p=Dp();if(f=s,d=Cx,D_===null?!L||p<=f||(d?d.run(console.timeStamp.bind(console,`Remaining Effects`,f,p,z,R,`secondary-dark`)):console.timeStamp(`Remaining Effects`,f,p,z,R,`secondary-dark`)):fr(f,p,D_,!0,d),hl(o,p),tu(0,!1),Xx?r===$x?Qx++:(Qx=0,$x=r):Qx=0,Xx=Yx=!1,Lp&&typeof Lp.onPostCommitFiberRoot==`function`)try{Lp.onPostCommitFiberRoot(Ip,r)}catch(e){Rp||(Rp=!0,console.error(`React instrumentation encountered an error: %o`,e))}var m=r.current.stateNode;return m.effectDuration=0,m.passiveEffectDuration=0,!0}finally{I.p=i,F.T=n,Rl(e,t)}}function Vl(e,t,n){t=Fr(n,t),Ai(t),t=ps(e.stateNode,t,2),e=sa(e,t,2),e!==null&&(Ve(e,2),eu(e))}function j(e,t,n){if(eS=!1,e.tag===3)Vl(e,e,n);else{for(;t!==null;){if(t.tag===3){Vl(t,e,n);return}if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError==`function`||typeof r.componentDidCatch==`function`&&(wx===null||!wx.has(r))){e=Fr(n,e),Ai(e),n=ms(2),r=sa(t,n,2),r!==null&&(hs(n,r,t,e),Ve(r,2),eu(r));return}}t=t.return}console.error(`Internal React error: Attempted to capture a commit phase error inside a detached tree. This indicates a bug in React. Potential causes include deleting the same fiber more than once, committing an already-finished tree, or an inconsistent return pointer.

Error message:

%s`,n)}}function Hl(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new Ib;var i=new Set;r.set(t,i)}else i=r.get(t),i===void 0&&(i=new Set,r.set(t,i));i.has(n)||(ox=!0,i.add(n),r=Ul.bind(null,e,t,n),zp&&Zl(e,n),t.then(r,r))}function Ul(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,n&127?0>P_&&(N_=P_=b_(),F_=x_(`Promise Resolved`),I_=C_):n&4194048&&0>G_&&(U_=G_=b_(),q_=x_(`Promise Resolved`),K_=C_),al()&&F.actQueue===null&&console.error(`A suspended resource finished loading inside a test, but the event was not wrapped in act(...).

When testing, code that resolves suspended data should be wrapped into act(...):

act(() => {
  /* finish loading suspended data */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://react.dev/link/wrap-tests-with-act`),X===e&&(Q&n)===n&&(cx===Wb||cx===Ub&&(Q&62914560)===Q&&Dp()-_x<yx?(Y&Rb)===Lb&&gl(e,0):dx|=n,px===Q&&(px=0)),eu(e)}function Wl(e,t){t===0&&(t=ze()),e=_r(e,t),e!==null&&(Ve(e,t),eu(e))}function Gl(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Wl(e,n)}function Kl(e,t){var n=0;switch(e.tag){case 31:case 13:var r=e.stateNode,i=e.memoizedState;i!==null&&(n=i.retryLane);break;case 19:r=e.stateNode;break;case 22:r=e.stateNode._retryCache;break;default:throw Error(`Pinged unknown suspense boundary type. This is probably a bug in React.`)}r!==null&&r.delete(t),Wl(e,n)}function ql(e,t,n){if(t.subtreeFlags&67117056)for(t=t.child;t!==null;){var r=e,i=t,a=i.type===Bf;a=n||a,i.tag===22?i.memoizedState===null&&(a&&i.flags&8192?w(i,Jl,r,i):i.subtreeFlags&67108864&&w(i,ql,r,i,a)):i.flags&67108864?a&&w(i,Jl,r,i):ql(r,i,a),t=t.sibling}}function Jl(e,t){E(!0);try{zc(t),nl(t),Vc(e,t.alternate,t,!1),Jc(e,t,0,null,!1,0)}finally{E(!1)}}function Yl(e){var t=!0;e.current.mode&(Hg|Ug)||(t=!1),ql(e,e.current,t)}function Xl(e){if((Y&Rb)===Lb){var t=e.tag;if(t===3||t===1||t===0||t===11||t===14||t===15){if(t=S(e)||`ReactComponent`,tS!==null){if(tS.has(t))return;tS.add(t)}else tS=new Set([t]);w(e,function(){console.error(`Can't perform a React state update on a component that hasn't mounted yet. This indicates that you have a side-effect in your render function that asynchronously tries to update the component. Move this work to useEffect instead.`)})}}}function Zl(e,t){zp&&e.memoizedUpdaters.forEach(function(n){qe(e,n,t)})}function Ql(e,t){var n=F.actQueue;return n===null?Cp(e,t):(n.push(t),iS)}function $l(e){al()&&F.actQueue===null&&w(e,function(){console.error(`An update to %s inside a test was not wrapped in act(...).

When testing, code that causes React state updates should be wrapped into act(...):

act(() => {
  /* fire events that update state */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://react.dev/link/wrap-tests-with-act`,S(e))})}function eu(e){e!==oS&&e.next===null&&(oS===null?aS=oS=e:oS=oS.next=e),lS=!0,F.actQueue===null?sS||(sS=!0,cu()):cS||(cS=!0,cu())}function tu(e,t){if(!uS&&lS){uS=!0;do for(var n=!1,r=aS;r!==null;){if(!t)if(e!==0){var i=r.pendingLanes;if(i===0)var a=0;else{var o=r.suspendedLanes,s=r.pingedLanes;a=(1<<31-Bp(42|e)+1)-1,a&=i&~(o&~s),a=a&201326741?a&201326741|1:a?a|2:0}a!==0&&(n=!0,ou(r,a))}else a=Q,a=Ie(r,r===X?a:0,r.cancelPendingCommit!==null||r.timeoutHandle!==eC),!(a&3)||Le(r,a)||(n=!0,ou(r,a));r=r.next}while(n);uS=!1}}function nu(){ZS=window.event,ru()}function ru(){lS=cS=sS=!1;var e=0;dS!==0&&Yu()&&(e=dS);for(var t=Dp(),n=null,r=aS;r!==null;){var i=r.next,a=iu(r,t);a===0?(r.next=null,n===null?aS=i:n.next=i,i===null&&(oS=n)):(n=r,(e!==0||a&3)&&(lS=!0)),r=i}Fx!==kx&&Fx!==Px||tu(e,!1),dS!==0&&(dS=0)}function iu(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes&-62914561;0<a;){var o=31-Bp(a),s=1<<o,c=i[o];c===-1?((s&n)===0||(s&r)!==0)&&(i[o]=Re(s,t)):c<=t&&(e.expiredLanes|=s),a&=~s}if(t=X,n=Q,n=Ie(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==eC),r=e.callbackNode,n===0||e===t&&($===Yb||$===nx)||e.cancelPendingCommit!==null)return r!==null&&su(r),e.callbackNode=null,e.callbackPriority=0;if(!(n&3)||Le(e,n)){if(t=n&-n,t!==e.callbackPriority||F.actQueue!==null&&r!==fS)su(r);else return t;switch(Ye(n)){case Kp:case qp:n=Ap;break;case Jp:n=jp;break;case Yp:n=Np;break;default:n=jp}return r=au.bind(null,e),F.actQueue===null?n=Cp(n,r):(F.actQueue.push(r),n=fS),e.callbackPriority=t,e.callbackNode=n,t}return r!==null&&su(r),e.callbackPriority=2,e.callbackNode=null,2}function au(e,t){if(sv=ov=!1,ZS=window.event,Fx!==kx&&Fx!==Px)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(Wx===Tx&&(Wx=Dx),zl()&&e.callbackNode!==n)return null;var r=Q;return r=Ie(e,e===X?r:0,e.cancelPendingCommit!==null||e.timeoutHandle!==eC),r===0?null:(ll(e,r,t),iu(e,Dp()),e.callbackNode!=null&&e.callbackNode===n?au.bind(null,e):null)}function ou(e,t){if(zl())return null;ov=sv,sv=!1,ll(e,t,!0)}function su(e){e!==fS&&e!==null&&wp(e)}function cu(){F.actQueue!==null&&F.actQueue.push(function(){return ru(),null}),nC(function(){(Y&(Rb|zb))===Lb?ru():Cp(kp,nu)})}function lu(){if(dS===0){var e=uv;e===0&&(e=Up,Up<<=1,!(Up&261888)&&(Up=256)),dS=e}return dS}function uu(e){return e==null||typeof e==`symbol`||typeof e==`boolean`?null:typeof e==`function`?e:(T(e,`action`),un(``+e))}function du(e,t){var n=t.ownerDocument.createElement(`input`);return n.name=t.name,n.value=t.value,e.id&&n.setAttribute(`form`,e.id),t.parentNode.insertBefore(n,t),e=new FormData(e),n.parentNode.removeChild(n),e}function fu(e,t,n,r,i){if(t===`submit`&&n&&n.stateNode===i){var a=uu((i[Qp]||null).action),o=r.submitter;o&&(t=(t=o[Qp]||null)?uu(t.formAction):o.getAttribute(`formAction`),t!==null&&(a=t,o=null));var s=new fh(`action`,`action`,null,r,i);e.push({event:s,listeners:[{instance:null,listener:function(){if(r.defaultPrevented){if(dS!==0){var e=o?du(i,o):new FormData(i),t={pending:!0,data:e,method:i.method,action:a};Object.freeze(t),Bo(n,t,null,e)}}else typeof a==`function`&&(s.preventDefault(),e=o?du(i,o):new FormData(i),t={pending:!0,data:e,method:i.method,action:a},Object.freeze(t),Bo(n,t,a,e))},currentTarget:i}]})}}function pu(e,t,n){e.currentTarget=n;try{t(e)}catch(e){_g(e)}e.currentTarget=null}function mu(e,t){t=(t&4)!=0;for(var n=0;n<e.length;n++){var r=e[n];a:{var i=void 0,a=r.event;if(r=r.listeners,t)for(var o=r.length-1;0<=o;o--){var s=r[o],c=s.instance,l=s.currentTarget;if(s=s.listener,c!==i&&a.isPropagationStopped())break a;c===null?pu(a,s,l):w(c,pu,a,s,l),i=c}else for(o=0;o<r.length;o++){if(s=r[o],c=s.instance,l=s.currentTarget,s=s.listener,c!==i&&a.isPropagationStopped())break a;c===null?pu(a,s,l):w(c,pu,a,s,l),i=c}}}}function M(e,t){mS.has(e)||console.error(`Did not expect a listenToNonDelegatedEvent() call for "%s". This is a bug in React. Please file an issue.`,e);var n=t[em];n===void 0&&(n=t[em]=new Set);var r=e+`__bubble`;n.has(r)||(_u(t,e,2,!1),n.add(r))}function hu(e,t,n){mS.has(e)&&!t&&console.error(`Did not expect a listenToNativeEvent() call for "%s" in the bubble phase. This is a bug in React. Please file an issue.`,e);var r=0;t&&(r|=4),_u(n,e,r,t)}function gu(e){if(!e[hS]){e[hS]=!0,am.forEach(function(t){t!==`selectionchange`&&(mS.has(t)||hu(t,!1,e),hu(t,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[hS]||(t[hS]=!0,hu(`selectionchange`,!1,t))}}function _u(e,t,n,r){switch(vf(t)){case Kp:var i=pf;break;case qp:i=mf;break;default:i=hf}n=i.bind(null,t,n,e),i=void 0,!oh||t!==`touchstart`&&t!==`touchmove`&&t!==`wheel`||(i=!0),r?i===void 0?e.addEventListener(t,n,!0):e.addEventListener(t,n,{capture:!0,passive:i}):i===void 0?e.addEventListener(t,n,!1):e.addEventListener(t,n,{passive:i})}function vu(e,t,n,r,i){var a=r;if(!(t&1)&&!(t&2)&&r!==null)a:for(;;){if(r===null)return;var o=r.tag;if(o===3||o===4){var s=r.stateNode.containerInfo;if(s===i)break;if(o===4)for(o=r.return;o!==null;){var c=o.tag;if((c===3||c===4)&&o.stateNode.containerInfo===i)return;o=o.return}for(;s!==null;){if(o=$e(s),o===null)return;if(c=o.tag,c===5||c===6||c===26||c===27){r=a=o;continue a}s=s.parentNode}}r=r.return}mn(function(){var r=a,i=fn(n),o=[];a:{var s=dg.get(e);if(s!==void 0){var c=fh,l=e;switch(e){case`keypress`:if(_n(n)===0)break a;case`keydown`:case`keyup`:c=kh;break;case`focusin`:l=`focus`,c=xh;break;case`focusout`:l=`blur`,c=xh;break;case`beforeblur`:case`afterblur`:c=xh;break;case`click`:if(n.button===2)break a;case`auxclick`:case`dblclick`:case`mousedown`:case`mousemove`:case`mouseup`:case`mouseout`:case`mouseover`:case`contextmenu`:c=yh;break;case`drag`:case`dragend`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`dragstart`:case`drop`:c=bh;break;case`touchcancel`:case`touchend`:case`touchmove`:case`touchstart`:c=jh;break;case ig:case ag:case og:c=Sh;break;case ug:c=Mh;break;case`scroll`:case`scrollend`:c=mh;break;case`wheel`:c=Nh;break;case`copy`:case`cut`:case`paste`:c=Ch;break;case`gotpointercapture`:case`lostpointercapture`:case`pointercancel`:case`pointerdown`:case`pointermove`:case`pointerout`:case`pointerover`:case`pointerup`:c=Ah;break;case`toggle`:case`beforetoggle`:c=Ph}var u=(t&4)!=0,d=!u&&(e===`scroll`||e===`scrollend`),f=u?s===null?null:s+`Capture`:s;u=[];for(var p=r,m;p!==null;){var h=p;if(m=h.stateNode,h=h.tag,h!==5&&h!==26&&h!==27||m===null||f===null||(h=hn(p,f),h!=null&&u.push(yu(p,h,m))),d)break;p=p.return}0<u.length&&(s=new c(s,l,null,n,i),o.push({event:s,listeners:u}))}}if(!(t&7)){a:{if(s=e===`mouseover`||e===`pointerover`,c=e===`mouseout`||e===`pointerout`,s&&n!==th&&(l=n.relatedTarget||n.fromElement)&&($e(l)||l[$p]))break a;if((c||s)&&(s=i.window===i?i:(s=i.ownerDocument)?s.defaultView||s.parentWindow:window,c?(l=n.relatedTarget||n.toElement,c=r,l=l?$e(l):null,l!==null&&(d=ee(l),u=l.tag,l!==d||u!==5&&u!==27&&u!==6)&&(l=null)):(c=null,l=r),c!==l)){if(u=yh,h=`onMouseLeave`,f=`onMouseEnter`,p=`mouse`,(e===`pointerout`||e===`pointerover`)&&(u=Ah,h=`onPointerLeave`,f=`onPointerEnter`,p=`pointer`),d=c==null?s:tt(c),m=l==null?s:tt(l),s=new u(h,p+`leave`,c,n,i),s.target=d,s.relatedTarget=m,h=null,$e(i)===r&&(u=new u(f,p+`enter`,l,n,i),u.target=m,u.relatedTarget=d,h=u),d=h,c&&l)b:{for(u=xu,f=c,p=l,m=0,h=f;h;h=u(h))m++;h=0;for(var g=p;g;g=u(g))h++;for(;0<m-h;)f=u(f),m--;for(;0<h-m;)p=u(p),h--;for(;m--;){if(f===p||p!==null&&f===p.alternate){u=f;break b}f=u(f),p=u(p)}u=null}else u=null;c!==null&&Su(o,s,c,u,!1),l!==null&&d!==null&&Su(o,d,l,u,!0)}}a:{if(s=r?tt(r):window,c=s.nodeName&&s.nodeName.toLowerCase(),c===`select`||c===`input`&&s.type===`file`)var _=Mn;else if(Dn(s))if(Jh)_=Rn;else{_=In;var v=Fn}else c=s.nodeName,!c||c.toLowerCase()!==`input`||s.type!==`checkbox`&&s.type!==`radio`?r&&rn(r.elementType)&&(_=Mn):_=Ln;if(_&&=_(e,r)){kn(o,_,n,i);break a}v&&v(e,s,r),e===`focusout`&&r&&s.type===`number`&&r.memoizedProps.value!=null&&St(s,`number`,s.value)}switch(v=r?tt(r):window,e){case`focusin`:(Dn(v)||v.contentEditable===`true`)&&(Zh=v,Qh=r,$h=null);break;case`focusout`:$h=Qh=Zh=null;break;case`mousedown`:eg=!0;break;case`contextmenu`:case`mouseup`:case`dragend`:eg=!1,Kn(o,n,i);break;case`selectionchange`:if(Xh)break;case`keydown`:case`keyup`:Kn(o,n,i)}var y;if(Lh)b:{switch(e){case`compositionstart`:var b=`onCompositionStart`;break b;case`compositionend`:b=`onCompositionEnd`;break b;case`compositionupdate`:b=`onCompositionUpdate`;break b}b=void 0}else Wh?Cn(e,n)&&(b=`onCompositionEnd`):e===`keydown`&&n.keyCode===Ih&&(b=`onCompositionStart`);b&&(Bh&&n.locale!==`ko`&&(Wh||b!==`onCompositionStart`?b===`onCompositionEnd`&&Wh&&(y=gn()):(ch=i,lh=`value`in ch?ch.value:ch.textContent,Wh=!0)),v=bu(r,b),0<v.length&&(b=new wh(b,e,null,n,i),o.push({event:b,listeners:v}),y?b.data=y:(y=wn(n),y!==null&&(b.data=y)))),(y=zh?Tn(e,n):En(e,n))&&(b=bu(r,`onBeforeInput`),0<b.length&&(v=new Th(`onBeforeInput`,`beforeinput`,null,n,i),o.push({event:v,listeners:b}),v.data=y)),fu(o,e,r,n,i)}mu(o,t)})}function yu(e,t,n){return{instance:e,listener:t,currentTarget:n}}function bu(e,t){for(var n=t+`Capture`,r=[];e!==null;){var i=e,a=i.stateNode;if(i=i.tag,i!==5&&i!==26&&i!==27||a===null||(i=hn(e,n),i!=null&&r.unshift(yu(e,i,a)),i=hn(e,t),i!=null&&r.push(yu(e,i,a))),e.tag===3)return r;e=e.return}return[]}function xu(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Su(e,t,n,r,i){for(var a=t._reactName,o=[];n!==null&&n!==r;){var s=n,c=s.alternate,l=s.stateNode;if(s=s.tag,c!==null&&c===r)break;s!==5&&s!==26&&s!==27||l===null||(c=l,i?(l=hn(n,a),l!=null&&o.unshift(yu(n,l,c))):i||(l=hn(n,a),l!=null&&o.push(yu(n,l,c)))),n=n.return}o.length!==0&&e.push({event:t,listeners:o})}function Cu(e,t){sn(e,t),e!==`input`&&e!==`textarea`&&e!==`select`||t==null||t.value!==null||Jm||(Jm=!0,e===`select`&&t.multiple?console.error("`value` prop on `%s` should not be null. Consider using an empty array when `multiple` is set to `true` to clear the component or `undefined` for uncontrolled components.",e):console.error("`value` prop on `%s` should not be null. Consider using an empty string to clear the component or `undefined` for uncontrolled components.",e));var n={registrationNameDependencies:om,possibleRegistrationNames:sm};rn(e)||typeof t.is==`string`||ln(e,t,n),t.contentEditable&&!t.suppressContentEditableWarning&&t.children!=null&&console.error("A component is `contentEditable` and contains `children` managed by React. It is now your responsibility to guarantee that none of those nodes are unexpectedly modified or duplicated. This is probably not intentional.")}function wu(e,t,n,r){t!==n&&(n=Ou(n),Ou(t)!==n&&(r[e]=t))}function Tu(e,t,n){t.forEach(function(t){n[Nu(t)]=t===`style`?Pu(e):e.getAttribute(t)})}function Eu(e,t){!1===t?console.error("Expected `%s` listener to be a function, instead got `false`.\n\nIf you used to conditionally omit it with %s={condition && value}, pass %s={condition ? value : undefined} instead.",e,e,e):console.error("Expected `%s` listener to be a function, instead got a value of `%s` type.",e,typeof t)}function Du(e,t){return e=e.namespaceURI===Bm||e.namespaceURI===Vm?e.ownerDocument.createElementNS(e.namespaceURI,e.tagName):e.ownerDocument.createElement(e.tagName),e.innerHTML=t,e.innerHTML}function Ou(e){return ke(e)&&(console.error(`The provided HTML markup uses a value of unsupported type %s. This value must be coerced to a string before using it here.`,Oe(e)),Ae(e)),(typeof e==`string`?e:``+e).replace(wS,`
`).replace(TS,``)}function ku(e,t){return t=Ou(t),Ou(e)===t}function N(e,t,n,r,i,a){switch(n){case`children`:typeof r==`string`?(Qt(r,t,!1),t===`body`||t===`textarea`&&r===``||$t(e,r)):(typeof r==`number`||typeof r==`bigint`)&&(Qt(``+r,t,!1),t!==`body`&&$t(e,``+r));break;case`className`:ut(e,`class`,r);break;case`tabIndex`:ut(e,`tabindex`,r);break;case`dir`:case`role`:case`viewBox`:case`width`:case`height`:ut(e,n,r);break;case`style`:nn(e,r,a);break;case`data`:if(t!==`object`){ut(e,`data`,r);break}case`src`:case`href`:if(r===``&&(t!==`a`||n!==`href`)){console.error(n===`src`?`An empty string ("") was passed to the %s attribute. This may cause the browser to download the whole page again over the network. To fix this, either do not render the element at all or pass null to %s instead of an empty string.`:`An empty string ("") was passed to the %s attribute. To fix this, either do not render the element at all or pass null to %s instead of an empty string.`,n,n),e.removeAttribute(n);break}if(r==null||typeof r==`function`||typeof r==`symbol`||typeof r==`boolean`){e.removeAttribute(n);break}T(r,n),r=un(``+r),e.setAttribute(n,r);break;case`action`:case`formAction`:if(r!=null&&(t===`form`?n===`formAction`?console.error(`You can only pass the formAction prop to <input> or <button>. Use the action prop on <form>.`):typeof r==`function`&&(i.encType==null&&i.method==null||xS||(xS=!0,console.error(`Cannot specify a encType or method for a form that specifies a function as the action. React provides those automatically. They will get overridden.`)),i.target==null||bS||(bS=!0,console.error(`Cannot specify a target for a form that specifies a function as the action. The function will always be executed in the same window.`))):t===`input`||t===`button`?n===`action`?console.error(`You can only pass the action prop to <form>. Use the formAction prop on <input> or <button>.`):t!==`input`||i.type===`submit`||i.type===`image`||vS?t!==`button`||i.type==null||i.type===`submit`||vS?typeof r==`function`&&(i.name==null||yS||(yS=!0,console.error(`Cannot specify a "name" prop for a button that specifies a function as a formAction. React needs it to encode which action should be invoked. It will get overridden.`)),i.formEncType==null&&i.formMethod==null||xS||(xS=!0,console.error(`Cannot specify a formEncType or formMethod for a button that specifies a function as a formAction. React provides those automatically. They will get overridden.`)),i.formTarget==null||bS||(bS=!0,console.error(`Cannot specify a formTarget for a button that specifies a function as a formAction. The function will always be executed in the same window.`))):(vS=!0,console.error(`A button can only specify a formAction along with type="submit" or no type.`)):(vS=!0,console.error(`An input can only specify a formAction along with type="submit" or type="image".`)):console.error(n===`action`?`You can only pass the action prop to <form>.`:`You can only pass the formAction prop to <input> or <button>.`)),typeof r==`function`){e.setAttribute(n,`javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`);break}else typeof a==`function`&&(n===`formAction`?(t!==`input`&&N(e,t,`name`,i.name,i,null),N(e,t,`formEncType`,i.formEncType,i,null),N(e,t,`formMethod`,i.formMethod,i,null),N(e,t,`formTarget`,i.formTarget,i,null)):(N(e,t,`encType`,i.encType,i,null),N(e,t,`method`,i.method,i,null),N(e,t,`target`,i.target,i,null)));if(r==null||typeof r==`symbol`||typeof r==`boolean`){e.removeAttribute(n);break}T(r,n),r=un(``+r),e.setAttribute(n,r);break;case`onClick`:r!=null&&(typeof r!=`function`&&Eu(n,r),e.onclick=dn);break;case`onScroll`:r!=null&&(typeof r!=`function`&&Eu(n,r),M(`scroll`,e));break;case`onScrollEnd`:r!=null&&(typeof r!=`function`&&Eu(n,r),M(`scrollend`,e));break;case`dangerouslySetInnerHTML`:if(r!=null){if(typeof r!=`object`||!(`__html`in r))throw Error("`props.dangerouslySetInnerHTML` must be in the form `{__html: ...}`. Please visit https://react.dev/link/dangerously-set-inner-html for more information.");if(n=r.__html,n!=null){if(i.children!=null)throw Error("Can only set one of `children` or `props.dangerouslySetInnerHTML`.");e.innerHTML=n}}break;case`multiple`:e.multiple=r&&typeof r!=`function`&&typeof r!=`symbol`;break;case`muted`:e.muted=r&&typeof r!=`function`&&typeof r!=`symbol`;break;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`defaultValue`:case`defaultChecked`:case`innerHTML`:case`ref`:break;case`autoFocus`:break;case`xlinkHref`:if(r==null||typeof r==`function`||typeof r==`boolean`||typeof r==`symbol`){e.removeAttribute(`xlink:href`);break}T(r,n),n=un(``+r),e.setAttributeNS(ES,`xlink:href`,n);break;case`contentEditable`:case`spellCheck`:case`draggable`:case`value`:case`autoReverse`:case`externalResourcesRequired`:case`focusable`:case`preserveAlpha`:r!=null&&typeof r!=`function`&&typeof r!=`symbol`?(T(r,n),e.setAttribute(n,``+r)):e.removeAttribute(n);break;case`inert`:r!==``||CS[n]||(CS[n]=!0,console.error("Received an empty string for a boolean attribute `%s`. This will treat the attribute as if it were false. Either pass `false` to silence this warning, or pass `true` if you used an empty string in earlier versions of React to indicate this attribute is true.",n));case`allowFullScreen`:case`async`:case`autoPlay`:case`controls`:case`default`:case`defer`:case`disabled`:case`disablePictureInPicture`:case`disableRemotePlayback`:case`formNoValidate`:case`hidden`:case`loop`:case`noModule`:case`noValidate`:case`open`:case`playsInline`:case`readOnly`:case`required`:case`reversed`:case`scoped`:case`seamless`:case`itemScope`:r&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,``):e.removeAttribute(n);break;case`capture`:case`download`:!0===r?e.setAttribute(n,``):!1!==r&&r!=null&&typeof r!=`function`&&typeof r!=`symbol`?(T(r,n),e.setAttribute(n,r)):e.removeAttribute(n);break;case`cols`:case`rows`:case`size`:case`span`:r!=null&&typeof r!=`function`&&typeof r!=`symbol`&&!isNaN(r)&&1<=r?(T(r,n),e.setAttribute(n,r)):e.removeAttribute(n);break;case`rowSpan`:case`start`:r==null||typeof r==`function`||typeof r==`symbol`||isNaN(r)?e.removeAttribute(n):(T(r,n),e.setAttribute(n,r));break;case`popover`:M(`beforetoggle`,e),M(`toggle`,e),lt(e,`popover`,r);break;case`xlinkActuate`:dt(e,ES,`xlink:actuate`,r);break;case`xlinkArcrole`:dt(e,ES,`xlink:arcrole`,r);break;case`xlinkRole`:dt(e,ES,`xlink:role`,r);break;case`xlinkShow`:dt(e,ES,`xlink:show`,r);break;case`xlinkTitle`:dt(e,ES,`xlink:title`,r);break;case`xlinkType`:dt(e,ES,`xlink:type`,r);break;case`xmlBase`:dt(e,DS,`xml:base`,r);break;case`xmlLang`:dt(e,DS,`xml:lang`,r);break;case`xmlSpace`:dt(e,DS,`xml:space`,r);break;case`is`:a!=null&&console.error(`Cannot update the "is" prop after it has been initialized.`),lt(e,`is`,r);break;case`innerText`:case`textContent`:break;case`popoverTarget`:SS||typeof r!=`object`||!r||(SS=!0,console.error("The `popoverTarget` prop expects the ID of an Element as a string. Received %s instead.",r));default:!(2<n.length)||n[0]!==`o`&&n[0]!==`O`||n[1]!==`n`&&n[1]!==`N`?(n=an(n),lt(e,n,r)):om.hasOwnProperty(n)&&r!=null&&typeof r!=`function`&&Eu(n,r)}}function Au(e,t,n,r,i,a){switch(n){case`style`:nn(e,r,a);break;case`dangerouslySetInnerHTML`:if(r!=null){if(typeof r!=`object`||!(`__html`in r))throw Error("`props.dangerouslySetInnerHTML` must be in the form `{__html: ...}`. Please visit https://react.dev/link/dangerously-set-inner-html for more information.");if(n=r.__html,n!=null){if(i.children!=null)throw Error("Can only set one of `children` or `props.dangerouslySetInnerHTML`.");e.innerHTML=n}}break;case`children`:typeof r==`string`?$t(e,r):(typeof r==`number`||typeof r==`bigint`)&&$t(e,``+r);break;case`onScroll`:r!=null&&(typeof r!=`function`&&Eu(n,r),M(`scroll`,e));break;case`onScrollEnd`:r!=null&&(typeof r!=`function`&&Eu(n,r),M(`scrollend`,e));break;case`onClick`:r!=null&&(typeof r!=`function`&&Eu(n,r),e.onclick=dn);break;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`innerHTML`:case`ref`:break;case`innerText`:case`textContent`:break;default:if(om.hasOwnProperty(n))r!=null&&typeof r!=`function`&&Eu(n,r);else a:{if(n[0]===`o`&&n[1]===`n`&&(i=n.endsWith(`Capture`),t=n.slice(2,i?n.length-7:void 0),a=e[Qp]||null,a=a==null?null:a[n],typeof a==`function`&&e.removeEventListener(t,a,i),typeof r==`function`)){typeof a!=`function`&&a!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(t,r,i);break a}n in e?e[n]=r:!0===r?e.setAttribute(n,``):lt(e,n,r)}}}function ju(e,t,n){switch(Cu(t,n),t){case`div`:case`span`:case`svg`:case`path`:case`a`:case`g`:case`p`:case`li`:break;case`img`:M(`error`,e),M(`load`,e);var r=!1,i=!1,a;for(a in n)if(n.hasOwnProperty(a)){var o=n[a];if(o!=null)switch(a){case`src`:r=!0;break;case`srcSet`:i=!0;break;case`children`:case`dangerouslySetInnerHTML`:throw Error(t+" is a void element tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");default:N(e,t,a,o,n,null)}}i&&N(e,t,`srcSet`,n.srcSet,n,null),r&&N(e,t,`src`,n.src,n,null);return;case`input`:ot(`input`,n),M(`invalid`,e);var s=a=o=i=null,c=null,l=null;for(r in n)if(n.hasOwnProperty(r)){var u=n[r];if(u!=null)switch(r){case`name`:i=u;break;case`type`:o=u;break;case`checked`:c=u;break;case`defaultChecked`:l=u;break;case`value`:a=u;break;case`defaultValue`:s=u;break;case`children`:case`dangerouslySetInnerHTML`:if(u!=null)throw Error(t+" is a void element tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");break;default:N(e,t,r,u,n,null)}}yt(e,n),xt(e,a,s,c,l,o,i,!1);return;case`select`:for(i in ot(`select`,n),M(`invalid`,e),r=o=a=null,n)if(n.hasOwnProperty(i)&&(s=n[i],s!=null))switch(i){case`value`:a=s;break;case`defaultValue`:o=s;break;case`multiple`:r=s;default:N(e,t,i,s,n,null)}Et(e,n),t=a,n=o,e.multiple=!!r,t==null?n!=null&&Tt(e,!!r,n,!0):Tt(e,!!r,t,!1);return;case`textarea`:for(o in ot(`textarea`,n),M(`invalid`,e),a=i=r=null,n)if(n.hasOwnProperty(o)&&(s=n[o],s!=null))switch(o){case`value`:r=s;break;case`defaultValue`:i=s;break;case`children`:a=s;break;case`dangerouslySetInnerHTML`:if(s!=null)throw Error("`dangerouslySetInnerHTML` does not make sense on <textarea>.");break;default:N(e,t,o,s,n,null)}Dt(e,n),kt(e,r,i,a);return;case`option`:for(c in Ct(e,n),n)if(n.hasOwnProperty(c)&&(r=n[c],r!=null))switch(c){case`selected`:e.selected=r&&typeof r!=`function`&&typeof r!=`symbol`;break;default:N(e,t,c,r,n,null)}return;case`dialog`:M(`beforetoggle`,e),M(`toggle`,e),M(`cancel`,e),M(`close`,e);break;case`iframe`:case`object`:M(`load`,e);break;case`video`:case`audio`:for(r=0;r<pS.length;r++)M(pS[r],e);break;case`image`:M(`error`,e),M(`load`,e);break;case`details`:M(`toggle`,e);break;case`embed`:case`source`:case`link`:M(`error`,e),M(`load`,e);case`area`:case`base`:case`br`:case`col`:case`hr`:case`keygen`:case`meta`:case`param`:case`track`:case`wbr`:case`menuitem`:for(l in n)if(n.hasOwnProperty(l)&&(r=n[l],r!=null))switch(l){case`children`:case`dangerouslySetInnerHTML`:throw Error(t+" is a void element tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");default:N(e,t,l,r,n,null)}return;default:if(rn(t)){for(u in n)n.hasOwnProperty(u)&&(r=n[u],r!==void 0&&Au(e,t,u,r,n,void 0));return}}for(s in n)n.hasOwnProperty(s)&&(r=n[s],r!=null&&N(e,t,s,r,n,null))}function Mu(e,t,n,r){switch(Cu(t,r),t){case`div`:case`span`:case`svg`:case`path`:case`a`:case`g`:case`p`:case`li`:break;case`input`:var i=null,a=null,o=null,s=null,c=null,l=null,u=null;for(p in n){var d=n[p];if(n.hasOwnProperty(p)&&d!=null)switch(p){case`checked`:break;case`value`:break;case`defaultValue`:c=d;default:r.hasOwnProperty(p)||N(e,t,p,null,r,d)}}for(var f in r){var p=r[f];if(d=n[f],r.hasOwnProperty(f)&&(p!=null||d!=null))switch(f){case`type`:a=p;break;case`name`:i=p;break;case`checked`:l=p;break;case`defaultChecked`:u=p;break;case`value`:o=p;break;case`defaultValue`:s=p;break;case`children`:case`dangerouslySetInnerHTML`:if(p!=null)throw Error(t+" is a void element tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");break;default:p!==d&&N(e,t,f,p,r,d)}}t=n.type===`checkbox`||n.type===`radio`?n.checked!=null:n.value!=null,r=r.type===`checkbox`||r.type===`radio`?r.checked!=null:r.value!=null,t||!r||_S||(console.error(`A component is changing an uncontrolled input to be controlled. This is likely caused by the value changing from undefined to a defined value, which should not happen. Decide between using a controlled or uncontrolled input element for the lifetime of the component. More info: https://react.dev/link/controlled-components`),_S=!0),!t||r||gS||(console.error(`A component is changing a controlled input to be uncontrolled. This is likely caused by the value changing from a defined to undefined, which should not happen. Decide between using a controlled or uncontrolled input element for the lifetime of the component. More info: https://react.dev/link/controlled-components`),gS=!0),bt(e,o,s,c,l,u,a,i);return;case`select`:for(a in p=o=s=f=null,n)if(c=n[a],n.hasOwnProperty(a)&&c!=null)switch(a){case`value`:break;case`multiple`:p=c;default:r.hasOwnProperty(a)||N(e,t,a,null,r,c)}for(i in r)if(a=r[i],c=n[i],r.hasOwnProperty(i)&&(a!=null||c!=null))switch(i){case`value`:f=a;break;case`defaultValue`:s=a;break;case`multiple`:o=a;default:a!==c&&N(e,t,i,a,r,c)}r=s,t=o,n=p,f==null?!!n!=!!t&&(r==null?Tt(e,!!t,t?[]:``,!1):Tt(e,!!t,r,!0)):Tt(e,!!t,f,!1);return;case`textarea`:for(s in p=f=null,n)if(i=n[s],n.hasOwnProperty(s)&&i!=null&&!r.hasOwnProperty(s))switch(s){case`value`:break;case`children`:break;default:N(e,t,s,null,r,i)}for(o in r)if(i=r[o],a=n[o],r.hasOwnProperty(o)&&(i!=null||a!=null))switch(o){case`value`:f=i;break;case`defaultValue`:p=i;break;case`children`:break;case`dangerouslySetInnerHTML`:if(i!=null)throw Error("`dangerouslySetInnerHTML` does not make sense on <textarea>.");break;default:i!==a&&N(e,t,o,i,r,a)}Ot(e,f,p);return;case`option`:for(var m in n)if(f=n[m],n.hasOwnProperty(m)&&f!=null&&!r.hasOwnProperty(m))switch(m){case`selected`:e.selected=!1;break;default:N(e,t,m,null,r,f)}for(c in r)if(f=r[c],p=n[c],r.hasOwnProperty(c)&&f!==p&&(f!=null||p!=null))switch(c){case`selected`:e.selected=f&&typeof f!=`function`&&typeof f!=`symbol`;break;default:N(e,t,c,f,r,p)}return;case`img`:case`link`:case`area`:case`base`:case`br`:case`col`:case`embed`:case`hr`:case`keygen`:case`meta`:case`param`:case`source`:case`track`:case`wbr`:case`menuitem`:for(var h in n)f=n[h],n.hasOwnProperty(h)&&f!=null&&!r.hasOwnProperty(h)&&N(e,t,h,null,r,f);for(l in r)if(f=r[l],p=n[l],r.hasOwnProperty(l)&&f!==p&&(f!=null||p!=null))switch(l){case`children`:case`dangerouslySetInnerHTML`:if(f!=null)throw Error(t+" is a void element tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");break;default:N(e,t,l,f,r,p)}return;default:if(rn(t)){for(var g in n)f=n[g],n.hasOwnProperty(g)&&f!==void 0&&!r.hasOwnProperty(g)&&Au(e,t,g,void 0,r,f);for(u in r)f=r[u],p=n[u],!r.hasOwnProperty(u)||f===p||f===void 0&&p===void 0||Au(e,t,u,f,r,p);return}}for(var _ in n)f=n[_],n.hasOwnProperty(_)&&f!=null&&!r.hasOwnProperty(_)&&N(e,t,_,null,r,f);for(d in r)f=r[d],p=n[d],!r.hasOwnProperty(d)||f===p||f==null&&p==null||N(e,t,d,f,r,p)}function Nu(e){switch(e){case`class`:return`className`;case`for`:return`htmlFor`;default:return e}}function Pu(e){var t={};e=e.style;for(var n=0;n<e.length;n++){var r=e[n];t[r]=e.getPropertyValue(r)}return t}function Fu(e,t,n){if(t!=null&&typeof t!=`object`)console.error("The `style` prop expects a mapping from style properties to values, not a string. For example, style={{marginRight: spacing + 'em'}} when using JSX.");else{var r,i=r=``,a;for(a in t)if(t.hasOwnProperty(a)){var o=t[a];o!=null&&typeof o!=`boolean`&&o!==``&&(a.indexOf(`--`)===0?(je(o,a),r+=i+a+`:`+(``+o).trim()):typeof o!=`number`||o===0||zm.has(a)?(je(o,a),r+=i+a.replace(km,`-$1`).toLowerCase().replace(Am,`-ms-`)+`:`+(``+o).trim()):r+=i+a.replace(km,`-$1`).toLowerCase().replace(Am,`-ms-`)+`:`+o+`px`,i=`;`)}r||=null,t=e.getAttribute(`style`),t!==r&&(r=Ou(r),Ou(t)!==r&&(n.style=Pu(e)))}}function Iu(e,t,n,r,i,a){if(i.delete(n),e=e.getAttribute(n),e===null)switch(typeof r){case`undefined`:case`function`:case`symbol`:case`boolean`:return}else if(r!=null)switch(typeof r){case`function`:case`symbol`:case`boolean`:break;default:if(T(r,t),e===``+r)return}wu(t,e,r,a)}function Lu(e,t,n,r,i,a){if(i.delete(n),e=e.getAttribute(n),e===null){switch(typeof r){case`function`:case`symbol`:return}if(!r)return}else switch(typeof r){case`function`:case`symbol`:break;default:if(r)return}wu(t,e,r,a)}function Ru(e,t,n,r,i,a){if(i.delete(n),e=e.getAttribute(n),e===null)switch(typeof r){case`undefined`:case`function`:case`symbol`:return}else if(r!=null)switch(typeof r){case`function`:case`symbol`:break;default:if(T(r,n),e===``+r)return}wu(t,e,r,a)}function zu(e,t,n,r,i,a){if(i.delete(n),e=e.getAttribute(n),e===null)switch(typeof r){case`undefined`:case`function`:case`symbol`:case`boolean`:return;default:if(isNaN(r))return}else if(r!=null)switch(typeof r){case`function`:case`symbol`:case`boolean`:break;default:if(!isNaN(r)&&(T(r,t),e===``+r))return}wu(t,e,r,a)}function Bu(e,t,n,r,i,a){if(i.delete(n),e=e.getAttribute(n),e===null)switch(typeof r){case`undefined`:case`function`:case`symbol`:case`boolean`:return}else if(r!=null)switch(typeof r){case`function`:case`symbol`:case`boolean`:break;default:if(T(r,t),n=un(``+r),e===n)return}wu(t,e,r,a)}function Vu(e,t,n,r){for(var i={},a=new Set,o=e.attributes,s=0;s<o.length;s++)switch(o[s].name.toLowerCase()){case`value`:break;case`checked`:break;case`selected`:break;default:a.add(o[s].name)}if(rn(t)){for(var c in n)if(n.hasOwnProperty(c)){var l=n[c];if(l!=null){if(om.hasOwnProperty(c))typeof l!=`function`&&Eu(c,l);else if(!0!==n.suppressHydrationWarning)switch(c){case`children`:typeof l!=`string`&&typeof l!=`number`||wu(`children`,e.textContent,l,i);continue;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`defaultValue`:case`defaultChecked`:case`innerHTML`:case`ref`:continue;case`dangerouslySetInnerHTML`:o=e.innerHTML,l=l?l.__html:void 0,l!=null&&(l=Du(e,l),wu(c,o,l,i));continue;case`style`:a.delete(c),Fu(e,l,i);continue;case`offsetParent`:case`offsetTop`:case`offsetLeft`:case`offsetWidth`:case`offsetHeight`:case`isContentEditable`:case`outerText`:case`outerHTML`:a.delete(c.toLowerCase()),console.error("Assignment to read-only property will result in a no-op: `%s`",c);continue;case`className`:a.delete(`class`),o=ct(e,`class`,l),wu(`className`,o,l,i);continue;default:r.context===WS&&t!==`svg`&&t!==`math`?a.delete(c.toLowerCase()):a.delete(c),o=ct(e,c,l),wu(c,o,l,i)}}}}else for(l in n)if(n.hasOwnProperty(l)&&(c=n[l],c!=null)){if(om.hasOwnProperty(l))typeof c!=`function`&&Eu(l,c);else if(!0!==n.suppressHydrationWarning)switch(l){case`children`:typeof c!=`string`&&typeof c!=`number`||wu(`children`,e.textContent,c,i);continue;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`value`:case`checked`:case`selected`:case`defaultValue`:case`defaultChecked`:case`innerHTML`:case`ref`:continue;case`dangerouslySetInnerHTML`:o=e.innerHTML,c=c?c.__html:void 0,c!=null&&(c=Du(e,c),o!==c&&(i[l]={__html:o}));continue;case`className`:Iu(e,l,`class`,c,a,i);continue;case`tabIndex`:Iu(e,l,`tabindex`,c,a,i);continue;case`style`:a.delete(l),Fu(e,c,i);continue;case`multiple`:a.delete(l),wu(l,e.multiple,c,i);continue;case`muted`:a.delete(l),wu(l,e.muted,c,i);continue;case`autoFocus`:a.delete(`autofocus`),wu(l,e.autofocus,c,i);continue;case`data`:if(t!==`object`){a.delete(l),o=e.getAttribute(`data`),wu(l,o,c,i);continue}case`src`:case`href`:if(!(c!==``||t===`a`&&l===`href`||t===`object`&&l===`data`)){console.error(l===`src`?`An empty string ("") was passed to the %s attribute. This may cause the browser to download the whole page again over the network. To fix this, either do not render the element at all or pass null to %s instead of an empty string.`:`An empty string ("") was passed to the %s attribute. To fix this, either do not render the element at all or pass null to %s instead of an empty string.`,l,l);continue}Bu(e,l,l,c,a,i);continue;case`action`:case`formAction`:if(o=e.getAttribute(l),typeof c==`function`){a.delete(l.toLowerCase()),l===`formAction`?(a.delete(`name`),a.delete(`formenctype`),a.delete(`formmethod`),a.delete(`formtarget`)):(a.delete(`enctype`),a.delete(`method`),a.delete(`target`));continue}else if(o===OS){a.delete(l.toLowerCase()),wu(l,`function`,c,i);continue}Bu(e,l,l.toLowerCase(),c,a,i);continue;case`xlinkHref`:Bu(e,l,`xlink:href`,c,a,i);continue;case`contentEditable`:Ru(e,l,`contenteditable`,c,a,i);continue;case`spellCheck`:Ru(e,l,`spellcheck`,c,a,i);continue;case`draggable`:case`autoReverse`:case`externalResourcesRequired`:case`focusable`:case`preserveAlpha`:Ru(e,l,l,c,a,i);continue;case`allowFullScreen`:case`async`:case`autoPlay`:case`controls`:case`default`:case`defer`:case`disabled`:case`disablePictureInPicture`:case`disableRemotePlayback`:case`formNoValidate`:case`hidden`:case`loop`:case`noModule`:case`noValidate`:case`open`:case`playsInline`:case`readOnly`:case`required`:case`reversed`:case`scoped`:case`seamless`:case`itemScope`:Lu(e,l,l.toLowerCase(),c,a,i);continue;case`capture`:case`download`:a:{s=e;var u=o=l,d=i;if(a.delete(u),s=s.getAttribute(u),s===null)switch(typeof c){case`undefined`:case`function`:case`symbol`:break a;default:if(!1===c)break a}else if(c!=null)switch(typeof c){case`function`:case`symbol`:break;case`boolean`:if(!0===c&&s===``)break a;break;default:if(T(c,o),s===``+c)break a}wu(o,s,c,d)}continue;case`cols`:case`rows`:case`size`:case`span`:a:{if(s=e,u=o=l,d=i,a.delete(u),s=s.getAttribute(u),s===null)switch(typeof c){case`undefined`:case`function`:case`symbol`:case`boolean`:break a;default:if(isNaN(c)||1>c)break a}else if(c!=null)switch(typeof c){case`function`:case`symbol`:case`boolean`:break;default:if(!(isNaN(c)||1>c)&&(T(c,o),s===``+c))break a}wu(o,s,c,d)}continue;case`rowSpan`:zu(e,l,`rowspan`,c,a,i);continue;case`start`:zu(e,l,l,c,a,i);continue;case`xHeight`:Iu(e,l,`x-height`,c,a,i);continue;case`xlinkActuate`:Iu(e,l,`xlink:actuate`,c,a,i);continue;case`xlinkArcrole`:Iu(e,l,`xlink:arcrole`,c,a,i);continue;case`xlinkRole`:Iu(e,l,`xlink:role`,c,a,i);continue;case`xlinkShow`:Iu(e,l,`xlink:show`,c,a,i);continue;case`xlinkTitle`:Iu(e,l,`xlink:title`,c,a,i);continue;case`xlinkType`:Iu(e,l,`xlink:type`,c,a,i);continue;case`xmlBase`:Iu(e,l,`xml:base`,c,a,i);continue;case`xmlLang`:Iu(e,l,`xml:lang`,c,a,i);continue;case`xmlSpace`:Iu(e,l,`xml:space`,c,a,i);continue;case`inert`:c!==``||CS[l]||(CS[l]=!0,console.error("Received an empty string for a boolean attribute `%s`. This will treat the attribute as if it were false. Either pass `false` to silence this warning, or pass `true` if you used an empty string in earlier versions of React to indicate this attribute is true.",l)),Lu(e,l,l,c,a,i);continue;default:if(!(2<l.length)||l[0]!==`o`&&l[0]!==`O`||l[1]!==`n`&&l[1]!==`N`){s=an(l),o=!1,r.context===WS&&t!==`svg`&&t!==`math`?a.delete(s.toLowerCase()):(u=l.toLowerCase(),u=Um.hasOwnProperty(u)&&Um[u]||null,u!==null&&u!==l&&(o=!0,a.delete(u)),a.delete(s));a:if(u=e,d=s,s=c,st(d))if(u.hasAttribute(d))u=u.getAttribute(d),T(s,d),s=u===``+s?s:u;else{switch(typeof s){case`function`:case`symbol`:break a;case`boolean`:if(u=d.toLowerCase().slice(0,5),u!==`data-`&&u!==`aria-`)break a}s=s===void 0?void 0:null}else s=void 0;o||wu(l,s,c,i)}}}return 0<a.size&&!0!==n.suppressHydrationWarning&&Tu(e,a,i),Object.keys(i).length===0?null:i}function Hu(e,t){switch(e.length){case 0:return``;case 1:return e[0];case 2:return e[0]+` `+t+` `+e[1];default:return e.slice(0,-1).join(`, `)+`, `+t+` `+e[e.length-1]}}function Uu(e){switch(e){case`css`:case`script`:case`font`:case`img`:case`image`:case`input`:case`link`:return!0;default:return!1}}function Wu(){if(typeof performance.getEntriesByType==`function`){for(var e=0,t=0,n=performance.getEntriesByType(`resource`),r=0;r<n.length;r++){var i=n[r],a=i.transferSize,o=i.initiatorType,s=i.duration;if(a&&s&&Uu(o)){for(o=0,s=i.responseEnd,r+=1;r<n.length;r++){var c=n[r],l=c.startTime;if(l>s)break;var u=c.transferSize,d=c.initiatorType;u&&Uu(d)&&(c=c.responseEnd,o+=u*(c<s?1:(s-l)/(c-l)))}if(--r,t+=8*(a+o)/(i.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e==`number`)?e:5}function Gu(e){return e.nodeType===9?e:e.ownerDocument}function Ku(e){switch(e){case Vm:return GS;case Bm:return KS;default:return WS}}function qu(e,t){if(e===WS)switch(t){case`svg`:return GS;case`math`:return KS;default:return WS}return e===GS&&t===`foreignObject`?WS:e}function Ju(e,t){return e===`textarea`||e===`noscript`||typeof t.children==`string`||typeof t.children==`number`||typeof t.children==`bigint`||typeof t.dangerouslySetInnerHTML==`object`&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}function Yu(){var e=window.event;return e&&e.type===`popstate`?e===XS?!1:(XS=e,!0):(XS=null,!1)}function Xu(){var e=window.event;return e&&e!==ZS?e.type:null}function Zu(){var e=window.event;return e&&e!==ZS?e.timeStamp:-1.1}function Qu(e){setTimeout(function(){throw e})}function $u(e,t,n){switch(t){case`button`:case`input`:case`select`:case`textarea`:n.autoFocus&&e.focus();break;case`img`:n.src?e.src=n.src:n.srcSet&&(e.srcset=n.srcSet)}}function ed(){}function td(e,t,n,r){Mu(e,t,n,r),e[Qp]=r}function nd(e){$t(e,``)}function rd(e,t,n){e.nodeValue=n}function id(e){if(!e.__reactWarnedAboutChildrenConflict){var t=e[Qp]||null;if(t!==null){var n=et(e);n!==null&&(typeof t.children==`string`||typeof t.children==`number`?(e.__reactWarnedAboutChildrenConflict=!0,w(n,function(){console.error('Cannot use a ref on a React element as a container to `createRoot` or `createPortal` if that element also sets "children" text content using React. It should be a leaf with no children. Otherwise it\'s ambiguous which children should be used.')})):t.dangerouslySetInnerHTML!=null&&(e.__reactWarnedAboutChildrenConflict=!0,w(n,function(){console.error('Cannot use a ref on a React element as a container to `createRoot` or `createPortal` if that element also sets "dangerouslySetInnerHTML" using React. It should be a leaf with no children. Otherwise it\'s ambiguous which children should be used.')})))}}}function ad(e){return e===`head`}function od(e,t){e.removeChild(t)}function sd(e,t){(e.nodeType===9?e.body:e.nodeName===`HTML`?e.ownerDocument.body:e).removeChild(t)}function cd(e,t){var n=t,r=0;do{var i=n.nextSibling;if(e.removeChild(n),i&&i.nodeType===8)if(n=i.data,n===NS||n===jS){if(r===0){e.removeChild(i),Of(t);return}r--}else if(n===MS||n===PS||n===FS||n===IS||n===AS)r++;else if(n===LS)Nd(e.ownerDocument.documentElement);else if(n===zS){n=e.ownerDocument.head,Nd(n);for(var a=n.firstChild;a;){var o=a.nextSibling,s=a.nodeName;a[im]||s===`SCRIPT`||s===`STYLE`||s===`LINK`&&a.rel.toLowerCase()===`stylesheet`||n.removeChild(a),a=o}}else n===RS&&Nd(e.ownerDocument.body);n=i}while(n);Of(t)}function ld(e,t){var n=e;e=0;do{var r=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display=`none`):(n.style.display=n._stashedDisplay||``,n.getAttribute(`style`)===``&&n.removeAttribute(`style`)):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=``):n.nodeValue=n._stashedText||``),r&&r.nodeType===8)if(n=r.data,n===NS){if(e===0)break;e--}else n!==MS&&n!==PS&&n!==FS&&n!==IS||e++;n=r}while(n)}function ud(e){ld(e,!0)}function dd(e){e=e.style,typeof e.setProperty==`function`?e.setProperty(`display`,`none`,`important`):e.display=`none`}function fd(e){e.nodeValue=``}function pd(e){ld(e,!1)}function md(e,t){t=t[US],t=t!=null&&t.hasOwnProperty(`display`)?t.display:null,e.style.display=t==null||typeof t==`boolean`?``:(``+t).trim()}function hd(e,t){e.nodeValue=t}function gd(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case`HTML`:case`HEAD`:case`BODY`:gd(n),Qe(n);continue;case`SCRIPT`:case`STYLE`:continue;case`LINK`:if(n.rel.toLowerCase()===`stylesheet`)continue}e.removeChild(n)}}function _d(e,t,n,r){for(;e.nodeType===1;){var i=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!r&&(e.nodeName!==`INPUT`||e.type!==`hidden`))break}else if(!r)if(t===`input`&&e.type===`hidden`){T(i.name,`name`);var a=i.name==null?null:``+i.name;if(i.type===`hidden`&&e.getAttribute(`name`)===a)return e}else return e;else if(!e[im])switch(t){case`meta`:if(!e.hasAttribute(`itemprop`))break;return e;case`link`:if(a=e.getAttribute(`rel`),a===`stylesheet`&&e.hasAttribute(`data-precedence`)||a!==i.rel||e.getAttribute(`href`)!==(i.href==null||i.href===``?null:i.href)||e.getAttribute(`crossorigin`)!==(i.crossOrigin==null?null:i.crossOrigin)||e.getAttribute(`title`)!==(i.title==null?null:i.title))break;return e;case`style`:if(e.hasAttribute(`data-precedence`))break;return e;case`script`:if(a=e.getAttribute(`src`),(a!==(i.src==null?null:i.src)||e.getAttribute(`type`)!==(i.type==null?null:i.type)||e.getAttribute(`crossorigin`)!==(i.crossOrigin==null?null:i.crossOrigin))&&a&&e.hasAttribute(`async`)&&!e.hasAttribute(`itemprop`))break;return e;default:return e}if(e=Cd(e.nextSibling),e===null)break}return null}function vd(e,t,n){if(t===``)return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!==`INPUT`||e.type!==`hidden`)&&!n||(e=Cd(e.nextSibling),e===null))return null;return e}function yd(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!==`INPUT`||e.type!==`hidden`)&&!t||(e=Cd(e.nextSibling),e===null))return null;return e}function bd(e){return e.data===PS||e.data===FS}function xd(e){return e.data===IS||e.data===PS&&e.ownerDocument.readyState!==HS}function Sd(e,t){var n=e.ownerDocument;if(e.data===FS)e._reactRetry=t;else if(e.data!==PS||n.readyState!==HS)t();else{var r=function(){t(),n.removeEventListener(`DOMContentLoaded`,r)};n.addEventListener(`DOMContentLoaded`,r),e._reactRetry=r}}function Cd(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t===MS||t===IS||t===PS||t===FS||t===AS||t===BS||t===VS)break;if(t===NS||t===jS)return null}}return e}function wd(e){if(e.nodeType===1){for(var t=e.nodeName.toLowerCase(),n={},r=e.attributes,i=0;i<r.length;i++){var a=r[i];n[Nu(a.name)]=a.name.toLowerCase()===`style`?Pu(e):a.value}return{type:t,props:n}}return e.nodeType===8?e.data===AS?{type:`Activity`,props:{}}:{type:`Suspense`,props:{}}:e.nodeValue}function Td(e,t,n){return n===null||!0!==n[kS]?(e.nodeValue===t?e=null:(t=Ou(t),e=Ou(e.nodeValue)===t?null:e.nodeValue),e):null}function Ed(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===NS||n===jS){if(t===0)return Cd(e.nextSibling);t--}else n!==MS&&n!==IS&&n!==PS&&n!==FS&&n!==AS||t++}e=e.nextSibling}return null}function Dd(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===MS||n===IS||n===PS||n===FS||n===AS){if(t===0)return e;t--}else n!==NS&&n!==jS||t++}e=e.previousSibling}return null}function Od(e){Of(e)}function kd(e){Of(e)}function Ad(e){Of(e)}function jd(e,t,n,r,i){switch(i&&Zt(e,r.ancestorInfo),t=Gu(n),e){case`html`:if(e=t.documentElement,!e)throw Error(`React expected an <html> element (document.documentElement) to exist in the Document but one was not found. React never removes the documentElement for any Document it renders into so the cause is likely in some other script running on this page.`);return e;case`head`:if(e=t.head,!e)throw Error(`React expected a <head> element (document.head) to exist in the Document but one was not found. React never removes the head for any Document it renders into so the cause is likely in some other script running on this page.`);return e;case`body`:if(e=t.body,!e)throw Error(`React expected a <body> element (document.body) to exist in the Document but one was not found. React never removes the body for any Document it renders into so the cause is likely in some other script running on this page.`);return e;default:throw Error(`resolveSingletonInstance was called with an element type that is not supported. This is a bug in React.`)}}function Md(e,t,n,r){if(!n[$p]&&et(n)){var i=n.tagName.toLowerCase();console.error(`You are mounting a new %s component when a previous one has not first unmounted. It is an error to render more than one %s component at a time and attributes and children of these components will likely fail in unpredictable ways. Please only render a single instance of <%s> and if you need to mount a new one, ensure any previous ones have unmounted first.`,i,i,i)}switch(e){case`html`:case`head`:case`body`:break;default:console.error(`acquireSingletonInstance was called with an element type that is not supported. This is a bug in React.`)}for(i=n.attributes;i.length;)n.removeAttributeNode(i[0]);ju(n,e,t),n[Zp]=r,n[Qp]=t}function Nd(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);Qe(e)}function Pd(e){return typeof e.getRootNode==`function`?e.getRootNode():e.nodeType===9?e:e.ownerDocument}function Fd(e,t,n){var r=fC;if(r&&typeof t==`string`&&t){var i=vt(t);i=`link[rel="`+e+`"][href="`+i+`"]`,typeof n==`string`&&(i+=`[crossorigin="`+n+`"]`),uC.has(i)||(uC.add(i),e={rel:e,crossOrigin:n,href:t},r.querySelector(i)===null&&(t=r.createElement(`link`),ju(t,`link`,e),rt(t),r.head.appendChild(t)))}}function Id(e,t,n,r){var i=(i=op.current)?Pd(i):null;if(!i)throw Error(`"resourceRoot" was expected to exist. This is a bug in React.`);switch(e){case`meta`:case`title`:return null;case`style`:return typeof n.precedence==`string`&&typeof n.href==`string`?(n=Rd(n.href),t=nt(i).hoistableStyles,r=t.get(n),r||(r={type:`style`,instance:null,count:0,state:null},t.set(n,r)),r):{type:`void`,instance:null,count:0,state:null};case`link`:if(n.rel===`stylesheet`&&typeof n.href==`string`&&typeof n.precedence==`string`){e=Rd(n.href);var a=nt(i).hoistableStyles,o=a.get(e);if(!o&&(i=i.ownerDocument||i,o={type:`stylesheet`,instance:null,count:0,state:{loading:iC,preload:null}},a.set(e,o),(a=i.querySelector(zd(e)))&&!a._p&&(o.instance=a,o.state.loading=aC|cC),!lC.has(e))){var s={rel:`preload`,as:`style`,href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy};lC.set(e,s),a||Vd(i,e,s,o.state)}if(t&&r===null)throw n=`

  - `+Ld(t)+`
  + `+Ld(n),Error("Expected <link> not to update to be updated to a stylesheet with precedence. Check the `rel`, `href`, and `precedence` props of this component. Alternatively, check whether two different <link> components render in the same slot or share the same key."+n);return o}if(t&&r!==null)throw n=`

  - `+Ld(t)+`
  + `+Ld(n),Error("Expected stylesheet with precedence to not be updated to a different kind of <link>. Check the `rel`, `href`, and `precedence` props of this component. Alternatively, check whether two different <link> components render in the same slot or share the same key."+n);return null;case`script`:return t=n.async,n=n.src,typeof n==`string`&&t&&typeof t!=`function`&&typeof t!=`symbol`?(n=Hd(n),t=nt(i).hoistableScripts,r=t.get(n),r||(r={type:`script`,instance:null,count:0,state:null},t.set(n,r)),r):{type:`void`,instance:null,count:0,state:null};default:throw Error(`getResource encountered a type it did not expect: "`+e+`". this is a bug in React.`)}}function Ld(e){var t=0,n=`<link`;return typeof e.rel==`string`?(t++,n+=` rel="`+e.rel+`"`):Sp.call(e,`rel`)&&(t++,n+=` rel="`+(e.rel===null?`null`:`invalid type `+typeof e.rel)+`"`),typeof e.href==`string`?(t++,n+=` href="`+e.href+`"`):Sp.call(e,`href`)&&(t++,n+=` href="`+(e.href===null?`null`:`invalid type `+typeof e.href)+`"`),typeof e.precedence==`string`?(t++,n+=` precedence="`+e.precedence+`"`):Sp.call(e,`precedence`)&&(t++,n+=` precedence={`+(e.precedence===null?`null`:`invalid type `+typeof e.precedence)+`}`),Object.getOwnPropertyNames(e).length>t&&(n+=` ...`),n+` />`}function Rd(e){return`href="`+vt(e)+`"`}function zd(e){return`link[rel="stylesheet"][`+e+`]`}function Bd(e){return P({},e,{"data-precedence":e.precedence,precedence:null})}function Vd(e,t,n,r){e.querySelector(`link[rel="preload"][as="style"][`+t+`]`)?r.loading=aC:(t=e.createElement(`link`),r.preload=t,t.addEventListener(`load`,function(){return r.loading|=aC}),t.addEventListener(`error`,function(){return r.loading|=oC}),ju(t,`link`,n),rt(t),e.head.appendChild(t))}function Hd(e){return`[src="`+vt(e)+`"]`}function Ud(e){return`script[async]`+e}function Wd(e,t,n){if(t.count++,t.instance===null)switch(t.type){case`style`:var r=e.querySelector(`style[data-href~="`+vt(n.href)+`"]`);if(r)return t.instance=r,rt(r),r;var i=P({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return r=(e.ownerDocument||e).createElement(`style`),rt(r),ju(r,`style`,i),Gd(r,n.precedence,e),t.instance=r;case`stylesheet`:i=Rd(n.href);var a=e.querySelector(zd(i));if(a)return t.state.loading|=cC,t.instance=a,rt(a),a;r=Bd(n),(i=lC.get(i))&&Kd(r,i),a=(e.ownerDocument||e).createElement(`link`),rt(a);var o=a;return o._p=new Promise(function(e,t){o.onload=e,o.onerror=t}),ju(a,`link`,r),t.state.loading|=cC,Gd(a,n.precedence,e),t.instance=a;case`script`:return a=Hd(n.src),(i=e.querySelector(Ud(a)))?(t.instance=i,rt(i),i):(r=n,(i=lC.get(a))&&(r=P({},n),qd(r,i)),e=e.ownerDocument||e,i=e.createElement(`script`),rt(i),ju(i,`link`,r),e.head.appendChild(i),t.instance=i);case`void`:return null;default:throw Error(`acquireResource encountered a resource type it did not expect: "`+t.type+`". this is a bug in React.`)}else t.type===`stylesheet`&&(t.state.loading&cC)===iC&&(r=t.instance,t.state.loading|=cC,Gd(r,n.precedence,e));return t.instance}function Gd(e,t,n){for(var r=n.querySelectorAll(`link[rel="stylesheet"][data-precedence],style[data-precedence]`),i=r.length?r[r.length-1]:null,a=i,o=0;o<r.length;o++){var s=r[o];if(s.dataset.precedence===t)a=s;else if(a!==i)break}a?a.parentNode.insertBefore(e,a.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function Kd(e,t){e.crossOrigin??=t.crossOrigin,e.referrerPolicy??=t.referrerPolicy,e.title??=t.title}function qd(e,t){e.crossOrigin??=t.crossOrigin,e.referrerPolicy??=t.referrerPolicy,e.integrity??=t.integrity}function Jd(e,t,n){if(pC===null){var r=new Map,i=pC=new Map;i.set(n,r)}else i=pC,r=i.get(n),r||(r=new Map,i.set(n,r));if(r.has(e))return r;for(r.set(e,null),n=n.getElementsByTagName(e),i=0;i<n.length;i++){var a=n[i];if(!(a[im]||a[Zp]||e===`link`&&a.getAttribute(`rel`)===`stylesheet`)&&a.namespaceURI!==Vm){var o=a.getAttribute(t)||``;o=e+o;var s=r.get(o);s?s.push(a):r.set(o,[a])}}return r}function Yd(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t===`title`?e.querySelector(`head > title`):null)}function Xd(e,t,n){var r=!n.ancestorInfo.containerTagInScope;if(n.context===GS||t.itemProp!=null)return!r||t.itemProp==null||e!==`meta`&&e!==`title`&&e!==`style`&&e!==`link`&&e!==`script`||console.error("Cannot render a <%s> outside the main document if it has an `itemProp` prop. `itemProp` suggests the tag belongs to an `itemScope` which can appear anywhere in the DOM. If you were intending for React to hoist this <%s> remove the `itemProp` prop. Otherwise, try moving this tag into the <head> or <body> of the Document.",e,e),!1;switch(e){case`meta`:case`title`:return!0;case`style`:if(typeof t.precedence!=`string`||typeof t.href!=`string`||t.href===``){r&&console.error('Cannot render a <style> outside the main document without knowing its precedence and a unique href key. React can hoist and deduplicate <style> tags if you provide a `precedence` prop along with an `href` prop that does not conflict with the `href` values used in any other hoisted <style> or <link rel="stylesheet" ...> tags.  Note that hoisting <style> tags is considered an advanced feature that most will not use directly. Consider moving the <style> tag to the <head> or consider adding a `precedence="default"` and `href="some unique resource identifier"`.');break}return!0;case`link`:if(typeof t.rel!=`string`||typeof t.href!=`string`||t.href===``||t.onLoad||t.onError){if(t.rel===`stylesheet`&&typeof t.precedence==`string`){e=t.href;var i=t.onError,a=t.disabled;n=[],t.onLoad&&n.push("`onLoad`"),i&&n.push("`onError`"),a!=null&&n.push("`disabled`"),i=Hu(n,`and`),i+=n.length===1?` prop`:` props`,a=n.length===1?`an `+i:`the `+i,n.length&&console.error('React encountered a <link rel="stylesheet" href="%s" ... /> with a `precedence` prop that also included %s. The presence of loading and error handlers indicates an intent to manage the stylesheet loading state from your from your Component code and React will not hoist or deduplicate this stylesheet. If your intent was to have React hoist and deduplciate this stylesheet using the `precedence` prop remove the %s, otherwise remove the `precedence` prop.',e,a,i)}r&&(typeof t.rel!=`string`||typeof t.href!=`string`||t.href===``?console.error("Cannot render a <link> outside the main document without a `rel` and `href` prop. Try adding a `rel` and/or `href` prop to this <link> or moving the link into the <head> tag"):(t.onError||t.onLoad)&&console.error(`Cannot render a <link> with onLoad or onError listeners outside the main document. Try removing onLoad={...} and onError={...} or moving it into the root <head> tag or somewhere in the <body>.`));break}switch(t.rel){case`stylesheet`:return e=t.precedence,t=t.disabled,typeof e!=`string`&&r&&console.error(`Cannot render a <link rel="stylesheet" /> outside the main document without knowing its precedence. Consider adding precedence="default" or moving it into the root <head> tag.`),typeof e==`string`&&t==null;default:return!0}case`script`:if(e=t.async&&typeof t.async!=`function`&&typeof t.async!=`symbol`,!e||t.onLoad||t.onError||!t.src||typeof t.src!=`string`){r&&(e?t.onLoad||t.onError?console.error(`Cannot render a <script> with onLoad or onError listeners outside the main document. Try removing onLoad={...} and onError={...} or moving it into the root <head> tag or somewhere in the <body>.`):console.error("Cannot render a <script> outside the main document without `async={true}` and a non-empty `src` prop. Ensure there is a valid `src` and either make the script async or move it into the root <head> tag or somewhere in the <body>."):console.error(`Cannot render a sync or defer <script> outside the main document without knowing its order. Try adding async="" or moving it into the root <head> tag.`));break}return!0;case`noscript`:case`template`:r&&console.error(`Cannot render <%s> outside the main document. Try moving it into the root <head> tag.`,e)}return!1}function Zd(e){return!(e.type===`stylesheet`&&(e.state.loading&sC)===iC)}function Qd(e,t,n,r){if(n.type===`stylesheet`&&(typeof r.media!=`string`||!1!==matchMedia(r.media).matches)&&(n.state.loading&cC)===iC){if(n.instance===null){var i=Rd(r.href),a=t.querySelector(zd(i));if(a){t=a._p,typeof t==`object`&&t&&typeof t.then==`function`&&(e.count++,e=ef.bind(e),t.then(e,e)),n.state.loading|=cC,n.instance=a,rt(a);return}a=t.ownerDocument||t,r=Bd(r),(i=lC.get(i))&&Kd(r,i),a=a.createElement(`link`),rt(a);var o=a;o._p=new Promise(function(e,t){o.onload=e,o.onerror=t}),ju(a,`link`,r),n.instance=a}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&sC)===iC&&(e.count++,n=ef.bind(e),t.addEventListener(`load`,n),t.addEventListener(`error`,n))}}function $d(e,t){return e.stylesheets&&e.count===0&&tf(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var r=setTimeout(function(){if(e.stylesheets&&tf(e,e.stylesheets),e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}},mC+t);0<e.imgBytes&&_C===0&&(_C=125*Wu()*gC);var i=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&tf(e,e.stylesheets),e.unsuspend)){var t=e.unsuspend;e.unsuspend=null,t()}},(e.imgBytes>_C?50:hC)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(r),clearTimeout(i)}}:null}function ef(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)tf(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}function tf(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,yC=new Map,t.forEach(nf,e),yC=null,ef.call(e))}function nf(e,t){if(!(t.state.loading&cC)){var n=yC.get(e);if(n)var r=n.get(vC);else{n=new Map,yC.set(e,n);for(var i=e.querySelectorAll(`link[data-precedence],style[data-precedence]`),a=0;a<i.length;a++){var o=i[a];(o.nodeName===`LINK`||o.getAttribute(`media`)!==`not all`)&&(n.set(o.dataset.precedence,o),r=o)}r&&n.set(vC,r)}i=t.instance,o=i.getAttribute(`data-precedence`),a=n.get(o)||r,a===r&&n.set(vC,i),n.set(o,i),this.count++,r=ef.bind(this),i.addEventListener(`load`,r),i.addEventListener(`error`,r),a?a.parentNode.insertBefore(i,a.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(i,e.firstChild)),t.state.loading|=cC}}function rf(e,t,n,r,i,a,o,s,c){for(this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=eC,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Be(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Be(0),this.hiddenUpdates=Be(null),this.identifierPrefix=r,this.onUncaughtError=i,this.onCaughtError=a,this.onRecoverableError=o,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=c,this.incompleteTransitions=new Map,this.passiveEffectDuration=this.effectDuration=-0,this.memoizedUpdaters=new Set,e=this.pendingUpdatersLaneMap=[],t=0;31>t;t++)e.push(new Set);this._debugRootType=n?`hydrateRoot()`:`createRoot()`}function af(e,t,n,r,i,a,o,s,c,l,u,d){return e=new rf(e,t,n,o,c,l,u,d,s),t=Vg,!0===a&&(t|=Hg|Ug),t|=V,a=g(3,null,null,t),e.current=a,a.stateNode=e,t=di(),fi(t),e.pooledCache=t,fi(t),a.memoizedState={element:r,isDehydrated:n,cache:t},ia(a),e}function of(e){return e?(e=Rg,e):Rg}function sf(e,t,n,r,i,a){if(Lp&&typeof Lp.onScheduleFiberRoot==`function`)try{Lp.onScheduleFiberRoot(Ip,r,n)}catch(e){Rp||(Rp=!0,console.error(`React instrumentation encountered an error: %o`,e))}i=of(i),r.context===null?r.context=i:r.pendingContext=i,xp&&bp!==null&&!DC&&(DC=!0,console.error(`Render methods should be a pure function of props and state; triggering nested component updates from render is not allowed. If necessary, trigger nested updates in componentDidUpdate.

Check the render method of %s.`,S(bp)||`Unknown`)),r=oa(t),r.payload={element:n},a=a===void 0?null:a,a!==null&&(typeof a!=`function`&&console.error("Expected the last optional `callback` argument to be a function. Instead received: %s.",a),r.callback=a),n=sa(e,r,t),n!==null&&(mi(t,`root.render()`,null),cl(n,e,t),ca(n,e,t))}function cf(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function lf(e,t){cf(e,t),(e=e.alternate)&&cf(e,t)}function uf(e){if(e.tag===13||e.tag===31){var t=_r(e,67108864);t!==null&&cl(t,e,67108864),lf(e,67108864)}}function df(e){if(e.tag===13||e.tag===31){var t=ol(e);t=Ke(t);var n=_r(e,t);n!==null&&cl(n,e,t),lf(e,t)}}function ff(){return bp}function pf(e,t,n,r){var i=F.T;F.T=null;var a=I.p;try{I.p=Kp,hf(e,t,n,r)}finally{I.p=a,F.T=i}}function mf(e,t,n,r){var i=F.T;F.T=null;var a=I.p;try{I.p=qp,hf(e,t,n,r)}finally{I.p=a,F.T=i}}function hf(e,t,n,r){if(RC){var i=gf(r);if(i===null)vu(e,t,r,zC,n),yf(e,r);else if(xf(i,e,t,n,r))r.stopPropagation();else if(yf(e,r),t&4&&-1<qC.indexOf(e)){for(;i!==null;){var a=et(i);if(a!==null)switch(a.tag){case 3:if(a=a.stateNode,a.current.memoizedState.isDehydrated){var o=Fe(a.pendingLanes);if(o!==0){var s=a;for(s.pendingLanes|=2,s.entangledLanes|=2;o;){var c=1<<31-Bp(o);s.entanglements[1]|=c,o&=~c}eu(a),(Y&(Rb|zb))===Lb&&(bx=Dp()+xx,tu(0,!1))}}break;case 31:case 13:s=_r(a,2),s!==null&&cl(s,a,2),pl(),lf(a,2)}if(a=gf(r),a===null&&vu(e,t,r,zC,n),a===i)break;i=a}i!==null&&r.stopPropagation()}else vu(e,t,r,null,n)}}function gf(e){return e=fn(e),_f(e)}function _f(e){if(zC=null,e=$e(e),e!==null){var t=ee(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=te(t),e!==null)return e;e=null}else if(n===31){if(e=ne(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return zC=e,null}function vf(e){switch(e){case`beforetoggle`:case`cancel`:case`click`:case`close`:case`contextmenu`:case`copy`:case`cut`:case`auxclick`:case`dblclick`:case`dragend`:case`dragstart`:case`drop`:case`focusin`:case`focusout`:case`input`:case`invalid`:case`keydown`:case`keypress`:case`keyup`:case`mousedown`:case`mouseup`:case`paste`:case`pause`:case`play`:case`pointercancel`:case`pointerdown`:case`pointerup`:case`ratechange`:case`reset`:case`resize`:case`seeked`:case`submit`:case`toggle`:case`touchcancel`:case`touchend`:case`touchstart`:case`volumechange`:case`change`:case`selectionchange`:case`textInput`:case`compositionstart`:case`compositionend`:case`compositionupdate`:case`beforeblur`:case`afterblur`:case`beforeinput`:case`blur`:case`fullscreenchange`:case`focus`:case`hashchange`:case`popstate`:case`select`:case`selectstart`:return Kp;case`drag`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`mousemove`:case`mouseout`:case`mouseover`:case`pointermove`:case`pointerout`:case`pointerover`:case`scroll`:case`touchmove`:case`wheel`:case`mouseenter`:case`mouseleave`:case`pointerenter`:case`pointerleave`:return qp;case`message`:switch(Op()){case kp:return Kp;case Ap:return qp;case jp:case Mp:return Jp;case Np:return Yp;default:return Jp}default:return Jp}}function yf(e,t){switch(e){case`focusin`:case`focusout`:VC=null;break;case`dragenter`:case`dragleave`:HC=null;break;case`mouseover`:case`mouseout`:UC=null;break;case`pointerover`:case`pointerout`:WC.delete(t.pointerId);break;case`gotpointercapture`:case`lostpointercapture`:GC.delete(t.pointerId)}}function bf(e,t,n,r,i,a){return e===null||e.nativeEvent!==a?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:a,targetContainers:[i]},t!==null&&(t=et(t),t!==null&&uf(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,i!==null&&t.indexOf(i)===-1&&t.push(i),e)}function xf(e,t,n,r,i){switch(t){case`focusin`:return VC=bf(VC,e,t,n,r,i),!0;case`dragenter`:return HC=bf(HC,e,t,n,r,i),!0;case`mouseover`:return UC=bf(UC,e,t,n,r,i),!0;case`pointerover`:var a=i.pointerId;return WC.set(a,bf(WC.get(a)||null,e,t,n,r,i)),!0;case`gotpointercapture`:return a=i.pointerId,GC.set(a,bf(GC.get(a)||null,e,t,n,r,i)),!0}return!1}function Sf(e){var t=$e(e.target);if(t!==null){var n=ee(t);if(n!==null){if(t=n.tag,t===13){if(t=te(n),t!==null){e.blockedOn=t,Ze(e.priority,function(){df(n)});return}}else if(t===31){if(t=ne(n),t!==null){e.blockedOn=t,Ze(e.priority,function(){df(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Cf(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=gf(e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n),i=r;th!==null&&console.error(`Expected currently replaying event to be null. This error is likely caused by a bug in React. Please file an issue.`),th=i,n.target.dispatchEvent(r),th===null&&console.error(`Expected currently replaying event to not be null. This error is likely caused by a bug in React. Please file an issue.`),th=null}else return t=et(n),t!==null&&uf(t),e.blockedOn=n,!1;t.shift()}return!0}function wf(e,t,n){Cf(e)&&n.delete(t)}function Tf(){BC=!1,VC!==null&&Cf(VC)&&(VC=null),HC!==null&&Cf(HC)&&(HC=null),UC!==null&&Cf(UC)&&(UC=null),WC.forEach(wf),GC.forEach(wf)}function Ef(e,t){e.blockedOn===t&&(e.blockedOn=null,BC||(BC=!0,Nf.unstable_scheduleCallback(Nf.unstable_NormalPriority,Tf)))}function Df(e){JC!==e&&(JC=e,Nf.unstable_scheduleCallback(Nf.unstable_NormalPriority,function(){JC===e&&(JC=null);for(var t=0;t<e.length;t+=3){var n=e[t],r=e[t+1],i=e[t+2];if(typeof r!=`function`){if(_f(r||n)===null)continue;break}var a=et(n);a!==null&&(e.splice(t,3),t-=3,n={pending:!0,data:i,method:n.method,action:r},Object.freeze(n),Bo(a,n,r,i))}}))}function Of(e){function t(t){return Ef(t,e)}VC!==null&&Ef(VC,e),HC!==null&&Ef(HC,e),UC!==null&&Ef(UC,e),WC.forEach(t),GC.forEach(t);for(var n=0;n<KC.length;n++){var r=KC[n];r.blockedOn===e&&(r.blockedOn=null)}for(;0<KC.length&&(n=KC[0],n.blockedOn===null);)Sf(n),n.blockedOn===null&&KC.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(r=0;r<n.length;r+=3){var i=n[r],a=n[r+1],o=i[Qp]||null;if(typeof a==`function`)o||Df(n);else if(o){var s=null;if(a&&a.hasAttribute(`formAction`)){if(i=a,o=a[Qp]||null)s=o.formAction;else if(_f(i)!==null)continue}else s=o.action;typeof s==`function`?n[r+1]=s:(n.splice(r,3),r-=3),Df(n)}}}function kf(){function e(e){e.canIntercept&&e.info===`react-transition`&&e.intercept({handler:function(){return new Promise(function(e){return i=e})},focusReset:`manual`,scroll:`manual`})}function t(){i!==null&&(i(),i=null),r||setTimeout(n,20)}function n(){if(!r&&!navigation.transition){var e=navigation.currentEntry;e&&e.url!=null&&navigation.navigate(e.url,{state:e.getState(),info:`react-transition`,history:`replace`})}}if(typeof navigation==`object`){var r=!1,i=null;return navigation.addEventListener(`navigate`,e),navigation.addEventListener(`navigatesuccess`,t),navigation.addEventListener(`navigateerror`,t),setTimeout(n,100),function(){r=!0,navigation.removeEventListener(`navigate`,e),navigation.removeEventListener(`navigatesuccess`,t),navigation.removeEventListener(`navigateerror`,t),i!==null&&(i(),i=null)}}}function Af(e){this._internalRoot=e}function jf(e){this._internalRoot=e}function Mf(e){e[$p]&&(e._reactRootContainer?console.error(`You are calling ReactDOMClient.createRoot() on a container that was previously passed to ReactDOM.render(). This is not supported.`):console.error(`You are calling ReactDOMClient.createRoot() on a container that has already been passed to createRoot() before. Instead, call root.render() on the existing root instead if you want to update it.`))}typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart==`function`&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());var Nf=f(),Pf=u(),Ff=m(),P=Object.assign,If=Symbol.for(`react.element`),Lf=Symbol.for(`react.transitional.element`),Rf=Symbol.for(`react.portal`),zf=Symbol.for(`react.fragment`),Bf=Symbol.for(`react.strict_mode`),Vf=Symbol.for(`react.profiler`),Hf=Symbol.for(`react.consumer`),Uf=Symbol.for(`react.context`),Wf=Symbol.for(`react.forward_ref`),Gf=Symbol.for(`react.suspense`),Kf=Symbol.for(`react.suspense_list`),qf=Symbol.for(`react.memo`),Jf=Symbol.for(`react.lazy`),Yf=Symbol.for(`react.activity`),Xf=Symbol.for(`react.memo_cache_sentinel`),Zf=Symbol.iterator,Qf=Symbol.for(`react.client.reference`),$f=Array.isArray,F=Pf.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,I=Ff.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ep=Object.freeze({pending:!1,data:null,method:null,action:null}),tp=[],np=[],rp=-1,ip=ce(null),ap=ce(null),op=ce(null),sp=ce(null),cp=0,lp,up,dp,fp,pp,mp,hp;ge.__reactDisabledLog=!0;var gp,_p,vp=!1,yp=new(typeof WeakMap==`function`?WeakMap:Map),bp=null,xp=!1,Sp=Object.prototype.hasOwnProperty,Cp=Nf.unstable_scheduleCallback,wp=Nf.unstable_cancelCallback,Tp=Nf.unstable_shouldYield,Ep=Nf.unstable_requestPaint,Dp=Nf.unstable_now,Op=Nf.unstable_getCurrentPriorityLevel,kp=Nf.unstable_ImmediatePriority,Ap=Nf.unstable_UserBlockingPriority,jp=Nf.unstable_NormalPriority,Mp=Nf.unstable_LowPriority,Np=Nf.unstable_IdlePriority,Pp=Nf.log,Fp=Nf.unstable_setDisableYieldValue,Ip=null,Lp=null,Rp=!1,zp=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`,Bp=Math.clz32?Math.clz32:Pe,Vp=Math.log,Hp=Math.LN2,Up=256,Wp=262144,Gp=4194304,Kp=2,qp=8,Jp=32,Yp=268435456,Xp=Math.random().toString(36).slice(2),Zp=`__reactFiber$`+Xp,Qp=`__reactProps$`+Xp,$p=`__reactContainer$`+Xp,em=`__reactEvents$`+Xp,tm=`__reactListeners$`+Xp,nm=`__reactHandles$`+Xp,rm=`__reactResources$`+Xp,im=`__reactMarker$`+Xp,am=new Set,om={},sm={},cm={button:!0,checkbox:!0,image:!0,hidden:!0,radio:!0,reset:!0,submit:!0},lm=RegExp(`^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),um={},dm={},fm=/[\n"\\]/g,pm=!1,mm=!1,hm=!1,gm=!1,_m=!1,vm=!1,ym=[`value`,`defaultValue`],bm=!1,xm=/["'&<>\n\t]|^\s|\s$/,Sm=`address applet area article aside base basefont bgsound blockquote body br button caption center col colgroup dd details dir div dl dt embed fieldset figcaption figure footer form frame frameset h1 h2 h3 h4 h5 h6 head header hgroup hr html iframe img input isindex li link listing main marquee menu menuitem meta nav noembed noframes noscript object ol p param plaintext pre script section select source style summary table tbody td template textarea tfoot th thead title tr track ul wbr xmp`.split(` `),Cm=`applet caption html table td th marquee object template foreignObject desc title`.split(` `),wm=Cm.concat([`button`]),Tm=`dd dt li option optgroup p rp rt`.split(` `),Em={current:null,formTag:null,aTagInScope:null,buttonTagInScope:null,nobrTagInScope:null,pTagInButtonScope:null,listItemTagAutoclosing:null,dlItemTagAutoclosing:null,containerTagInScope:null,implicitRootScope:!1},Dm={},Om={animation:`animationDelay animationDirection animationDuration animationFillMode animationIterationCount animationName animationPlayState animationTimingFunction`.split(` `),background:`backgroundAttachment backgroundClip backgroundColor backgroundImage backgroundOrigin backgroundPositionX backgroundPositionY backgroundRepeat backgroundSize`.split(` `),backgroundPosition:[`backgroundPositionX`,`backgroundPositionY`],border:`borderBottomColor borderBottomStyle borderBottomWidth borderImageOutset borderImageRepeat borderImageSlice borderImageSource borderImageWidth borderLeftColor borderLeftStyle borderLeftWidth borderRightColor borderRightStyle borderRightWidth borderTopColor borderTopStyle borderTopWidth`.split(` `),borderBlockEnd:[`borderBlockEndColor`,`borderBlockEndStyle`,`borderBlockEndWidth`],borderBlockStart:[`borderBlockStartColor`,`borderBlockStartStyle`,`borderBlockStartWidth`],borderBottom:[`borderBottomColor`,`borderBottomStyle`,`borderBottomWidth`],borderColor:[`borderBottomColor`,`borderLeftColor`,`borderRightColor`,`borderTopColor`],borderImage:[`borderImageOutset`,`borderImageRepeat`,`borderImageSlice`,`borderImageSource`,`borderImageWidth`],borderInlineEnd:[`borderInlineEndColor`,`borderInlineEndStyle`,`borderInlineEndWidth`],borderInlineStart:[`borderInlineStartColor`,`borderInlineStartStyle`,`borderInlineStartWidth`],borderLeft:[`borderLeftColor`,`borderLeftStyle`,`borderLeftWidth`],borderRadius:[`borderBottomLeftRadius`,`borderBottomRightRadius`,`borderTopLeftRadius`,`borderTopRightRadius`],borderRight:[`borderRightColor`,`borderRightStyle`,`borderRightWidth`],borderStyle:[`borderBottomStyle`,`borderLeftStyle`,`borderRightStyle`,`borderTopStyle`],borderTop:[`borderTopColor`,`borderTopStyle`,`borderTopWidth`],borderWidth:[`borderBottomWidth`,`borderLeftWidth`,`borderRightWidth`,`borderTopWidth`],columnRule:[`columnRuleColor`,`columnRuleStyle`,`columnRuleWidth`],columns:[`columnCount`,`columnWidth`],flex:[`flexBasis`,`flexGrow`,`flexShrink`],flexFlow:[`flexDirection`,`flexWrap`],font:`fontFamily fontFeatureSettings fontKerning fontLanguageOverride fontSize fontSizeAdjust fontStretch fontStyle fontVariant fontVariantAlternates fontVariantCaps fontVariantEastAsian fontVariantLigatures fontVariantNumeric fontVariantPosition fontWeight lineHeight`.split(` `),fontVariant:`fontVariantAlternates fontVariantCaps fontVariantEastAsian fontVariantLigatures fontVariantNumeric fontVariantPosition`.split(` `),gap:[`columnGap`,`rowGap`],grid:`gridAutoColumns gridAutoFlow gridAutoRows gridTemplateAreas gridTemplateColumns gridTemplateRows`.split(` `),gridArea:[`gridColumnEnd`,`gridColumnStart`,`gridRowEnd`,`gridRowStart`],gridColumn:[`gridColumnEnd`,`gridColumnStart`],gridColumnGap:[`columnGap`],gridGap:[`columnGap`,`rowGap`],gridRow:[`gridRowEnd`,`gridRowStart`],gridRowGap:[`rowGap`],gridTemplate:[`gridTemplateAreas`,`gridTemplateColumns`,`gridTemplateRows`],listStyle:[`listStyleImage`,`listStylePosition`,`listStyleType`],margin:[`marginBottom`,`marginLeft`,`marginRight`,`marginTop`],marker:[`markerEnd`,`markerMid`,`markerStart`],mask:`maskClip maskComposite maskImage maskMode maskOrigin maskPositionX maskPositionY maskRepeat maskSize`.split(` `),maskPosition:[`maskPositionX`,`maskPositionY`],outline:[`outlineColor`,`outlineStyle`,`outlineWidth`],overflow:[`overflowX`,`overflowY`],padding:[`paddingBottom`,`paddingLeft`,`paddingRight`,`paddingTop`],placeContent:[`alignContent`,`justifyContent`],placeItems:[`alignItems`,`justifyItems`],placeSelf:[`alignSelf`,`justifySelf`],textDecoration:[`textDecorationColor`,`textDecorationLine`,`textDecorationStyle`],textEmphasis:[`textEmphasisColor`,`textEmphasisStyle`],transition:[`transitionDelay`,`transitionDuration`,`transitionProperty`,`transitionTimingFunction`],wordWrap:[`overflowWrap`]},km=/([A-Z])/g,Am=/^ms-/,jm=/^(?:webkit|moz|o)[A-Z]/,Mm=/^-ms-/,Nm=/-(.)/g,Pm=/;\s*$/,Fm={},Im={},Lm=!1,Rm=!1,zm=new Set(`animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(` `)),Bm=`http://www.w3.org/1998/Math/MathML`,Vm=`http://www.w3.org/2000/svg`,Hm=new Map([[`acceptCharset`,`accept-charset`],[`htmlFor`,`for`],[`httpEquiv`,`http-equiv`],[`crossOrigin`,`crossorigin`],[`accentHeight`,`accent-height`],[`alignmentBaseline`,`alignment-baseline`],[`arabicForm`,`arabic-form`],[`baselineShift`,`baseline-shift`],[`capHeight`,`cap-height`],[`clipPath`,`clip-path`],[`clipRule`,`clip-rule`],[`colorInterpolation`,`color-interpolation`],[`colorInterpolationFilters`,`color-interpolation-filters`],[`colorProfile`,`color-profile`],[`colorRendering`,`color-rendering`],[`dominantBaseline`,`dominant-baseline`],[`enableBackground`,`enable-background`],[`fillOpacity`,`fill-opacity`],[`fillRule`,`fill-rule`],[`floodColor`,`flood-color`],[`floodOpacity`,`flood-opacity`],[`fontFamily`,`font-family`],[`fontSize`,`font-size`],[`fontSizeAdjust`,`font-size-adjust`],[`fontStretch`,`font-stretch`],[`fontStyle`,`font-style`],[`fontVariant`,`font-variant`],[`fontWeight`,`font-weight`],[`glyphName`,`glyph-name`],[`glyphOrientationHorizontal`,`glyph-orientation-horizontal`],[`glyphOrientationVertical`,`glyph-orientation-vertical`],[`horizAdvX`,`horiz-adv-x`],[`horizOriginX`,`horiz-origin-x`],[`imageRendering`,`image-rendering`],[`letterSpacing`,`letter-spacing`],[`lightingColor`,`lighting-color`],[`markerEnd`,`marker-end`],[`markerMid`,`marker-mid`],[`markerStart`,`marker-start`],[`overlinePosition`,`overline-position`],[`overlineThickness`,`overline-thickness`],[`paintOrder`,`paint-order`],[`panose-1`,`panose-1`],[`pointerEvents`,`pointer-events`],[`renderingIntent`,`rendering-intent`],[`shapeRendering`,`shape-rendering`],[`stopColor`,`stop-color`],[`stopOpacity`,`stop-opacity`],[`strikethroughPosition`,`strikethrough-position`],[`strikethroughThickness`,`strikethrough-thickness`],[`strokeDasharray`,`stroke-dasharray`],[`strokeDashoffset`,`stroke-dashoffset`],[`strokeLinecap`,`stroke-linecap`],[`strokeLinejoin`,`stroke-linejoin`],[`strokeMiterlimit`,`stroke-miterlimit`],[`strokeOpacity`,`stroke-opacity`],[`strokeWidth`,`stroke-width`],[`textAnchor`,`text-anchor`],[`textDecoration`,`text-decoration`],[`textRendering`,`text-rendering`],[`transformOrigin`,`transform-origin`],[`underlinePosition`,`underline-position`],[`underlineThickness`,`underline-thickness`],[`unicodeBidi`,`unicode-bidi`],[`unicodeRange`,`unicode-range`],[`unitsPerEm`,`units-per-em`],[`vAlphabetic`,`v-alphabetic`],[`vHanging`,`v-hanging`],[`vIdeographic`,`v-ideographic`],[`vMathematical`,`v-mathematical`],[`vectorEffect`,`vector-effect`],[`vertAdvY`,`vert-adv-y`],[`vertOriginX`,`vert-origin-x`],[`vertOriginY`,`vert-origin-y`],[`wordSpacing`,`word-spacing`],[`writingMode`,`writing-mode`],[`xmlnsXlink`,`xmlns:xlink`],[`xHeight`,`x-height`]]),Um={accept:`accept`,acceptcharset:`acceptCharset`,"accept-charset":`acceptCharset`,accesskey:`accessKey`,action:`action`,allowfullscreen:`allowFullScreen`,alt:`alt`,as:`as`,async:`async`,autocapitalize:`autoCapitalize`,autocomplete:`autoComplete`,autocorrect:`autoCorrect`,autofocus:`autoFocus`,autoplay:`autoPlay`,autosave:`autoSave`,capture:`capture`,cellpadding:`cellPadding`,cellspacing:`cellSpacing`,challenge:`challenge`,charset:`charSet`,checked:`checked`,children:`children`,cite:`cite`,class:`className`,classid:`classID`,classname:`className`,cols:`cols`,colspan:`colSpan`,content:`content`,contenteditable:`contentEditable`,contextmenu:`contextMenu`,controls:`controls`,controlslist:`controlsList`,coords:`coords`,crossorigin:`crossOrigin`,dangerouslysetinnerhtml:`dangerouslySetInnerHTML`,data:`data`,datetime:`dateTime`,default:`default`,defaultchecked:`defaultChecked`,defaultvalue:`defaultValue`,defer:`defer`,dir:`dir`,disabled:`disabled`,disablepictureinpicture:`disablePictureInPicture`,disableremoteplayback:`disableRemotePlayback`,download:`download`,draggable:`draggable`,enctype:`encType`,enterkeyhint:`enterKeyHint`,fetchpriority:`fetchPriority`,for:`htmlFor`,form:`form`,formmethod:`formMethod`,formaction:`formAction`,formenctype:`formEncType`,formnovalidate:`formNoValidate`,formtarget:`formTarget`,frameborder:`frameBorder`,headers:`headers`,height:`height`,hidden:`hidden`,high:`high`,href:`href`,hreflang:`hrefLang`,htmlfor:`htmlFor`,httpequiv:`httpEquiv`,"http-equiv":`httpEquiv`,icon:`icon`,id:`id`,imagesizes:`imageSizes`,imagesrcset:`imageSrcSet`,inert:`inert`,innerhtml:`innerHTML`,inputmode:`inputMode`,integrity:`integrity`,is:`is`,itemid:`itemID`,itemprop:`itemProp`,itemref:`itemRef`,itemscope:`itemScope`,itemtype:`itemType`,keyparams:`keyParams`,keytype:`keyType`,kind:`kind`,label:`label`,lang:`lang`,list:`list`,loop:`loop`,low:`low`,manifest:`manifest`,marginwidth:`marginWidth`,marginheight:`marginHeight`,max:`max`,maxlength:`maxLength`,media:`media`,mediagroup:`mediaGroup`,method:`method`,min:`min`,minlength:`minLength`,multiple:`multiple`,muted:`muted`,name:`name`,nomodule:`noModule`,nonce:`nonce`,novalidate:`noValidate`,open:`open`,optimum:`optimum`,pattern:`pattern`,placeholder:`placeholder`,playsinline:`playsInline`,poster:`poster`,preload:`preload`,profile:`profile`,radiogroup:`radioGroup`,readonly:`readOnly`,referrerpolicy:`referrerPolicy`,rel:`rel`,required:`required`,reversed:`reversed`,role:`role`,rows:`rows`,rowspan:`rowSpan`,sandbox:`sandbox`,scope:`scope`,scoped:`scoped`,scrolling:`scrolling`,seamless:`seamless`,selected:`selected`,shape:`shape`,size:`size`,sizes:`sizes`,span:`span`,spellcheck:`spellCheck`,src:`src`,srcdoc:`srcDoc`,srclang:`srcLang`,srcset:`srcSet`,start:`start`,step:`step`,style:`style`,summary:`summary`,tabindex:`tabIndex`,target:`target`,title:`title`,type:`type`,usemap:`useMap`,value:`value`,width:`width`,wmode:`wmode`,wrap:`wrap`,about:`about`,accentheight:`accentHeight`,"accent-height":`accentHeight`,accumulate:`accumulate`,additive:`additive`,alignmentbaseline:`alignmentBaseline`,"alignment-baseline":`alignmentBaseline`,allowreorder:`allowReorder`,alphabetic:`alphabetic`,amplitude:`amplitude`,arabicform:`arabicForm`,"arabic-form":`arabicForm`,ascent:`ascent`,attributename:`attributeName`,attributetype:`attributeType`,autoreverse:`autoReverse`,azimuth:`azimuth`,basefrequency:`baseFrequency`,baselineshift:`baselineShift`,"baseline-shift":`baselineShift`,baseprofile:`baseProfile`,bbox:`bbox`,begin:`begin`,bias:`bias`,by:`by`,calcmode:`calcMode`,capheight:`capHeight`,"cap-height":`capHeight`,clip:`clip`,clippath:`clipPath`,"clip-path":`clipPath`,clippathunits:`clipPathUnits`,cliprule:`clipRule`,"clip-rule":`clipRule`,color:`color`,colorinterpolation:`colorInterpolation`,"color-interpolation":`colorInterpolation`,colorinterpolationfilters:`colorInterpolationFilters`,"color-interpolation-filters":`colorInterpolationFilters`,colorprofile:`colorProfile`,"color-profile":`colorProfile`,colorrendering:`colorRendering`,"color-rendering":`colorRendering`,contentscripttype:`contentScriptType`,contentstyletype:`contentStyleType`,cursor:`cursor`,cx:`cx`,cy:`cy`,d:`d`,datatype:`datatype`,decelerate:`decelerate`,descent:`descent`,diffuseconstant:`diffuseConstant`,direction:`direction`,display:`display`,divisor:`divisor`,dominantbaseline:`dominantBaseline`,"dominant-baseline":`dominantBaseline`,dur:`dur`,dx:`dx`,dy:`dy`,edgemode:`edgeMode`,elevation:`elevation`,enablebackground:`enableBackground`,"enable-background":`enableBackground`,end:`end`,exponent:`exponent`,externalresourcesrequired:`externalResourcesRequired`,fill:`fill`,fillopacity:`fillOpacity`,"fill-opacity":`fillOpacity`,fillrule:`fillRule`,"fill-rule":`fillRule`,filter:`filter`,filterres:`filterRes`,filterunits:`filterUnits`,floodopacity:`floodOpacity`,"flood-opacity":`floodOpacity`,floodcolor:`floodColor`,"flood-color":`floodColor`,focusable:`focusable`,fontfamily:`fontFamily`,"font-family":`fontFamily`,fontsize:`fontSize`,"font-size":`fontSize`,fontsizeadjust:`fontSizeAdjust`,"font-size-adjust":`fontSizeAdjust`,fontstretch:`fontStretch`,"font-stretch":`fontStretch`,fontstyle:`fontStyle`,"font-style":`fontStyle`,fontvariant:`fontVariant`,"font-variant":`fontVariant`,fontweight:`fontWeight`,"font-weight":`fontWeight`,format:`format`,from:`from`,fx:`fx`,fy:`fy`,g1:`g1`,g2:`g2`,glyphname:`glyphName`,"glyph-name":`glyphName`,glyphorientationhorizontal:`glyphOrientationHorizontal`,"glyph-orientation-horizontal":`glyphOrientationHorizontal`,glyphorientationvertical:`glyphOrientationVertical`,"glyph-orientation-vertical":`glyphOrientationVertical`,glyphref:`glyphRef`,gradienttransform:`gradientTransform`,gradientunits:`gradientUnits`,hanging:`hanging`,horizadvx:`horizAdvX`,"horiz-adv-x":`horizAdvX`,horizoriginx:`horizOriginX`,"horiz-origin-x":`horizOriginX`,ideographic:`ideographic`,imagerendering:`imageRendering`,"image-rendering":`imageRendering`,in2:`in2`,in:`in`,inlist:`inlist`,intercept:`intercept`,k1:`k1`,k2:`k2`,k3:`k3`,k4:`k4`,k:`k`,kernelmatrix:`kernelMatrix`,kernelunitlength:`kernelUnitLength`,kerning:`kerning`,keypoints:`keyPoints`,keysplines:`keySplines`,keytimes:`keyTimes`,lengthadjust:`lengthAdjust`,letterspacing:`letterSpacing`,"letter-spacing":`letterSpacing`,lightingcolor:`lightingColor`,"lighting-color":`lightingColor`,limitingconeangle:`limitingConeAngle`,local:`local`,markerend:`markerEnd`,"marker-end":`markerEnd`,markerheight:`markerHeight`,markermid:`markerMid`,"marker-mid":`markerMid`,markerstart:`markerStart`,"marker-start":`markerStart`,markerunits:`markerUnits`,markerwidth:`markerWidth`,mask:`mask`,maskcontentunits:`maskContentUnits`,maskunits:`maskUnits`,mathematical:`mathematical`,mode:`mode`,numoctaves:`numOctaves`,offset:`offset`,opacity:`opacity`,operator:`operator`,order:`order`,orient:`orient`,orientation:`orientation`,origin:`origin`,overflow:`overflow`,overlineposition:`overlinePosition`,"overline-position":`overlinePosition`,overlinethickness:`overlineThickness`,"overline-thickness":`overlineThickness`,paintorder:`paintOrder`,"paint-order":`paintOrder`,panose1:`panose1`,"panose-1":`panose1`,pathlength:`pathLength`,patterncontentunits:`patternContentUnits`,patterntransform:`patternTransform`,patternunits:`patternUnits`,pointerevents:`pointerEvents`,"pointer-events":`pointerEvents`,points:`points`,pointsatx:`pointsAtX`,pointsaty:`pointsAtY`,pointsatz:`pointsAtZ`,popover:`popover`,popovertarget:`popoverTarget`,popovertargetaction:`popoverTargetAction`,prefix:`prefix`,preservealpha:`preserveAlpha`,preserveaspectratio:`preserveAspectRatio`,primitiveunits:`primitiveUnits`,property:`property`,r:`r`,radius:`radius`,refx:`refX`,refy:`refY`,renderingintent:`renderingIntent`,"rendering-intent":`renderingIntent`,repeatcount:`repeatCount`,repeatdur:`repeatDur`,requiredextensions:`requiredExtensions`,requiredfeatures:`requiredFeatures`,resource:`resource`,restart:`restart`,result:`result`,results:`results`,rotate:`rotate`,rx:`rx`,ry:`ry`,scale:`scale`,security:`security`,seed:`seed`,shaperendering:`shapeRendering`,"shape-rendering":`shapeRendering`,slope:`slope`,spacing:`spacing`,specularconstant:`specularConstant`,specularexponent:`specularExponent`,speed:`speed`,spreadmethod:`spreadMethod`,startoffset:`startOffset`,stddeviation:`stdDeviation`,stemh:`stemh`,stemv:`stemv`,stitchtiles:`stitchTiles`,stopcolor:`stopColor`,"stop-color":`stopColor`,stopopacity:`stopOpacity`,"stop-opacity":`stopOpacity`,strikethroughposition:`strikethroughPosition`,"strikethrough-position":`strikethroughPosition`,strikethroughthickness:`strikethroughThickness`,"strikethrough-thickness":`strikethroughThickness`,string:`string`,stroke:`stroke`,strokedasharray:`strokeDasharray`,"stroke-dasharray":`strokeDasharray`,strokedashoffset:`strokeDashoffset`,"stroke-dashoffset":`strokeDashoffset`,strokelinecap:`strokeLinecap`,"stroke-linecap":`strokeLinecap`,strokelinejoin:`strokeLinejoin`,"stroke-linejoin":`strokeLinejoin`,strokemiterlimit:`strokeMiterlimit`,"stroke-miterlimit":`strokeMiterlimit`,strokewidth:`strokeWidth`,"stroke-width":`strokeWidth`,strokeopacity:`strokeOpacity`,"stroke-opacity":`strokeOpacity`,suppresscontenteditablewarning:`suppressContentEditableWarning`,suppresshydrationwarning:`suppressHydrationWarning`,surfacescale:`surfaceScale`,systemlanguage:`systemLanguage`,tablevalues:`tableValues`,targetx:`targetX`,targety:`targetY`,textanchor:`textAnchor`,"text-anchor":`textAnchor`,textdecoration:`textDecoration`,"text-decoration":`textDecoration`,textlength:`textLength`,textrendering:`textRendering`,"text-rendering":`textRendering`,to:`to`,transform:`transform`,transformorigin:`transformOrigin`,"transform-origin":`transformOrigin`,typeof:`typeof`,u1:`u1`,u2:`u2`,underlineposition:`underlinePosition`,"underline-position":`underlinePosition`,underlinethickness:`underlineThickness`,"underline-thickness":`underlineThickness`,unicode:`unicode`,unicodebidi:`unicodeBidi`,"unicode-bidi":`unicodeBidi`,unicoderange:`unicodeRange`,"unicode-range":`unicodeRange`,unitsperem:`unitsPerEm`,"units-per-em":`unitsPerEm`,unselectable:`unselectable`,valphabetic:`vAlphabetic`,"v-alphabetic":`vAlphabetic`,values:`values`,vectoreffect:`vectorEffect`,"vector-effect":`vectorEffect`,version:`version`,vertadvy:`vertAdvY`,"vert-adv-y":`vertAdvY`,vertoriginx:`vertOriginX`,"vert-origin-x":`vertOriginX`,vertoriginy:`vertOriginY`,"vert-origin-y":`vertOriginY`,vhanging:`vHanging`,"v-hanging":`vHanging`,videographic:`vIdeographic`,"v-ideographic":`vIdeographic`,viewbox:`viewBox`,viewtarget:`viewTarget`,visibility:`visibility`,vmathematical:`vMathematical`,"v-mathematical":`vMathematical`,vocab:`vocab`,widths:`widths`,wordspacing:`wordSpacing`,"word-spacing":`wordSpacing`,writingmode:`writingMode`,"writing-mode":`writingMode`,x1:`x1`,x2:`x2`,x:`x`,xchannelselector:`xChannelSelector`,xheight:`xHeight`,"x-height":`xHeight`,xlinkactuate:`xlinkActuate`,"xlink:actuate":`xlinkActuate`,xlinkarcrole:`xlinkArcrole`,"xlink:arcrole":`xlinkArcrole`,xlinkhref:`xlinkHref`,"xlink:href":`xlinkHref`,xlinkrole:`xlinkRole`,"xlink:role":`xlinkRole`,xlinkshow:`xlinkShow`,"xlink:show":`xlinkShow`,xlinktitle:`xlinkTitle`,"xlink:title":`xlinkTitle`,xlinktype:`xlinkType`,"xlink:type":`xlinkType`,xmlbase:`xmlBase`,"xml:base":`xmlBase`,xmllang:`xmlLang`,"xml:lang":`xmlLang`,xmlns:`xmlns`,"xml:space":`xmlSpace`,xmlnsxlink:`xmlnsXlink`,"xmlns:xlink":`xmlnsXlink`,xmlspace:`xmlSpace`,y1:`y1`,y2:`y2`,y:`y`,ychannelselector:`yChannelSelector`,z:`z`,zoomandpan:`zoomAndPan`},Wm={"aria-current":0,"aria-description":0,"aria-details":0,"aria-disabled":0,"aria-hidden":0,"aria-invalid":0,"aria-keyshortcuts":0,"aria-label":0,"aria-roledescription":0,"aria-autocomplete":0,"aria-checked":0,"aria-expanded":0,"aria-haspopup":0,"aria-level":0,"aria-modal":0,"aria-multiline":0,"aria-multiselectable":0,"aria-orientation":0,"aria-placeholder":0,"aria-pressed":0,"aria-readonly":0,"aria-required":0,"aria-selected":0,"aria-sort":0,"aria-valuemax":0,"aria-valuemin":0,"aria-valuenow":0,"aria-valuetext":0,"aria-atomic":0,"aria-busy":0,"aria-live":0,"aria-relevant":0,"aria-dropeffect":0,"aria-grabbed":0,"aria-activedescendant":0,"aria-colcount":0,"aria-colindex":0,"aria-colspan":0,"aria-controls":0,"aria-describedby":0,"aria-errormessage":0,"aria-flowto":0,"aria-labelledby":0,"aria-owns":0,"aria-posinset":0,"aria-rowcount":0,"aria-rowindex":0,"aria-rowspan":0,"aria-setsize":0,"aria-braillelabel":0,"aria-brailleroledescription":0,"aria-colindextext":0,"aria-rowindextext":0},Gm={},Km=RegExp(`^(aria)-[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),qm=RegExp(`^(aria)[A-Z][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),Jm=!1,Ym={},Xm=/^on./,Zm=/^on[^A-Z]/,Qm=RegExp(`^(aria)-[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),$m=RegExp(`^(aria)[A-Z][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),eh=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i,th=null,nh=null,rh=null,ih=!1,ah=!(typeof window>`u`||window.document===void 0||window.document.createElement===void 0),oh=!1;if(ah)try{var sh={};Object.defineProperty(sh,`passive`,{get:function(){oh=!0}}),window.addEventListener(`test`,sh,sh),window.removeEventListener(`test`,sh,sh)}catch{oh=!1}var ch=null,lh=null,uh=null,dh={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},fh=bn(dh),ph=P({},dh,{view:0,detail:0}),mh=bn(ph),hh,gh,_h,vh=P({},ph,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Sn,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return`movementX`in e?e.movementX:(e!==_h&&(_h&&e.type===`mousemove`?(hh=e.screenX-_h.screenX,gh=e.screenY-_h.screenY):gh=hh=0,_h=e),hh)},movementY:function(e){return`movementY`in e?e.movementY:gh}}),yh=bn(vh),bh=bn(P({},vh,{dataTransfer:0})),xh=bn(P({},ph,{relatedTarget:0})),Sh=bn(P({},dh,{animationName:0,elapsedTime:0,pseudoElement:0})),Ch=bn(P({},dh,{clipboardData:function(e){return`clipboardData`in e?e.clipboardData:window.clipboardData}})),wh=bn(P({},dh,{data:0})),Th=wh,Eh={Esc:`Escape`,Spacebar:` `,Left:`ArrowLeft`,Up:`ArrowUp`,Right:`ArrowRight`,Down:`ArrowDown`,Del:`Delete`,Win:`OS`,Menu:`ContextMenu`,Apps:`ContextMenu`,Scroll:`ScrollLock`,MozPrintableKey:`Unidentified`},Dh={8:`Backspace`,9:`Tab`,12:`Clear`,13:`Enter`,16:`Shift`,17:`Control`,18:`Alt`,19:`Pause`,20:`CapsLock`,27:`Escape`,32:` `,33:`PageUp`,34:`PageDown`,35:`End`,36:`Home`,37:`ArrowLeft`,38:`ArrowUp`,39:`ArrowRight`,40:`ArrowDown`,45:`Insert`,46:`Delete`,112:`F1`,113:`F2`,114:`F3`,115:`F4`,116:`F5`,117:`F6`,118:`F7`,119:`F8`,120:`F9`,121:`F10`,122:`F11`,123:`F12`,144:`NumLock`,145:`ScrollLock`,224:`Meta`},Oh={Alt:`altKey`,Control:`ctrlKey`,Meta:`metaKey`,Shift:`shiftKey`},kh=bn(P({},ph,{key:function(e){if(e.key){var t=Eh[e.key]||e.key;if(t!==`Unidentified`)return t}return e.type===`keypress`?(e=_n(e),e===13?`Enter`:String.fromCharCode(e)):e.type===`keydown`||e.type===`keyup`?Dh[e.keyCode]||`Unidentified`:``},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Sn,charCode:function(e){return e.type===`keypress`?_n(e):0},keyCode:function(e){return e.type===`keydown`||e.type===`keyup`?e.keyCode:0},which:function(e){return e.type===`keypress`?_n(e):e.type===`keydown`||e.type===`keyup`?e.keyCode:0}})),Ah=bn(P({},vh,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),jh=bn(P({},ph,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Sn})),Mh=bn(P({},dh,{propertyName:0,elapsedTime:0,pseudoElement:0})),Nh=bn(P({},vh,{deltaX:function(e){return`deltaX`in e?e.deltaX:`wheelDeltaX`in e?-e.wheelDeltaX:0},deltaY:function(e){return`deltaY`in e?e.deltaY:`wheelDeltaY`in e?-e.wheelDeltaY:`wheelDelta`in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),Ph=bn(P({},dh,{newState:0,oldState:0})),Fh=[9,13,27,32],Ih=229,Lh=ah&&`CompositionEvent`in window,Rh=null;ah&&`documentMode`in document&&(Rh=document.documentMode);var zh=ah&&`TextEvent`in window&&!Rh,Bh=ah&&(!Lh||Rh&&8<Rh&&11>=Rh),Vh=32,Hh=String.fromCharCode(Vh),Uh=!1,Wh=!1,Gh={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0},Kh=null,qh=null,Jh=!1;ah&&(Jh=On(`input`)&&(!document.documentMode||9<document.documentMode));var Yh=typeof Object.is==`function`?Object.is:zn,Xh=ah&&`documentMode`in document&&11>=document.documentMode,Zh=null,Qh=null,$h=null,eg=!1,tg={animationend:qn(`Animation`,`AnimationEnd`),animationiteration:qn(`Animation`,`AnimationIteration`),animationstart:qn(`Animation`,`AnimationStart`),transitionrun:qn(`Transition`,`TransitionRun`),transitionstart:qn(`Transition`,`TransitionStart`),transitioncancel:qn(`Transition`,`TransitionCancel`),transitionend:qn(`Transition`,`TransitionEnd`)},ng={},rg={};ah&&(rg=document.createElement(`div`).style,`AnimationEvent`in window||(delete tg.animationend.animation,delete tg.animationiteration.animation,delete tg.animationstart.animation),`TransitionEvent`in window||delete tg.transitionend.transition);var ig=Jn(`animationend`),ag=Jn(`animationiteration`),og=Jn(`animationstart`),sg=Jn(`transitionrun`),cg=Jn(`transitionstart`),lg=Jn(`transitioncancel`),ug=Jn(`transitionend`),dg=new Map,fg=`abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);fg.push(`scrollEnd`);var pg=0;if(typeof performance==`object`&&typeof performance.now==`function`)var mg=performance,hg=function(){return mg.now()};else{var gg=Date;hg=function(){return gg.now()}}var _g=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)},vg=`This object has been omitted by React in the console log to avoid sending too much data from the server. Try logging smaller or more specific objects.`,yg=0,bg=1,xg=2,Sg=3,Cg=`–\xA0`,wg=`+\xA0`,Tg=` \xA0`,L=typeof console<`u`&&typeof console.timeStamp==`function`&&typeof performance<`u`&&typeof performance.measure==`function`,Eg=`Components ⚛`,R=`Scheduler ⚛`,z=`Blocking`,Dg=!1,Og={color:`primary`,properties:null,tooltipText:``,track:Eg},kg={start:-0,end:-0,detail:{devtools:Og}},Ag=[`Changed Props`,``],jg=`This component received deeply equal props. It might benefit from useMemo or the React Compiler in its owner.`,Mg=[`Changed Props`,jg],Ng=1,Pg=2,Fg=[],Ig=0,Lg=0,Rg={};Object.freeze(Rg);var zg=null,Bg=null,B=0,Vg=1,V=2,Hg=8,Ug=16,Wg=32,Gg=!1;try{var Kg=Object.preventExtensions({});new Map([[Kg,null]]),new Set([Kg])}catch{Gg=!0}var qg=new WeakMap,Jg=[],Yg=0,Xg=null,Zg=0,Qg=[],$g=0,e_=null,t_=1,n_=``,r_=null,i_=null,H=!1,a_=!1,o_=null,s_=null,c_=!1,l_=Error(`Hydration Mismatch Exception: This is not a real error, and should not leak into userspace. If you're seeing this, it's likely a bug in React.`),u_=ce(null),d_=ce(null),f_={},p_=null,m_=null,h_=!1,g_=typeof AbortController<`u`?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(t,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(e){return e()})}},__=Nf.unstable_scheduleCallback,v_=Nf.unstable_NormalPriority,y_={$$typeof:Uf,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0,_currentRenderer:null,_currentRenderer2:null},b_=Nf.unstable_now,x_=console.createTask?console.createTask:function(){return null},S_=1,C_=2,w_=-0,T_=-0,E_=-0,D_=null,O_=-1.1,k_=-0,A_=-0,U=-1.1,W=-1.1,j_=null,M_=!1,N_=-0,P_=-1.1,F_=null,I_=0,L_=null,R_=null,z_=-1.1,B_=null,V_=-1.1,H_=-1.1,U_=-0,W_=-1.1,G_=-1.1,K_=0,q_=null,J_=null,Y_=null,X_=-1.1,Z_=null,Q_=-1.1,$_=-1.1,ev=-0,tv=-0,nv=0,rv=null,iv=0,av=-1.1,ov=!1,sv=!1,cv=null,lv=0,uv=0,dv=null,fv=F.S;F.S=function(e,t){if(vx=Dp(),typeof t==`object`&&t&&typeof t.then==`function`){if(0>W_&&0>G_){W_=b_();var n=Zu(),r=Xu();(n!==Q_||r!==Z_)&&(Q_=-1.1),X_=n,Z_=r}Ni(e,t)}fv!==null&&fv(e,t)};var pv=ce(null),mv={recordUnsafeLifecycleWarnings:function(){},flushPendingUnsafeLifecycleWarnings:function(){},recordLegacyContextWarning:function(){},flushLegacyContextWarning:function(){},discardPendingWarnings:function(){}},hv=[],gv=[],_v=[],vv=[],yv=[],bv=[],xv=new Set;mv.recordUnsafeLifecycleWarnings=function(e,t){xv.has(e.type)||(typeof t.componentWillMount==`function`&&!0!==t.componentWillMount.__suppressDeprecationWarning&&hv.push(e),e.mode&Hg&&typeof t.UNSAFE_componentWillMount==`function`&&gv.push(e),typeof t.componentWillReceiveProps==`function`&&!0!==t.componentWillReceiveProps.__suppressDeprecationWarning&&_v.push(e),e.mode&Hg&&typeof t.UNSAFE_componentWillReceiveProps==`function`&&vv.push(e),typeof t.componentWillUpdate==`function`&&!0!==t.componentWillUpdate.__suppressDeprecationWarning&&yv.push(e),e.mode&Hg&&typeof t.UNSAFE_componentWillUpdate==`function`&&bv.push(e))},mv.flushPendingUnsafeLifecycleWarnings=function(){var e=new Set;0<hv.length&&(hv.forEach(function(t){e.add(S(t)||`Component`),xv.add(t.type)}),hv=[]);var t=new Set;0<gv.length&&(gv.forEach(function(e){t.add(S(e)||`Component`),xv.add(e.type)}),gv=[]);var n=new Set;0<_v.length&&(_v.forEach(function(e){n.add(S(e)||`Component`),xv.add(e.type)}),_v=[]);var r=new Set;0<vv.length&&(vv.forEach(function(e){r.add(S(e)||`Component`),xv.add(e.type)}),vv=[]);var i=new Set;0<yv.length&&(yv.forEach(function(e){i.add(S(e)||`Component`),xv.add(e.type)}),yv=[]);var a=new Set;if(0<bv.length&&(bv.forEach(function(e){a.add(S(e)||`Component`),xv.add(e.type)}),bv=[]),0<t.size){var o=h(t);console.error(`Using UNSAFE_componentWillMount in strict mode is not recommended and may indicate bugs in your code. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move code with side effects to componentDidMount, and set initial state in the constructor.

Please update the following components: %s`,o)}0<r.size&&(o=h(r),console.error(`Using UNSAFE_componentWillReceiveProps in strict mode is not recommended and may indicate bugs in your code. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* If you're updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://react.dev/link/derived-state

Please update the following components: %s`,o)),0<a.size&&(o=h(a),console.error(`Using UNSAFE_componentWillUpdate in strict mode is not recommended and may indicate bugs in your code. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.

Please update the following components: %s`,o)),0<e.size&&(o=h(e),console.warn(`componentWillMount has been renamed, and is not recommended for use. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move code with side effects to componentDidMount, and set initial state in the constructor.
* Rename componentWillMount to UNSAFE_componentWillMount to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`,o)),0<n.size&&(o=h(n),console.warn(`componentWillReceiveProps has been renamed, and is not recommended for use. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* If you're updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://react.dev/link/derived-state
* Rename componentWillReceiveProps to UNSAFE_componentWillReceiveProps to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`,o)),0<i.size&&(o=h(i),console.warn(`componentWillUpdate has been renamed, and is not recommended for use. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* Rename componentWillUpdate to UNSAFE_componentWillUpdate to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`,o))};var Sv=new Map,Cv=new Set;mv.recordLegacyContextWarning=function(e,t){for(var n=null,r=e;r!==null;)r.mode&Hg&&(n=r),r=r.return;n===null?console.error(`Expected to find a StrictMode component in a strict mode tree. This error is likely caused by a bug in React. Please file an issue.`):!Cv.has(e.type)&&(r=Sv.get(n),e.type.contextTypes!=null||e.type.childContextTypes!=null||t!==null&&typeof t.getChildContext==`function`)&&(r===void 0&&(r=[],Sv.set(n,r)),r.push(e))},mv.flushLegacyContextWarning=function(){Sv.forEach(function(e){if(e.length!==0){var t=e[0],n=new Set;e.forEach(function(e){n.add(S(e)||`Component`),Cv.add(e.type)});var r=h(n);w(t,function(){console.error(`Legacy context API has been detected within a strict-mode tree.

The old API will be supported in all 16.x releases, but applications using it should migrate to the new version.

Please update the following components: %s

Learn more about this warning here: https://react.dev/link/legacy-context`,r)})}})},mv.discardPendingWarnings=function(){hv=[],gv=[],_v=[],vv=[],yv=[],bv=[],Sv=new Map};var wv={react_stack_bottom_frame:function(e,t,n){var r=xp;xp=!0;try{return e(t,n)}finally{xp=r}}},Tv=wv.react_stack_bottom_frame.bind(wv),Ev={react_stack_bottom_frame:function(e){var t=xp;xp=!0;try{return e.render()}finally{xp=t}}},Dv=Ev.react_stack_bottom_frame.bind(Ev),Ov={react_stack_bottom_frame:function(e,t){try{t.componentDidMount()}catch(t){j(e,e.return,t)}}},kv=Ov.react_stack_bottom_frame.bind(Ov),Av={react_stack_bottom_frame:function(e,t,n,r,i){try{t.componentDidUpdate(n,r,i)}catch(t){j(e,e.return,t)}}},jv=Av.react_stack_bottom_frame.bind(Av),Mv={react_stack_bottom_frame:function(e,t){var n=t.stack;e.componentDidCatch(t.value,{componentStack:n===null?``:n})}},Nv=Mv.react_stack_bottom_frame.bind(Mv),Pv={react_stack_bottom_frame:function(e,t,n){try{n.componentWillUnmount()}catch(n){j(e,t,n)}}},Fv=Pv.react_stack_bottom_frame.bind(Pv),Iv={react_stack_bottom_frame:function(e){var t=e.create;return e=e.inst,t=t(),e.destroy=t}},Lv=Iv.react_stack_bottom_frame.bind(Iv),Rv={react_stack_bottom_frame:function(e,t,n){try{n()}catch(n){j(e,t,n)}}},zv=Rv.react_stack_bottom_frame.bind(Rv),Bv={react_stack_bottom_frame:function(e){var t=e._init;return t(e._payload)}},Vv=Bv.react_stack_bottom_frame.bind(Bv),Hv=Error("Suspense Exception: This is not a real error! It's an implementation detail of `use` to interrupt the current render. You must either rethrow it immediately, or move the `use` call outside of the `try/catch` block. Capturing without rethrowing will lead to unexpected behavior.\n\nTo handle async errors, wrap your component in an error boundary, or call the promise's `.catch` method and pass the result to `use`."),Uv=Error(`Suspense Exception: This is not a real error, and should not leak into userspace. If you're seeing this, it's likely a bug in React.`),Wv=Error("Suspense Exception: This is not a real error! It's an implementation detail of `useActionState` to interrupt the current render. You must either rethrow it immediately, or move the `useActionState` call outside of the `try/catch` block. Capturing without rethrowing will lead to unexpected behavior.\n\nTo handle async errors, wrap your component in an error boundary."),Gv={then:function(){console.error(`Internal React error: A listener was unexpectedly attached to a "noop" thenable. This is a bug in React. Please file an issue.`)}},Kv=null,qv=!1,Jv=null,Yv=0,G=null,Xv,Zv=Xv=!1,Qv={},$v={},ey={};p=function(e,t,n){if(typeof n==`object`&&n&&n._store&&(!n._store.validated&&n.key==null||n._store.validated===2)){if(typeof n._store!=`object`)throw Error(`React Component in warnForMissingKey should have a _store. This error is likely caused by a bug in React. Please file an issue.`);n._store.validated=1;var r=S(e),i=r||`null`;if(!Qv[i]){Qv[i]=!0,n=n._owner,e=e._debugOwner;var a=``;e&&typeof e.tag==`number`&&(i=S(e))&&(a=`

Check the render method of \``+i+"`."),a||r&&(a=`

Check the top-level render call using <`+r+`>.`);var o=``;n!=null&&e!==n&&(r=null,typeof n.tag==`number`?r=S(n):typeof n.name==`string`&&(r=n.name),r&&(o=` It was passed a child from `+r+`.`)),w(t,function(){console.error(`Each child in a list should have a unique "key" prop.%s%s See https://react.dev/link/warning-keys for more information.`,a,o)})}}};var ty=na(!0),ny=na(!1),ry=0,iy=1,ay=2,oy=3,sy=!1,cy=!1,ly=null,uy=!1,dy=ce(null),fy=ce(0),py=ce(null),my=null,hy=1,gy=2,_y=ce(0),vy=0,yy=1,by=2,xy=4,Sy=8,Cy,wy=new Set,Ty=new Set,Ey=new Set,Dy=new Set,Oy=0,K=null,q=null,ky=null,Ay=!1,jy=!1,My=!1,Ny=0,Py=0,Fy=null,Iy=0,Ly=25,J=null,Ry=null,zy=-1,By=!1,Vy={readContext:ci,use:Ra,useCallback:Ea,useContext:Ea,useEffect:Ea,useImperativeHandle:Ea,useLayoutEffect:Ea,useInsertionEffect:Ea,useMemo:Ea,useReducer:Ea,useRef:Ea,useState:Ea,useDebugValue:Ea,useDeferredValue:Ea,useTransition:Ea,useSyncExternalStore:Ea,useId:Ea,useHostTransitionStatus:Ea,useFormState:Ea,useActionState:Ea,useOptimistic:Ea,useMemoCache:Ea,useCacheRefresh:Ea};Vy.useEffectEvent=Ea;var Hy=null,Uy=null,Wy=null,Gy=null,Ky=null,qy=null,Jy=null;Hy={readContext:function(e){return ci(e)},use:Ra,useCallback:function(e,t){return J=`useCallback`,D(),wa(t),ko(e,t)},useContext:function(e){return J=`useContext`,D(),ci(e)},useEffect:function(e,t){return J=`useEffect`,D(),wa(t),xo(e,t)},useImperativeHandle:function(e,t,n){return J=`useImperativeHandle`,D(),wa(n),Do(e,t,n)},useInsertionEffect:function(e,t){J=`useInsertionEffect`,D(),wa(t),yo(4,by,e,t)},useLayoutEffect:function(e,t){return J=`useLayoutEffect`,D(),wa(t),To(e,t)},useMemo:function(e,t){J=`useMemo`,D(),wa(t);var n=F.H;F.H=Ky;try{return jo(e,t)}finally{F.H=n}},useReducer:function(e,t,n){J=`useReducer`,D();var r=F.H;F.H=Ky;try{return Va(e,t,n)}finally{F.H=r}},useRef:function(e){return J=`useRef`,D(),vo(e)},useState:function(e){J=`useState`,D();var t=F.H;F.H=Ky;try{return $a(e)}finally{F.H=t}},useDebugValue:function(){J=`useDebugValue`,D()},useDeferredValue:function(e,t){return J=`useDeferredValue`,D(),No(e,t)},useTransition:function(){return J=`useTransition`,D(),Uo()},useSyncExternalStore:function(e,t,n){return J=`useSyncExternalStore`,D(),Ga(e,t,n)},useId:function(){return J=`useId`,D(),qo()},useFormState:function(e,t){return J=`useFormState`,D(),Ta(),fo(e,t)},useActionState:function(e,t){return J=`useActionState`,D(),fo(e,t)},useOptimistic:function(e){return J=`useOptimistic`,D(),eo(e)},useHostTransitionStatus:Ko,useMemoCache:za,useCacheRefresh:function(){return J=`useCacheRefresh`,D(),Jo()},useEffectEvent:function(e){return J=`useEffectEvent`,D(),Co(e)}},Uy={readContext:function(e){return ci(e)},use:Ra,useCallback:function(e,t){return J=`useCallback`,O(),ko(e,t)},useContext:function(e){return J=`useContext`,O(),ci(e)},useEffect:function(e,t){return J=`useEffect`,O(),xo(e,t)},useImperativeHandle:function(e,t,n){return J=`useImperativeHandle`,O(),Do(e,t,n)},useInsertionEffect:function(e,t){J=`useInsertionEffect`,O(),yo(4,by,e,t)},useLayoutEffect:function(e,t){return J=`useLayoutEffect`,O(),To(e,t)},useMemo:function(e,t){J=`useMemo`,O();var n=F.H;F.H=Ky;try{return jo(e,t)}finally{F.H=n}},useReducer:function(e,t,n){J=`useReducer`,O();var r=F.H;F.H=Ky;try{return Va(e,t,n)}finally{F.H=r}},useRef:function(e){return J=`useRef`,O(),vo(e)},useState:function(e){J=`useState`,O();var t=F.H;F.H=Ky;try{return $a(e)}finally{F.H=t}},useDebugValue:function(){J=`useDebugValue`,O()},useDeferredValue:function(e,t){return J=`useDeferredValue`,O(),No(e,t)},useTransition:function(){return J=`useTransition`,O(),Uo()},useSyncExternalStore:function(e,t,n){return J=`useSyncExternalStore`,O(),Ga(e,t,n)},useId:function(){return J=`useId`,O(),qo()},useActionState:function(e,t){return J=`useActionState`,O(),fo(e,t)},useFormState:function(e,t){return J=`useFormState`,O(),Ta(),fo(e,t)},useOptimistic:function(e){return J=`useOptimistic`,O(),eo(e)},useHostTransitionStatus:Ko,useMemoCache:za,useCacheRefresh:function(){return J=`useCacheRefresh`,O(),Jo()},useEffectEvent:function(e){return J=`useEffectEvent`,O(),Co(e)}},Wy={readContext:function(e){return ci(e)},use:Ra,useCallback:function(e,t){return J=`useCallback`,O(),Ao(e,t)},useContext:function(e){return J=`useContext`,O(),ci(e)},useEffect:function(e,t){J=`useEffect`,O(),bo(2048,Sy,e,t)},useImperativeHandle:function(e,t,n){return J=`useImperativeHandle`,O(),Oo(e,t,n)},useInsertionEffect:function(e,t){return J=`useInsertionEffect`,O(),bo(4,by,e,t)},useLayoutEffect:function(e,t){return J=`useLayoutEffect`,O(),bo(4,xy,e,t)},useMemo:function(e,t){J=`useMemo`,O();var n=F.H;F.H=qy;try{return Mo(e,t)}finally{F.H=n}},useReducer:function(e,t,n){J=`useReducer`,O();var r=F.H;F.H=qy;try{return Ha(e,t,n)}finally{F.H=r}},useRef:function(){return J=`useRef`,O(),k().memoizedState},useState:function(){J=`useState`,O();var e=F.H;F.H=qy;try{return Ha(Ba)}finally{F.H=e}},useDebugValue:function(){J=`useDebugValue`,O()},useDeferredValue:function(e,t){return J=`useDeferredValue`,O(),Po(e,t)},useTransition:function(){return J=`useTransition`,O(),Wo()},useSyncExternalStore:function(e,t,n){return J=`useSyncExternalStore`,O(),Ka(e,t,n)},useId:function(){return J=`useId`,O(),k().memoizedState},useFormState:function(e){return J=`useFormState`,O(),Ta(),po(e)},useActionState:function(e){return J=`useActionState`,O(),po(e)},useOptimistic:function(e,t){return J=`useOptimistic`,O(),to(e,t)},useHostTransitionStatus:Ko,useMemoCache:za,useCacheRefresh:function(){return J=`useCacheRefresh`,O(),k().memoizedState},useEffectEvent:function(e){return J=`useEffectEvent`,O(),wo(e)}},Gy={readContext:function(e){return ci(e)},use:Ra,useCallback:function(e,t){return J=`useCallback`,O(),Ao(e,t)},useContext:function(e){return J=`useContext`,O(),ci(e)},useEffect:function(e,t){J=`useEffect`,O(),bo(2048,Sy,e,t)},useImperativeHandle:function(e,t,n){return J=`useImperativeHandle`,O(),Oo(e,t,n)},useInsertionEffect:function(e,t){return J=`useInsertionEffect`,O(),bo(4,by,e,t)},useLayoutEffect:function(e,t){return J=`useLayoutEffect`,O(),bo(4,xy,e,t)},useMemo:function(e,t){J=`useMemo`,O();var n=F.H;F.H=Jy;try{return Mo(e,t)}finally{F.H=n}},useReducer:function(e,t,n){J=`useReducer`,O();var r=F.H;F.H=Jy;try{return Wa(e,t,n)}finally{F.H=r}},useRef:function(){return J=`useRef`,O(),k().memoizedState},useState:function(){J=`useState`,O();var e=F.H;F.H=Jy;try{return Wa(Ba)}finally{F.H=e}},useDebugValue:function(){J=`useDebugValue`,O()},useDeferredValue:function(e,t){return J=`useDeferredValue`,O(),Fo(e,t)},useTransition:function(){return J=`useTransition`,O(),Go()},useSyncExternalStore:function(e,t,n){return J=`useSyncExternalStore`,O(),Ka(e,t,n)},useId:function(){return J=`useId`,O(),k().memoizedState},useFormState:function(e){return J=`useFormState`,O(),Ta(),go(e)},useActionState:function(e){return J=`useActionState`,O(),go(e)},useOptimistic:function(e,t){return J=`useOptimistic`,O(),ro(e,t)},useHostTransitionStatus:Ko,useMemoCache:za,useCacheRefresh:function(){return J=`useCacheRefresh`,O(),k().memoizedState},useEffectEvent:function(e){return J=`useEffectEvent`,O(),wo(e)}},Ky={readContext:function(e){return l(),ci(e)},use:function(e){return c(),Ra(e)},useCallback:function(e,t){return J=`useCallback`,c(),D(),ko(e,t)},useContext:function(e){return J=`useContext`,c(),D(),ci(e)},useEffect:function(e,t){return J=`useEffect`,c(),D(),xo(e,t)},useImperativeHandle:function(e,t,n){return J=`useImperativeHandle`,c(),D(),Do(e,t,n)},useInsertionEffect:function(e,t){J=`useInsertionEffect`,c(),D(),yo(4,by,e,t)},useLayoutEffect:function(e,t){return J=`useLayoutEffect`,c(),D(),To(e,t)},useMemo:function(e,t){J=`useMemo`,c(),D();var n=F.H;F.H=Ky;try{return jo(e,t)}finally{F.H=n}},useReducer:function(e,t,n){J=`useReducer`,c(),D();var r=F.H;F.H=Ky;try{return Va(e,t,n)}finally{F.H=r}},useRef:function(e){return J=`useRef`,c(),D(),vo(e)},useState:function(e){J=`useState`,c(),D();var t=F.H;F.H=Ky;try{return $a(e)}finally{F.H=t}},useDebugValue:function(){J=`useDebugValue`,c(),D()},useDeferredValue:function(e,t){return J=`useDeferredValue`,c(),D(),No(e,t)},useTransition:function(){return J=`useTransition`,c(),D(),Uo()},useSyncExternalStore:function(e,t,n){return J=`useSyncExternalStore`,c(),D(),Ga(e,t,n)},useId:function(){return J=`useId`,c(),D(),qo()},useFormState:function(e,t){return J=`useFormState`,c(),D(),fo(e,t)},useActionState:function(e,t){return J=`useActionState`,c(),D(),fo(e,t)},useOptimistic:function(e){return J=`useOptimistic`,c(),D(),eo(e)},useMemoCache:function(e){return c(),za(e)},useHostTransitionStatus:Ko,useCacheRefresh:function(){return J=`useCacheRefresh`,D(),Jo()},useEffectEvent:function(e){return J=`useEffectEvent`,c(),D(),Co(e)}},qy={readContext:function(e){return l(),ci(e)},use:function(e){return c(),Ra(e)},useCallback:function(e,t){return J=`useCallback`,c(),O(),Ao(e,t)},useContext:function(e){return J=`useContext`,c(),O(),ci(e)},useEffect:function(e,t){J=`useEffect`,c(),O(),bo(2048,Sy,e,t)},useImperativeHandle:function(e,t,n){return J=`useImperativeHandle`,c(),O(),Oo(e,t,n)},useInsertionEffect:function(e,t){return J=`useInsertionEffect`,c(),O(),bo(4,by,e,t)},useLayoutEffect:function(e,t){return J=`useLayoutEffect`,c(),O(),bo(4,xy,e,t)},useMemo:function(e,t){J=`useMemo`,c(),O();var n=F.H;F.H=qy;try{return Mo(e,t)}finally{F.H=n}},useReducer:function(e,t,n){J=`useReducer`,c(),O();var r=F.H;F.H=qy;try{return Ha(e,t,n)}finally{F.H=r}},useRef:function(){return J=`useRef`,c(),O(),k().memoizedState},useState:function(){J=`useState`,c(),O();var e=F.H;F.H=qy;try{return Ha(Ba)}finally{F.H=e}},useDebugValue:function(){J=`useDebugValue`,c(),O()},useDeferredValue:function(e,t){return J=`useDeferredValue`,c(),O(),Po(e,t)},useTransition:function(){return J=`useTransition`,c(),O(),Wo()},useSyncExternalStore:function(e,t,n){return J=`useSyncExternalStore`,c(),O(),Ka(e,t,n)},useId:function(){return J=`useId`,c(),O(),k().memoizedState},useFormState:function(e){return J=`useFormState`,c(),O(),po(e)},useActionState:function(e){return J=`useActionState`,c(),O(),po(e)},useOptimistic:function(e,t){return J=`useOptimistic`,c(),O(),to(e,t)},useMemoCache:function(e){return c(),za(e)},useHostTransitionStatus:Ko,useCacheRefresh:function(){return J=`useCacheRefresh`,O(),k().memoizedState},useEffectEvent:function(e){return J=`useEffectEvent`,c(),O(),wo(e)}},Jy={readContext:function(e){return l(),ci(e)},use:function(e){return c(),Ra(e)},useCallback:function(e,t){return J=`useCallback`,c(),O(),Ao(e,t)},useContext:function(e){return J=`useContext`,c(),O(),ci(e)},useEffect:function(e,t){J=`useEffect`,c(),O(),bo(2048,Sy,e,t)},useImperativeHandle:function(e,t,n){return J=`useImperativeHandle`,c(),O(),Oo(e,t,n)},useInsertionEffect:function(e,t){return J=`useInsertionEffect`,c(),O(),bo(4,by,e,t)},useLayoutEffect:function(e,t){return J=`useLayoutEffect`,c(),O(),bo(4,xy,e,t)},useMemo:function(e,t){J=`useMemo`,c(),O();var n=F.H;F.H=qy;try{return Mo(e,t)}finally{F.H=n}},useReducer:function(e,t,n){J=`useReducer`,c(),O();var r=F.H;F.H=qy;try{return Wa(e,t,n)}finally{F.H=r}},useRef:function(){return J=`useRef`,c(),O(),k().memoizedState},useState:function(){J=`useState`,c(),O();var e=F.H;F.H=qy;try{return Wa(Ba)}finally{F.H=e}},useDebugValue:function(){J=`useDebugValue`,c(),O()},useDeferredValue:function(e,t){return J=`useDeferredValue`,c(),O(),Fo(e,t)},useTransition:function(){return J=`useTransition`,c(),O(),Go()},useSyncExternalStore:function(e,t,n){return J=`useSyncExternalStore`,c(),O(),Ka(e,t,n)},useId:function(){return J=`useId`,c(),O(),k().memoizedState},useFormState:function(e){return J=`useFormState`,c(),O(),go(e)},useActionState:function(e){return J=`useActionState`,c(),O(),go(e)},useOptimistic:function(e,t){return J=`useOptimistic`,c(),O(),ro(e,t)},useMemoCache:function(e){return c(),za(e)},useHostTransitionStatus:Ko,useCacheRefresh:function(){return J=`useCacheRefresh`,O(),k().memoizedState},useEffectEvent:function(e){return J=`useEffectEvent`,c(),O(),wo(e)}};var Yy={},Xy=new Set,Zy=new Set,Qy=new Set,$y=new Set,eb=new Set,tb=new Set,nb=new Set,rb=new Set,ib=new Set,ab=new Set;Object.freeze(Yy);var ob={enqueueSetState:function(e,t,n){e=e._reactInternals;var r=ol(e),i=oa(r);i.payload=t,n!=null&&(rs(n),i.callback=n),t=sa(e,i,r),t!==null&&(mi(r,`this.setState()`,e),cl(t,e,r),ca(t,e,r))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=ol(e),i=oa(r);i.tag=iy,i.payload=t,n!=null&&(rs(n),i.callback=n),t=sa(e,i,r),t!==null&&(mi(r,`this.replaceState()`,e),cl(t,e,r),ca(t,e,r))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=ol(e),r=oa(n);r.tag=ay,t!=null&&(rs(t),r.callback=t),t=sa(e,r,n),t!==null&&(mi(n,`this.forceUpdate()`,e),cl(t,e,n),ca(t,e,n))}},sb=null,cb=null,lb=Error(`This is not a real error. It's an implementation detail of React's selective hydration feature. If this leaks into userspace, it's a bug in React. Please file an issue.`),ub=!1,db={},fb={},pb={},mb={},hb=!1,gb={},_b={},vb={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null},yb=!1,bb=null;bb=new Set;var xb=!1,Sb=!1,Cb=!1,wb=typeof WeakSet==`function`?WeakSet:Set,Tb=null,Eb=null,Db=null,Ob=null,kb=!1,Ab=null,jb=!1,Mb=8192,Nb={getCacheForType:function(e){var t=ci(y_),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return ci(y_).controller.signal},getOwner:function(){return bp}};if(typeof Symbol==`function`&&Symbol.for){var Pb=Symbol.for;Pb(`selector.component`),Pb(`selector.has_pseudo_class`),Pb(`selector.role`),Pb(`selector.test_id`),Pb(`selector.text`)}var Fb=[],Ib=typeof WeakMap==`function`?WeakMap:Map,Lb=0,Rb=2,zb=4,Bb=0,Vb=1,Hb=2,Ub=3,Wb=4,Gb=6,Kb=5,Y=Lb,X=null,Z=null,Q=0,qb=0,Jb=1,Yb=2,Xb=3,Zb=4,Qb=5,$b=6,ex=7,tx=8,nx=9,$=qb,rx=null,ix=!1,ax=!1,ox=!1,sx=0,cx=Bb,lx=0,ux=0,dx=0,fx=0,px=0,mx=null,hx=null,gx=!1,_x=0,vx=0,yx=300,bx=1/0,xx=500,Sx=null,Cx=null,wx=null,Tx=0,Ex=1,Dx=2,Ox=3,kx=0,Ax=1,jx=2,Mx=3,Nx=4,Px=5,Fx=0,Ix=null,Lx=null,Rx=0,zx=0,Bx=-0,Vx=null,Hx=null,Ux=null,Wx=Tx,Gx=null,Kx=50,qx=0,Jx=null,Yx=!1,Xx=!1,Zx=50,Qx=0,$x=null,eS=!1,tS=null,nS=!1,rS=new Set,iS={},aS=null,oS=null,sS=!1,cS=!1,lS=!1,uS=!1,dS=0,fS={};(function(){for(var e=0;e<fg.length;e++){var t=fg[e],n=t.toLowerCase();t=t[0].toUpperCase()+t.slice(1),Yn(n,`on`+t)}Yn(ig,`onAnimationEnd`),Yn(ag,`onAnimationIteration`),Yn(og,`onAnimationStart`),Yn(`dblclick`,`onDoubleClick`),Yn(`focusin`,`onFocus`),Yn(`focusout`,`onBlur`),Yn(sg,`onTransitionRun`),Yn(cg,`onTransitionStart`),Yn(lg,`onTransitionCancel`),Yn(ug,`onTransitionEnd`)})(),at(`onMouseEnter`,[`mouseout`,`mouseover`]),at(`onMouseLeave`,[`mouseout`,`mouseover`]),at(`onPointerEnter`,[`pointerout`,`pointerover`]),at(`onPointerLeave`,[`pointerout`,`pointerover`]),it(`onChange`,`change click focusin focusout input keydown keyup selectionchange`.split(` `)),it(`onSelect`,`focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)),it(`onBeforeInput`,[`compositionend`,`keypress`,`textInput`,`paste`]),it(`onCompositionEnd`,`compositionend focusout keydown keypress keyup mousedown`.split(` `)),it(`onCompositionStart`,`compositionstart focusout keydown keypress keyup mousedown`.split(` `)),it(`onCompositionUpdate`,`compositionupdate focusout keydown keypress keyup mousedown`.split(` `));var pS=`abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),mS=new Set(`beforetoggle cancel close invalid load scroll scrollend toggle`.split(` `).concat(pS)),hS=`_reactListening`+Math.random().toString(36).slice(2),gS=!1,_S=!1,vS=!1,yS=!1,bS=!1,xS=!1,SS=!1,CS={},wS=/\r\n?/g,TS=/\u0000|\uFFFD/g,ES=`http://www.w3.org/1999/xlink`,DS=`http://www.w3.org/XML/1998/namespace`,OS=`javascript:throw new Error('React form unexpectedly submitted.')`,kS=`suppressHydrationWarning`,AS=`&`,jS=`/&`,MS=`$`,NS=`/$`,PS=`$?`,FS=`$~`,IS=`$!`,LS=`html`,RS=`body`,zS=`head`,BS=`F!`,VS=`F`,HS=`loading`,US=`style`,WS=0,GS=1,KS=2,qS=null,JS=null,YS={dialog:!0,webview:!0},XS=null,ZS=void 0,QS=typeof setTimeout==`function`?setTimeout:void 0,$S=typeof clearTimeout==`function`?clearTimeout:void 0,eC=-1,tC=typeof Promise==`function`?Promise:void 0,nC=typeof queueMicrotask==`function`?queueMicrotask:tC===void 0?QS:function(e){return tC.resolve(null).then(e).catch(Qu)},rC=null,iC=0,aC=1,oC=2,sC=3,cC=4,lC=new Map,uC=new Set,dC=I.d;I.d={f:function(){var e=dC.f(),t=pl();return e||t},r:function(e){var t=et(e);t!==null&&t.tag===5&&t.type===`form`?Ho(t):dC.r(e)},D:function(e){dC.D(e),Fd(`dns-prefetch`,e,null)},C:function(e,t){dC.C(e,t),Fd(`preconnect`,e,t)},L:function(e,t,n){dC.L(e,t,n);var r=fC;if(r&&e&&t){var i=`link[rel="preload"][as="`+vt(t)+`"]`;t===`image`&&n&&n.imageSrcSet?(i+=`[imagesrcset="`+vt(n.imageSrcSet)+`"]`,typeof n.imageSizes==`string`&&(i+=`[imagesizes="`+vt(n.imageSizes)+`"]`)):i+=`[href="`+vt(e)+`"]`;var a=i;switch(t){case`style`:a=Rd(e);break;case`script`:a=Hd(e)}lC.has(a)||(e=P({rel:`preload`,href:t===`image`&&n&&n.imageSrcSet?void 0:e,as:t},n),lC.set(a,e),r.querySelector(i)!==null||t===`style`&&r.querySelector(zd(a))||t===`script`&&r.querySelector(Ud(a))||(t=r.createElement(`link`),ju(t,`link`,e),rt(t),r.head.appendChild(t)))}},m:function(e,t){dC.m(e,t);var n=fC;if(n&&e){var r=t&&typeof t.as==`string`?t.as:`script`,i=`link[rel="modulepreload"][as="`+vt(r)+`"][href="`+vt(e)+`"]`,a=i;switch(r){case`audioworklet`:case`paintworklet`:case`serviceworker`:case`sharedworker`:case`worker`:case`script`:a=Hd(e)}if(!lC.has(a)&&(e=P({rel:`modulepreload`,href:e},t),lC.set(a,e),n.querySelector(i)===null)){switch(r){case`audioworklet`:case`paintworklet`:case`serviceworker`:case`sharedworker`:case`worker`:case`script`:if(n.querySelector(Ud(a)))return}r=n.createElement(`link`),ju(r,`link`,e),rt(r),n.head.appendChild(r)}}},X:function(e,t){dC.X(e,t);var n=fC;if(n&&e){var r=nt(n).hoistableScripts,i=Hd(e),a=r.get(i);a||(a=n.querySelector(Ud(i)),a||(e=P({src:e,async:!0},t),(t=lC.get(i))&&qd(e,t),a=n.createElement(`script`),rt(a),ju(a,`link`,e),n.head.appendChild(a)),a={type:`script`,instance:a,count:1,state:null},r.set(i,a))}},S:function(e,t,n){dC.S(e,t,n);var r=fC;if(r&&e){var i=nt(r).hoistableStyles,a=Rd(e);t||=`default`;var o=i.get(a);if(!o){var s={loading:iC,preload:null};if(o=r.querySelector(zd(a)))s.loading=aC|cC;else{e=P({rel:`stylesheet`,href:e,"data-precedence":t},n),(n=lC.get(a))&&Kd(e,n);var c=o=r.createElement(`link`);rt(c),ju(c,`link`,e),c._p=new Promise(function(e,t){c.onload=e,c.onerror=t}),c.addEventListener(`load`,function(){s.loading|=aC}),c.addEventListener(`error`,function(){s.loading|=oC}),s.loading|=cC,Gd(o,t,r)}o={type:`stylesheet`,instance:o,count:1,state:s},i.set(a,o)}}},M:function(e,t){dC.M(e,t);var n=fC;if(n&&e){var r=nt(n).hoistableScripts,i=Hd(e),a=r.get(i);a||(a=n.querySelector(Ud(i)),a||(e=P({src:e,async:!0,type:`module`},t),(t=lC.get(i))&&qd(e,t),a=n.createElement(`script`),rt(a),ju(a,`link`,e),n.head.appendChild(a)),a={type:`script`,instance:a,count:1,state:null},r.set(i,a))}}};var fC=typeof document>`u`?null:document,pC=null,mC=6e4,hC=800,gC=500,_C=0,vC=null,yC=null,bC=ep,xC={$$typeof:Uf,Provider:null,Consumer:null,_currentValue:bC,_currentValue2:bC,_threadCount:0},SC=`%c%s%c`,CC=`background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px`,wC=``,TC=` `,EC=Function.prototype.bind,DC=!1,OC=null,kC=null,AC=null,jC=null,MC=null,NC=null,PC=null,FC=null,IC=null,LC=null;OC=function(e,r,i,a){r=t(e,r),r!==null&&(i=n(r.memoizedState,i,0,a),r.memoizedState=i,r.baseState=i,e.memoizedProps=P({},e.memoizedProps),i=_r(e,2),i!==null&&cl(i,e,2))},kC=function(e,n,r){n=t(e,n),n!==null&&(r=a(n.memoizedState,r,0),n.memoizedState=r,n.baseState=r,e.memoizedProps=P({},e.memoizedProps),r=_r(e,2),r!==null&&cl(r,e,2))},AC=function(e,n,i,a){n=t(e,n),n!==null&&(i=r(n.memoizedState,i,a),n.memoizedState=i,n.baseState=i,e.memoizedProps=P({},e.memoizedProps),i=_r(e,2),i!==null&&cl(i,e,2))},jC=function(e,t,r){e.pendingProps=n(e.memoizedProps,t,0,r),e.alternate&&(e.alternate.pendingProps=e.pendingProps),t=_r(e,2),t!==null&&cl(t,e,2)},MC=function(e,t){e.pendingProps=a(e.memoizedProps,t,0),e.alternate&&(e.alternate.pendingProps=e.pendingProps),t=_r(e,2),t!==null&&cl(t,e,2)},NC=function(e,t,n){e.pendingProps=r(e.memoizedProps,t,n),e.alternate&&(e.alternate.pendingProps=e.pendingProps),t=_r(e,2),t!==null&&cl(t,e,2)},PC=function(e){var t=_r(e,2);t!==null&&cl(t,e,2)},FC=function(e){var t=ze(),n=_r(e,t);n!==null&&cl(n,e,t)},IC=function(e){s=e},LC=function(e){o=e};var RC=!0,zC=null,BC=!1,VC=null,HC=null,UC=null,WC=new Map,GC=new Map,KC=[],qC=`mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(` `),JC=null;if(jf.prototype.render=Af.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(`Cannot update an unmounted root.`);var n=arguments;typeof n[1]==`function`?console.error(`does not support the second callback argument. To execute a side effect after rendering, declare it in a component body with useEffect().`):b(n[1])?console.error(`You passed a container to the second argument of root.render(...). You don't need to pass it again since you already passed it to create the root.`):n[1]!==void 0&&console.error(`You passed a second argument to root.render(...) but it only accepts one argument.`),n=e;var r=t.current;sf(r,ol(r),n,t,null,null)},jf.prototype.unmount=Af.prototype.unmount=function(){var e=arguments;if(typeof e[0]==`function`&&console.error(`does not support a callback argument. To execute a side effect after rendering, declare it in a component body with useEffect().`),e=this._internalRoot,e!==null){this._internalRoot=null;var t=e.containerInfo;(Y&(Rb|zb))!==Lb&&console.error(`Attempted to synchronously unmount a root while React was already rendering. React cannot finish unmounting the root until the current render has completed, which may lead to a race condition.`),sf(e.current,2,null,e,null,null),pl(),t[$p]=null}},jf.prototype.unstable_scheduleHydration=function(e){if(e){var t=Xe();e={blockedOn:null,target:e,priority:t};for(var n=0;n<KC.length&&t!==0&&t<KC[n].priority;n++);KC.splice(n,0,e),n===0&&Sf(e)}},(function(){var e=Pf.version;if(e!==`19.2.4`)throw Error(`Incompatible React versions: The "react" and "react-dom" packages must have the exact same version. Instead got:
  - react:      `+(e+`
  - react-dom:  19.2.4
Learn more: https://react.dev/warnings/version-mismatch`))})(),typeof Map==`function`&&Map.prototype!=null&&typeof Map.prototype.forEach==`function`&&typeof Set==`function`&&Set.prototype!=null&&typeof Set.prototype.clear==`function`&&typeof Set.prototype.forEach==`function`||console.error(`React depends on Map and Set built-in types. Make sure that you load a polyfill in older browsers. https://react.dev/link/react-polyfills`),I.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render==`function`?Error(`Unable to find node on an unmounted component.`):(e=Object.keys(e).join(`,`),Error(`Argument appears to not be a ReactComponent. Keys: `+e));return e=ie(t),e=e===null?null:ae(e),e=e===null?null:e.stateNode,e},!(function(){var e={bundleType:1,version:`19.2.4`,rendererPackageName:`react-dom`,currentDispatcherRef:F,reconcilerVersion:`19.2.4`};return e.overrideHookState=OC,e.overrideHookStateDeletePath=kC,e.overrideHookStateRenamePath=AC,e.overrideProps=jC,e.overridePropsDeletePath=MC,e.overridePropsRenamePath=NC,e.scheduleUpdate=PC,e.scheduleRetry=FC,e.setErrorHandler=IC,e.setSuspenseHandler=LC,e.scheduleRefresh=v,e.scheduleRoot=_,e.setRefreshHandler=y,e.getCurrentFiber=ff,Ne(e)})()&&ah&&window.top===window.self&&(-1<navigator.userAgent.indexOf(`Chrome`)&&navigator.userAgent.indexOf(`Edge`)===-1||-1<navigator.userAgent.indexOf(`Firefox`))){var YC=window.location.protocol;/^(https?|file):$/.test(YC)&&console.info(`%cDownload the React DevTools for a better development experience: https://react.dev/link/react-devtools`+(YC===`file:`?`
You might need to use a local HTTP server (instead of file://): https://react.dev/link/react-devtools-faq`:``),`font-weight:bold`)}e.createRoot=function(e,t){if(!b(e))throw Error(`Target container is not a DOM element.`);Mf(e);var n=!1,r=``,i=cs,a=ls,o=us;return t!=null&&(t.hydrate?console.warn(`hydrate through createRoot is deprecated. Use ReactDOMClient.hydrateRoot(container, <App />) instead.`):typeof t==`object`&&t&&t.$$typeof===Lf&&console.error(`You passed a JSX element to createRoot. You probably meant to call root.render instead. Example usage:

  let root = createRoot(domContainer);
  root.render(<App />);`),!0===t.unstable_strictMode&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onUncaughtError!==void 0&&(i=t.onUncaughtError),t.onCaughtError!==void 0&&(a=t.onCaughtError),t.onRecoverableError!==void 0&&(o=t.onRecoverableError)),t=af(e,1,!1,null,null,n,r,null,i,a,o,kf),e[$p]=t.current,gu(e),new Af(t)},e.hydrateRoot=function(e,t,n){if(!b(e))throw Error(`Target container is not a DOM element.`);Mf(e),t===void 0&&console.error(`Must provide initial children as second argument to hydrateRoot. Example usage: hydrateRoot(domContainer, <App />)`);var r=!1,i=``,a=cs,o=ls,s=us,c=null;return n!=null&&(!0===n.unstable_strictMode&&(r=!0),n.identifierPrefix!==void 0&&(i=n.identifierPrefix),n.onUncaughtError!==void 0&&(a=n.onUncaughtError),n.onCaughtError!==void 0&&(o=n.onCaughtError),n.onRecoverableError!==void 0&&(s=n.onRecoverableError),n.formState!==void 0&&(c=n.formState)),t=af(e,1,!0,t,n??null,r,i,c,a,o,s,kf),t.context=of(null),n=t.current,r=ol(n),r=Ke(r),i=oa(r),i.callback=null,sa(n,i,r),mi(r,`hydrateRoot()`,null),n=r,t.current.lanes=n,Ve(t,n),eu(t),e[$p]=t.current,gu(e),new jf(t)},e.version=`19.2.4`,typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop==`function`&&__REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error())})()})),g=o(((e,t)=>{t.exports=h()})),_=c(u(),1),v=c(g(),1),y=`<!-- ==================================================================== -->
<!-- 1. PRIHLASOVACÍ MODAL (AUTENTIFIKAČNÁ BRÁNA)                        -->
<!-- ==================================================================== -->
<div class="modal-backdrop-overlay" id="welcomeAuthOverlay" style="display: none">
  <div class="auth-modal-card">
    <button class="modal-dismiss" id="closeAuthBtn" type="button" aria-label="Zavrieť prihlásenie">
      Zavrieť
    </button>
    <div class="auth-modal-hero">
      <div class="brand-soundwave lg">
        <span class="sw-col c1"></span>
        <span class="sw-col c2"></span>
        <span class="sw-col c3"></span>
      </div>
      <div class="brand-title-sub">glide</div>
      <span class="auth-overline">TVOJ HLAS, TVOJE TEMPO</span>
      <h1 class="auth-modal-title">Tvoj hlas má svoj priestor.</h1>
      <p class="auth-modal-desc">Ulož si pokrok. Alebo pokračuj bez účtu.</p>
    </div>

    <div class="auth-card-body">
      <!-- Google Sign-in -->
      <button class="social-login-btn google full-width" id="welcomeBtnGoogle" type="button">
        <svg class="social-btn-icon" viewBox="0 0 24 24" width="22" height="22">
          <path
            fill="#4285F4"
            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
          />
          <path
            fill="#34A853"
            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
          />
          <path
            fill="#FBBC05"
            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
          />
          <path
            fill="#EA4335"
            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
          />
        </svg>
        <span>Pokračovať cez Google účet</span>
      </button>

      <div class="auth-divider">
        <span>ALEBO REGISTRÁCIA CEZ EMAIL</span>
      </div>

      <div class="auth-form-fields" id="welcomeAuthBox">
        <div class="auth-field-group">
          <label class="auth-field-label" for="welcomeNameInput">Tvoje meno / prezývka</label>
          <input
            type="text"
            class="auth-input"
            id="welcomeNameInput"
            placeholder="napr. Alex"
            autocomplete="name"
          />
        </div>

        <div class="auth-field-group">
          <label class="auth-field-label" for="welcomeEmailInput">Emailová adresa</label>
          <input
            type="email"
            class="auth-input"
            id="welcomeEmailInput"
            placeholder="napr. tvoj.email@gmail.com"
            autocomplete="email"
          />
        </div>

        <div class="auth-field-group">
          <label class="auth-field-label" for="welcomePasswordInput">Heslo</label>
          <input
            type="password"
            class="auth-input"
            id="welcomePasswordInput"
            placeholder="Minimálne 6 znakov"
            autocomplete="current-password"
          />
        </div>

        <div class="auth-feedback-msg" id="welcomeAuthFeedback" style="display: none"></div>

        <button class="btn-primary full" id="welcomeSubmitBtn" type="button">
          <span id="welcomeSubmitText">🚀 Pokračovať</span>
        </button>
      </div>

      <button class="guest-bypass-btn" id="welcomeGuestBtn" type="button">
        <span>👤 Vyskúšať bez prihlásenia (Lokálny režim)</span>
      </button>
    </div>
  </div>
</div>

<!-- ==================================================================== -->
<!-- 2. OFICIÁLNY FIGMA VÝSKUMNÝ DOTAZNÍK (MODÁL PO PRVOM PRIHLÁSENÍ)      -->
<!-- ==================================================================== -->
<div class="modal-backdrop-overlay" id="figmaQuestionnaireModal" style="display: none">
  <div class="questionnaire-modal-card">
    <button
      class="modal-dismiss"
      id="closeQuestionnaireBtn"
      type="button"
      aria-label="Zavrieť dotazník"
    >
      Teraz nie
    </button>
    <div class="questionnaire-top">
      <div>
        <p class="eyebrow">VÝSKUMNÝ DOTAZNÍK</p>
        <h1 class="q-main-title">Tvoja skúsenosť s rečou<span>.</span></h1>
      </div>
      <span class="questionnaire-count" id="qCountText" style="display: none">1 / 4</span>
    </div>

    <div class="questionnaire-progress" id="qProgressWrap" aria-label="Priebeh dotazníka">
      <span id="qProgressBar" style="width: 0%"></span>
    </div>

    <!-- KROK 0: UVÍTACIA OBRAZOVKA S INFORMÁCIAMI A SÚHLASOM -->
    <section class="questionnaire-welcome" id="qStep0">
      <div class="research-intro">
        <span class="research-icon">
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <rect x="5" y="4" width="14" height="17" rx="2" />
            <path d="M9 4V2h6v2M9 9h6M9 13h6M9 17h4" />
          </svg>
        </span>
        <span class="section-kicker">PRED ZAČIATKOM</span>
        <h2>Nejde o test plynulosti ani o diagnózu.</h2>
        <p>
          Tento dotazník mapuje, ako zajakavosť ovplyvňuje tvoje rozprávanie, prežívanie a
          každodenný život. Vyplnenie trvá približne 4 minúty.
        </p>
      </div>

      <div class="research-points">
        <article>
          <span>
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <path d="M12 22s8-3 8-10V5l-8-3-8 3v7c0 7 8 10 8 10Z" />
            </svg>
          </span>
          <div>
            <strong>Odpovede zostávajú v tomto zariadení</strong>
            <p>
              Nikam sa neodosielajú bez tvojho vedomia. Slúžia na personalizáciu tréningu mäkkého
              nábehu.
            </p>
          </div>
        </article>
        <article>
          <span>
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <circle cx="12" cy="12" r="9" />
              <path d="M12 11v6M12 7h.01" />
            </svg>
          </span>
          <div>
            <strong>Vedecky podložené oblasti</strong>
            <p>Obsah vychádza z medzinárodných logopedických rámcov OASES-A, WASSP a ICF.</p>
          </div>
        </article>
      </div>

      <div class="research-consent">
        <label class="consent-check">
          <input type="checkbox" id="qAdultCheck" />
          <span>Mám 18 rokov alebo viac.</span>
        </label>
        <label class="consent-check">
          <input type="checkbox" id="qConsentCheck" />
          <span>Rozumiem účelu dotazníka a dobrovoľne súhlasím s vyplnením.</span>
        </label>
      </div>
    </section>

    <!-- KROK 1: SKÚSENOSŤ S ROZPRÁVANÍM -->
    <section class="questionnaire-form" id="qStep1" style="display: none">
      <header>
        <span class="section-kicker">ČASŤ 1 Z 3</span>
        <h2>Skúsenosť s rozprávaním</h2>
        <p>Ako často si za posledné dva týždne zažíval/a nasledujúce situácie?</p>
      </header>

      <div class="question-list">
        <article class="question-item">
          <p class="question-text">Mám pocit, že nemám kontrolu nad tým, kedy sa reč zasekne.</p>
          <div class="answer-scale" data-qid="speech-control">
            <label><input type="radio" name="speech-control" value="0" /><span>Nikdy</span></label>
            <label
              ><input type="radio" name="speech-control" value="1" /><span>Zriedka</span></label
            >
            <label><input type="radio" name="speech-control" value="2" /><span>Občas</span></label>
            <label><input type="radio" name="speech-control" value="3" /><span>Často</span></label>
            <label
              ><input type="radio" name="speech-control" value="4" /><span>Takmer vždy</span></label
            >
          </div>
        </article>

        <article class="question-item">
          <p class="question-text">
            Hovorenie odo mňa vyžaduje výraznú fyzickú námahu alebo napätie v hrdle.
          </p>
          <div class="answer-scale" data-qid="speech-effort">
            <label><input type="radio" name="speech-effort" value="0" /><span>Nikdy</span></label>
            <label><input type="radio" name="speech-effort" value="1" /><span>Zriedka</span></label>
            <label><input type="radio" name="speech-effort" value="2" /><span>Občas</span></label>
            <label><input type="radio" name="speech-effort" value="3" /><span>Často</span></label>
            <label
              ><input type="radio" name="speech-effort" value="4" /><span>Takmer vždy</span></label
            >
          </div>
        </article>

        <article class="question-item">
          <p class="question-text">
            Zajakavosť prichádza nečakane aj pri slovách, ktoré bežne zvládam.
          </p>
          <div class="answer-scale" data-qid="speech-unpredictable">
            <label
              ><input type="radio" name="speech-unpredictable" value="0" /><span>Nikdy</span></label
            >
            <label
              ><input type="radio" name="speech-unpredictable" value="1" /><span
                >Zriedka</span
              ></label
            >
            <label
              ><input type="radio" name="speech-unpredictable" value="2" /><span>Občas</span></label
            >
            <label
              ><input type="radio" name="speech-unpredictable" value="3" /><span>Často</span></label
            >
            <label
              ><input type="radio" name="speech-unpredictable" value="4" /><span
                >Takmer vždy</span
              ></label
            >
          </div>
        </article>
      </div>
    </section>

    <!-- KROK 2: MYŠLIENKY A POCITY -->
    <section class="questionnaire-form" id="qStep2" style="display: none">
      <header>
        <span class="section-kicker">ČASŤ 2 Z 3</span>
        <h2>Myšlienky a pocity</h2>
        <p>Neexistuje správna odpoveď. Vyber to, čo najlepšie vystihuje tvoju skúsenosť.</p>
      </header>

      <div class="question-list">
        <article class="question-item">
          <p class="question-text">Cítim obavy alebo napätie už pred tým, ako začnem rozprávať.</p>
          <div class="answer-scale" data-qid="feeling-worry">
            <label><input type="radio" name="feeling-worry" value="0" /><span>Nikdy</span></label>
            <label><input type="radio" name="feeling-worry" value="1" /><span>Zriedka</span></label>
            <label><input type="radio" name="feeling-worry" value="2" /><span>Občas</span></label>
            <label><input type="radio" name="feeling-worry" value="3" /><span>Často</span></label>
            <label
              ><input type="radio" name="feeling-worry" value="4" /><span>Takmer vždy</span></label
            >
          </div>
        </article>

        <article class="question-item">
          <p class="question-text">Mením slová, vyhýbam sa určitým hláskam alebo radšej mlčím.</p>
          <div class="answer-scale" data-qid="feeling-avoid">
            <label><input type="radio" name="feeling-avoid" value="0" /><span>Nikdy</span></label>
            <label><input type="radio" name="feeling-avoid" value="1" /><span>Zriedka</span></label>
            <label><input type="radio" name="feeling-avoid" value="2" /><span>Občas</span></label>
            <label><input type="radio" name="feeling-avoid" value="3" /><span>Často</span></label>
            <label
              ><input type="radio" name="feeling-avoid" value="4" /><span>Takmer vždy</span></label
            >
          </div>
        </article>

        <article class="question-item">
          <p class="question-text">
            Po rozhovore premýšľam nad tým, ako som znel/a a čo si mysleli ostatní.
          </p>
          <div class="answer-scale" data-qid="feeling-after">
            <label><input type="radio" name="feeling-after" value="0" /><span>Nikdy</span></label>
            <label><input type="radio" name="feeling-after" value="1" /><span>Zriedka</span></label>
            <label><input type="radio" name="feeling-after" value="2" /><span>Občas</span></label>
            <label><input type="radio" name="feeling-after" value="3" /><span>Často</span></label>
            <label
              ><input type="radio" name="feeling-after" value="4" /><span>Takmer vždy</span></label
            >
          </div>
        </article>
      </div>
    </section>

    <!-- KROK 3: ÚČASŤ V KAŽDODENNOM ŽIVOTE -->
    <section class="questionnaire-form" id="qStep3" style="display: none">
      <header>
        <span class="section-kicker">ČASŤ 3 Z 3</span>
        <h2>Účasť v každodennom živote</h2>
        <p>Zamysli sa nad prácou, školou, vzťahmi aj bežnými povinnosťami.</p>
      </header>

      <div class="question-list">
        <article class="question-item">
          <p class="question-text">
            Zajakavosť ovplyvňuje moje sebavedomie v práci, škole alebo pri prezentáciách.
          </p>
          <div class="answer-scale" data-qid="impact-work">
            <label><input type="radio" name="impact-work" value="0" /><span>Nikdy</span></label>
            <label><input type="radio" name="impact-work" value="1" /><span>Zriedka</span></label>
            <label><input type="radio" name="impact-work" value="2" /><span>Občas</span></label>
            <label><input type="radio" name="impact-work" value="3" /><span>Často</span></label>
            <label
              ><input type="radio" name="impact-work" value="4" /><span>Takmer vždy</span></label
            >
          </div>
        </article>

        <article class="question-item">
          <p class="question-text">
            Odmietam alebo obmedzujem spoločenské situácie kvôli obavám z reči.
          </p>
          <div class="answer-scale" data-qid="impact-social">
            <label><input type="radio" name="impact-social" value="0" /><span>Nikdy</span></label>
            <label><input type="radio" name="impact-social" value="1" /><span>Zriedka</span></label>
            <label><input type="radio" name="impact-social" value="2" /><span>Občas</span></label>
            <label><input type="radio" name="impact-social" value="3" /><span>Často</span></label>
            <label
              ><input type="radio" name="impact-social" value="4" /><span>Takmer vždy</span></label
            >
          </div>
        </article>

        <article class="question-item">
          <p class="question-text">
            Je pre mňa náročné vybaviť bežné veci (telefonát, objednávka, nákup).
          </p>
          <div class="answer-scale" data-qid="impact-tasks">
            <label><input type="radio" name="impact-tasks" value="0" /><span>Nikdy</span></label>
            <label><input type="radio" name="impact-tasks" value="1" /><span>Zriedka</span></label>
            <label><input type="radio" name="impact-tasks" value="2" /><span>Občas</span></label>
            <label><input type="radio" name="impact-tasks" value="3" /><span>Často</span></label>
            <label
              ><input type="radio" name="impact-tasks" value="4" /><span>Takmer vždy</span></label
            >
          </div>
        </article>
      </div>
    </section>

    <!-- KROK 4: DOPLŇUJÚCI KONTEXT -->
    <section class="questionnaire-form context-step" id="qStep4" style="display: none">
      <header>
        <span class="section-kicker">DOPLŇUJÚCI KONTEXT</span>
        <h2>Kde je rozprávanie najnáročnejšie?</h2>
        <p>Môžeš vybrať viac možností alebo tento krok preskočiť.</p>
      </header>

      <div class="situation-grid" id="qSituationGrid">
        <button type="button" class="situation-btn" data-sit="Telefonovanie">
          <span></span>Telefonovanie
        </button>
        <button type="button" class="situation-btn" data-sit="Objednávanie jedla a nákupy">
          <span></span>Objednávanie & Nákupy
        </button>
        <button type="button" class="situation-btn" data-sit="Práca, porady a prezentácie">
          <span></span>Práca & Porady
        </button>
        <button type="button" class="situation-btn" data-sit="Predstavovanie sa vlastným menom">
          <span></span>Predstavovanie sa menom
        </button>
        <button type="button" class="situation-btn" data-sit="Rozhovory s autoritami">
          <span></span>Rozhovory s autoritami
        </button>
        <button type="button" class="situation-btn" data-sit="Neznámi ľudia">
          <span></span>Neznámi ľudia
        </button>
      </div>

      <label class="questionnaire-note">
        <span>Chceš niečo doplniť? <small>nepovinné</small></span>
        <textarea
          id="qNoteInput"
          placeholder="Napíš vlastnými slovami, čo je pre teba dôležité…"
          maxlength="500"
        ></textarea>
        <small id="qNoteCount">0 / 500</small>
      </label>
    </section>

    <!-- KROK 5: VÝSLEDKY A ZHRNUTIE -->
    <section class="questionnaire-results" id="qStep5" style="display: none">
      <div class="complete-icon">
        <svg
          width="34"
          height="34"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#10b981"
          stroke-width="2.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path d="m6 12 4 4 8-9" />
        </svg>
      </div>
      <span class="section-kicker">DOTAZNÍK DOKONČENÝ</span>
      <h2>Ďakujeme za tvoju otvorenosť.</h2>
      <p>
        Toto zhrnutie opisuje tvoje odpovede, nie klinickú diagnózu. Ak si vyplnil/a aj dobrovoľný
        tréningový profil, po dokončení sa nastaví odporúčaný svet a počiatočné DAF oneskorenie.
      </p>

      <div class="result-domains">
        <article class="domain-card">
          <header>
            <span class="domain-label">Skúsenosť s rozprávaním</span>
            <span class="domain-val" id="domainRes0">stredná záťaž</span>
          </header>
          <div class="domain-bar"><span id="domainBar0" style="width: 50%"></span></div>
        </article>

        <article class="domain-card">
          <header>
            <span class="domain-label">Myšlienky a pocity</span>
            <span class="domain-val" id="domainRes1">stredná záťaž</span>
          </header>
          <div class="domain-bar"><span id="domainBar1" style="width: 50%"></span></div>
        </article>

        <article class="domain-card">
          <header>
            <span class="domain-label">Účasť v živote</span>
            <span class="domain-val" id="domainRes2">stredná záťaž</span>
          </header>
          <div class="domain-bar"><span id="domainBar2" style="width: 50%"></span></div>
        </article>
      </div>

      <div class="result-context" id="qResultContext" style="display: none; margin-top: 16px">
        <span class="context-label">Najviac náročné situácie:</span>
        <div class="context-chips" id="qResultSituationChips"></div>
      </div>

      <button
        class="btn-primary full lg"
        id="qFinishEnterBtn"
        type="button"
        style="margin-top: 24px"
      >
        <span>Vstúpiť do aplikácie a začať tréning →</span>
      </button>
    </section>

    <!-- SPODNÁ NAVIGÁCIA DOTAZNÍKA -->
    <footer class="questionnaire-actions" id="qActionsFooter">
      <button class="btn-secondary sm" id="qBackBtn" type="button" style="visibility: hidden">
        Späť
      </button>
      <button class="btn-primary sm" id="qNextBtn" type="button" disabled>
        <span id="qNextBtnText">Začať dotazník</span>
        <svg
          width="18"
          height="18"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path d="M5 12h14m-5-5 5 5-5 5" />
        </svg>
      </button>
    </footer>
  </div>
</div>

<!-- ==================================================================== -->
<!-- HLAVNÁ APLIKÁCIA (APP SHELL S DESKTOP SIDEBAROM)                    -->
<!-- ==================================================================== -->
<div class="app-shell-container">
  <!-- DESKTOP SIDEBAR (Viditeľný iba na obrazovkách > 768px, BEZ DOTAZNÍKA) -->
  <aside class="desktop-sidebar" id="desktopSidebar">
    <div class="sidebar-brand" id="sidebarBrandBtn">
      <div class="brand-soundwave">
        <span class="sw-col c1"></span>
        <span class="sw-col c2"></span>
        <span class="sw-col c3"></span>
      </div>
      <span class="sidebar-brand-name">glide</span>
    </div>

    <nav class="sidebar-nav">
      <button class="sidebar-nav-item active" data-tab="tabCesta" id="sidebarTabCesta">
        <span class="sn-icon"
          ><svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="m3 10 9-7 9 7M5 9v11h14V9M9 20v-6h6v6" /></svg
        ></span>
        <span class="sn-label">Cesta</span>
      </button>
      <button class="sidebar-nav-item" data-tab="tabDril" id="sidebarTabDril">
        <span class="sn-icon"
          ><svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="M5 4v16M19 4v16M9 8v8M15 8v8M2 12h20" /></svg
        ></span>
        <span class="sn-label">Dril</span>
      </button>
      <button class="sidebar-nav-item" data-tab="tabAsistent" id="sidebarTabAsistent">
        <span class="sn-icon"
          ><svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path
              d="M4 14v-2a8 8 0 0 1 16 0v2M4 14h4v7H6a2 2 0 0 1-2-2v-5ZM20 14h-4v7h2a2 2 0 0 0 2-2v-5Z"
            /></svg
        ></span>
        <span class="sn-label">Asistent</span>
      </button>
      <button class="sidebar-nav-item" data-tab="tabTelemetria" id="sidebarTabTelemetria">
        <span class="sn-icon"
          ><svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="M4 19V9M10 19V5M16 19v-7M22 19H2" /></svg
        ></span>
        <span class="sn-label">Telemetria</span>
      </button>
      <button class="sidebar-nav-item" id="sidebarScienceBtn">
        <span class="sn-icon"
          ><svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="M4 4h6v16H4zM14 4h6v16h-6zM7 8h1M17 8h1" /></svg
        ></span>
        <span class="sn-label">Veda & Modely</span>
      </button>
    </nav>

    <div class="sidebar-footer">
      <button class="sidebar-profile-card" id="sidebarProfileBtn" type="button">
        <div class="sidebar-avatar" id="sidebarAvatarCircle">AB</div>
        <div class="sidebar-user-info">
          <span class="sidebar-user-name" id="sidebarUserName">Môj profil</span>
          <span class="sidebar-user-status">Tvoj priestor</span>
        </div>
        <span class="sidebar-settings-icon">⚙️</span>
      </button>
    </div>
  </aside>

  <!-- HLAVNÉ TELO OBSAHU -->
  <div class="app-layout" id="appLayout">
    <!-- HORNÝ HUD (Viditeľný na mobile aj na desktope v záhlaví) -->
    <header class="duo-header" id="mainHeader">
      <div class="header-inner">
        <div class="brand-badge" id="brandLogoBtn" title="Glide Biofeedback">
          <div class="brand-soundwave">
            <span class="sw-col c1"></span>
            <span class="sw-col c2"></span>
            <span class="sw-col c3"></span>
          </div>
          <span class="brand-name">glide</span>
        </div>

        <div class="hud-metrics">
          <!-- Streak -->
          <div class="hud-pill fire" id="hudStreakPill" title="Denná séria tréningu">
            <span class="hud-icon">🔥</span>
            <span class="hud-val" id="streakVal">1</span>
          </div>

          <!-- XP -->
          <div class="hud-pill xp" id="hudXpPill" title="Celkové body XP">
            <span class="hud-icon">⚡</span>
            <span class="hud-val" id="xpVal">0</span>
          </div>

          <!-- Srdiečka / Životy -->
          <div class="hud-pill hearts" id="hudHeartsPill" title="Životy na lekciu">
            <span class="hud-icon">❤️</span>
            <span class="hud-val" id="heartsVal">5</span>
          </div>

          <!-- Rank Odznak -->
          <div class="rank-badge" id="hudRankBadge" title="Tvoja aktuálna úroveň plynulosti">
            <span class="rank-icon">👑</span>
            <span class="rank-title-short" id="rankTitle">Začiatočník</span>
          </div>

          <!-- Profil Tlačidlo -->
          <button
            class="header-profile-btn"
            id="headerProfileBtn"
            type="button"
            title="Používateľský profil & Cloud synchronizácia"
          >
            <div class="header-avatar-circle" id="headerAvatarCircle">AB</div>
            <span class="profile-name-short" id="headerProfileName">Profil</span>
          </button>
        </div>
      </div>
    </header>

    <!-- HLAVNÝ OBSAH (4 ZÁLOŽKY) -->
    <main class="main-content-viewport">
      <!-- ---------------------------------------------------------------- -->
      <!-- ZÁLOŽKA 1: 🗺️ CESTA (KAMPAŇ / HLAVNÁ HRA)                        -->
      <!-- ---------------------------------------------------------------- -->
      <section class="tab-pane active" id="tabCesta">
        <p class="training-disclaimer">Pomôcka na cvičenie. Nenahrádza logopéda.</p>

        <!-- HERO KARTA (Figma Vela: YOUR DAILY SPACE) -->
        <div class="daily-space-hero">
          <span class="hero-overline">TU MÔŽEŠ BYŤ SÁM SEBOU</span>
          <h1 class="hero-greeting" id="dailyGreetingHeading">Dobré ráno, Alex.</h1>
          <p class="hero-subline">Nadýchni sa. Tu sa nemusíš ponáhľať.</p>
        </div>

        <!-- KARTA DNEŠNÉHO ZAMERANIA (Figma Vela: TODAY'S FOCUS) -->
        <div class="todays-focus-card">
          <div class="focus-card-left">
            <div class="focus-eyebrow">✦ DNEŠNÉ ZAMERANIE</div>
            <h2 class="focus-title">Chvíľa pre tvoj hlas.</h2>
            <p class="focus-description" id="dailyQuestText">Nadýchni sa. Začneme jedným slovom.</p>
            <button class="focus-cta-btn" id="continuePathBtn" type="button">
              <span>Spustiť tréning</span>
              <span class="cta-arrow">→</span>
            </button>
          </div>
          <div class="focus-card-visual">
            <div class="breathing-capsule-widget">
              <div class="breathing-ring-pulse"></div>
              <div class="breathing-circle-core">
                <span class="bc-label" id="stageBreathLabel">Nádych</span>
                <span class="bc-num" id="stageBreathNum">4</span>
                <span class="bc-unit">sekundy</span>
                <span id="wbBreathLabel" style="display: none"></span>
                <span id="wbBreathNum" style="display: none"></span>
              </div>
            </div>
          </div>
        </div>

        <!-- SEKCIA REČOVÉHO PLÁNU (5 SVETOV) -->
        <div class="curriculum-section-header">
          <div class="curriculum-badge">TVOJ REČOVÝ PLÁN</div>
          <h3 class="curriculum-title">Tvoja cesta, krok za krokom</h3>
        </div>

        <!-- 5 Svetov s lineárnym stromom úrovní (GAMIFIKÁCIA) -->
        <div class="worlds-wrapper" id="worldsWrapper">
          <!-- Dynamicky vygenerované z gamification-engine.js -->
        </div>

        <div class="tab-bottom-spacer"></div>
      </section>

      <section class="tab-pane" id="tabDril">
        <div class="sandbox-container">
          <!-- Hero karta SOS Drilu -->
          <div class="sandbox-hero-card">
            <div class="sandbox-badge">⚡ SOS SANDBOX</div>
            <h2 class="sandbox-title">Čo chceš dnes povedať?</h2>
            <p class="sandbox-sub">Meno, telefonát či objednávka. Nacvič si to po svojom.</p>
          </div>

          <!-- Vstup na vlastné slovo / meno -->
          <div class="sandbox-input-card">
            <label class="sandbox-label" for="wordInput">Slovo alebo veta</label>
            <div class="sandbox-input-wrap">
              <input
                type="text"
                id="wordInput"
                class="custom-word-input"
                value="Peter Novák"
                placeholder="Zadaj slovo, meno alebo celú vetu..."
              />
              <button class="btn-3d blue sm" id="clearWordBtn" title="Vyčistiť text">✕</button>
            </div>

            <!-- Rýchle SOS čipy -->
            <div class="sos-chips-label">Skús napríklad</div>
            <div class="preset-chips">
              <span class="chip" data-word="Peter Novák">Peter Novák</span>
              <span class="chip" data-word="Kartou, prosím">Kartou, prosím</span>
              <span class="chip" data-word="Dobrý deň, pri telefóne">Dobrý deň, pri telefóne</span>
              <span class="chip" data-word="Káva s mliekom">Káva s mliekom</span>
              <span class="chip" data-word="Chlieb">Chlieb (CH)</span>
              <span class="chip" data-word="Štvrtok o tretej">Štvrtok o tretej</span>
              <span class="chip" data-word="Isto, ďakujem">Isto, ďakujem</span>
            </div>
          </div>

          <!-- Voľba režimu drilu -->
          <div class="sandbox-mode-card">
            <div class="sandbox-label">Ako chceš cvičiť?</div>
            <div class="mode-select-grid">
              <label class="mode-card-radio">
                <input type="radio" name="sandboxMode" value="standard" checked />
                <div class="mode-card-inner">
                  <span class="mode-card-icon">🧘</span>
                  <span class="mode-card-title">Vlastným tempom</span>
                  <span class="mode-card-desc">Nadýchni sa a začni jemne.</span>
                </div>
              </label>

              <label class="mode-card-radio">
                <input type="radio" name="sandboxMode" value="guillotine" />
                <div class="mode-card-inner">
                  <span class="mode-card-icon">⚡</span>
                  <span class="mode-card-title">Časový tlak</span>
                  <span class="mode-card-desc">Krátka odpoveď na otázku.</span>
                </div>
              </label>
            </div>
          </div>

          <!-- Veľké tlačidlo na spustenie drilu -->
          <div class="sandbox-action-wrap">
            <button class="btn-3d green full lg" id="launchSosDrillBtn">
              <span>Začať · 3 pokusy</span>
            </button>
          </div>

          <!-- ============================================================== -->
          <!-- TREZOR OBÁVANÝCH SLOV (FEARED WORDS VAULT)                     -->
          <!-- ============================================================== -->
          <div class="telemetry-card feared-words-card" id="fearedWordsCard">
            <div class="card-header-row">
              <div>
                <div class="card-subtitle orange">DESENZIBILIZAČNÝ MODUL</div>
                <h3 class="card-title">Tvoje slová</h3>
              </div>
              <span class="vault-status-badge" id="vaultMasteryBadge">0 / 0 Odblokované 🏆</span>
            </div>

            <p class="vault-lead">Pridaj si slová, ktoré chceš zvládnuť s väčšou ľahkosťou.</p>

            <!-- Pridanie nového slova do trezoru -->
            <div class="vault-add-form">
              <div class="vault-input-row">
                <input
                  type="text"
                  id="vaultWordInput"
                  class="vault-input"
                  placeholder="Nové obávané slovo, meno alebo objednávka..."
                />
                <select id="vaultCategorySelect" class="vault-select" title="Kategória slova">
                  <option value="Meno">👤 Meno</option>
                  <option value="Kaviareň">☕ Kaviareň</option>
                  <option value="Cestovanie">📍 Mesto</option>
                  <option value="Číslo">🔢 Číslo</option>
                  <option value="Práca">💼 Práca</option>
                  <option value="Iné">⚡ Iné</option>
                </select>
                <button class="btn-3d amber sm" id="vaultAddBtn">
                  <span>+ Pridať</span>
                </button>
              </div>
            </div>

            <!-- Filtre a akcie trezoru -->
            <div class="vault-toolbar">
              <button
                class="btn-3d purple sm"
                id="vaultRandomChallengeBtn"
                title="Vyberie náhodné obávané slovo a spustí dril"
              >
                <span>🎲 Náhodná výzva</span>
              </button>
              <div class="vault-filter-pills" id="vaultFilterPills">
                <button class="vault-pill active" data-filter="all" id="vFilterAll">
                  Všetky (<span id="vCountAll">0</span>)
                </button>
                <button class="vault-pill" data-filter="unmastered" id="vFilterTraining">
                  V tréningu (<span id="vCountTraining">0</span>)
                </button>
                <button class="vault-pill" data-filter="mastered" id="vFilterMastered">
                  🏆 (<span id="vCountMastered">0</span>)
                </button>
              </div>
            </div>

            <!-- Zoznam kariet slov v trezore -->
            <div class="vault-list" id="vaultList">
              <!-- Dynamicky generované z gamification-engine.js -->
            </div>
          </div>

          <div class="tab-bottom-spacer"></div>
        </div>
      </section>

      <!-- ------------------------------------------------------------------ -->
      <!-- ZÁLOŽKA 3: 🎧 ASISTENT (ŽIVÝ DAF ODPOSLUCH V REÁLNOM ČASE)         -->
      <!-- ------------------------------------------------------------------ -->
      <section class="tab-pane" id="tabAsistent">
        <div class="assistant-container">
          <!-- Hero karta Asistenta -->
          <div class="assistant-hero-card">
            <div class="assistant-badge">🎧 ŽIVÝ REČOVÝ ASISTENT</div>
            <h2 class="assistant-title">Počuj sa trochu inak.</h2>
            <p class="assistant-sub">Nastav si odposluch tak, aby ti bol príjemný.</p>

            <div class="assistant-headphone-alert">
              <span class="alert-icon">🎧</span>
              <span class="alert-text">Najprv si pripoj slúchadlá.</span>
            </div>
          </div>

          <!-- Vizuálny feedback (pulzujúci indikátor v reálnom čase) -->
          <div class="assistant-visual-card">
            <div class="pulse-wrapper">
              <div class="assistant-pulse-circle" id="assistantPulseIndicator">
                <div class="pulse-ring pulse-ring-1"></div>
                <div class="pulse-ring pulse-ring-2"></div>
                <div class="pulse-inner-core">
                  <span class="pulse-icon" id="assistantPulseIcon">🎧</span>
                </div>
              </div>
              <div class="pulse-status-text" id="assistantPulseStatus">Asistent je pripravený</div>
            </div>
          </div>

          <!-- Dominantný Master Switch -->
          <div class="assistant-toggle-card">
            <button class="btn-3d green full lg assistant-main-btn" id="assistantToggle">
              <span class="btn-main-label">▶ Aktivovať asistenta</span>
            </button>
          </div>

          <!-- Iba dva intuitívne ovládacie prvky -->
          <div class="assistant-controls-card">
            <!-- 1. Rýchlosť odozvy (Delay) -->
            <div class="control-row-group">
              <div class="control-label-row">
                <div class="control-title-wrap">
                  <span class="control-icon">⏱️</span>
                  <span class="control-name">Rýchlosť odozvy (Delay):</span>
                </div>
                <span class="control-val-badge" id="assistantDelayVal">70 ms</span>
              </div>

              <div class="slider-track-container">
                <div class="slider-wrap">
                  <input
                    type="range"
                    class="assistant-slider"
                    id="assistantDelaySlider"
                    min="40"
                    max="140"
                    step="5"
                    value="70"
                  />
                  <input type="hidden" id="dafDelaySlider" value="70" />
                </div>

                <!-- Presná matematicky zarovnaná stupnica (40..140 ms, 70 ms leží na presne 30%) -->
                <div class="slider-ruler" id="delayRuler">
                  <div class="ruler-mark" style="left: 0%" data-val="40">
                    <div class="ruler-tick"></div>
                    <span class="ruler-label">40 ms</span>
                  </div>
                  <div class="ruler-mark sweet active" style="left: 30%" data-val="70">
                    <div class="ruler-tick sweet"></div>
                    <span class="ruler-label sweet">70 ms</span>
                  </div>
                  <div class="ruler-mark" style="left: 60%" data-val="100">
                    <div class="ruler-tick"></div>
                    <span class="ruler-label">100 ms</span>
                  </div>
                  <div class="ruler-mark" style="left: 100%" data-val="140">
                    <div class="ruler-tick"></div>
                    <span class="ruler-label">140 ms</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- 2. Hlasitosť v uchu (Volume) -->
            <div class="control-row-group">
              <div class="control-label-row">
                <div class="control-title-wrap">
                  <span class="control-icon">🔊</span>
                  <span class="control-name">Hlasitosť</span>
                </div>
                <span class="control-val-badge" id="assistantVolVal">35 %</span>
              </div>

              <div class="slider-track-container">
                <div class="slider-wrap">
                  <input
                    type="range"
                    class="assistant-slider"
                    id="assistantVolSlider"
                    min="0"
                    max="100"
                    step="1"
                    value="35"
                  />
                </div>

                <!-- Presná matematicky zarovnaná stupnica (0..100%, 85% leží na presne 85%) -->
                <div class="slider-ruler" id="volRuler">
                  <div class="ruler-mark" style="left: 0%" data-val="0">
                    <div class="ruler-tick"></div>
                    <span class="ruler-label">0 % (Ticho)</span>
                  </div>
                  <div class="ruler-mark" style="left: 50%" data-val="50">
                    <div class="ruler-tick"></div>
                    <span class="ruler-label">50 %</span>
                  </div>
                  <div class="ruler-mark sweet active" style="left: 35%" data-val="35">
                    <div class="ruler-tick sweet"></div>
                    <span class="ruler-label sweet">Začni potichu</span>
                  </div>
                  <div class="ruler-mark" style="left: 100%" data-val="100">
                    <div class="ruler-tick"></div>
                    <span class="ruler-label">100 %</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- 3. FAF Zmena výšky hlasu (Pitch Shift) -->
            <div class="control-row-group">
              <div class="control-label-row">
                <div class="control-title-wrap">
                  <span class="control-icon">🎵</span>
                  <span class="control-name">Výška hlasu · FAF</span>
                </div>
                <span class="control-val-badge" id="assistantPitchVal">+2 st</span>
              </div>

              <div class="slider-track-container">
                <div class="slider-wrap">
                  <input
                    type="range"
                    class="assistant-slider"
                    id="assistantPitchSlider"
                    min="-4"
                    max="4"
                    step="1"
                    value="2"
                  />
                </div>

                <div class="slider-ruler" id="pitchRuler">
                  <div class="ruler-mark" style="left: 0%" data-val="-4">
                    <div class="ruler-tick"></div>
                    <span class="ruler-label">-4 st</span>
                  </div>
                  <div class="ruler-mark" style="left: 50%" data-val="0">
                    <div class="ruler-tick"></div>
                    <span class="ruler-label">0 st</span>
                  </div>
                  <div class="ruler-mark sweet active" style="left: 75%" data-val="2">
                    <div class="ruler-tick sweet"></div>
                    <span class="ruler-label sweet">+2 st</span>
                  </div>
                  <div class="ruler-mark" style="left: 100%" data-val="4">
                    <div class="ruler-tick"></div>
                    <span class="ruler-label">+4 st</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Integrovaná automatická modulácia tónu -->
            <div class="assistant-feature-badge">
              <span class="afb-icon">✨</span>
              <span class="afb-text"
                >DAF pridá oneskorenie. FAF upraví výšku hlasu. Vyber si, čo je ti príjemné.</span
              >
            </div>
          </div>

          <div class="tab-bottom-spacer"></div>
        </div>
      </section>

      <!-- ------------------------------------------------------------------ -->
      <!-- ZÁLOŽKA 4: 📊 TELEMETRIA (PROFIL & ŠTATISTIKY)                      -->
      <!-- ------------------------------------------------------------------ -->
      <section class="tab-pane" id="tabTelemetria">
        <div class="telemetry-container">
          <header class="telemetry-intro">
            <span class="section-kicker">TVOJ POKROK</span>
            <h1>Každý krok sa počíta.</h1>
            <p>Pozri sa, čo už máš za sebou.</p>
          </header>
          <!-- Hero profil hráča -->
          <div class="telemetry-hero-card">
            <div class="profile-hero-top">
              <div class="profile-avatar-circle">🎙️</div>
              <div class="profile-info-block">
                <strong class="telemetry-display-name" id="telemetryDisplayName"
                  >Tvoj profil</strong
                >
                <div class="profile-rank-tag" id="telemetryRankTitle">Rank 1: Resonator</div>
              </div>
            </div>

            <div class="profile-hero-stats">
              <div class="ph-stat">
                <span class="ph-label">XP BODY</span>
                <span class="ph-val gold" id="telemetryXpVal">0</span>
              </div>
              <div class="ph-stat">
                <span class="ph-label">DENNÁ SÉRIA</span>
                <span class="ph-val orange" id="telemetryStreakVal">1 deň 🔥</span>
              </div>
              <div class="ph-stat">
                <span class="ph-label">SVETY</span>
                <span class="ph-val green" id="telemetryWorldsVal">1 / 5</span>
              </div>
            </div>
          </div>

          <!-- Klinický telemetrický panel VRT -->
          <div class="telemetry-card">
            <div class="card-header-row">
              <div>
                <div class="card-subtitle">TVOJ HLAS</div>
                <h3 class="card-title">Nábeh hlasu</h3>
              </div>
              <span class="vrt-badge-status" id="vrtStatusBadge">Orientačné meranie</span>
            </div>

            <div class="vrt-gauge-box">
              <div class="vrt-big-number">
                <span id="avgVrtVal">74.2</span>
                <span class="vrt-unit">ms</span>
              </div>
              <div class="vrt-scale-bar">
                <div class="vrt-zone hard" title="Tvrdý glotálny úder (< 45 ms)">
                  Tvrdý (< 45 ms)
                </div>
                <div class="vrt-zone sweet active" title="Klinický sweet-spot (60–140 ms)">
                  Mäkký nábeh (60–140 ms)
                </div>
                <div class="vrt-zone breathy" title="Dychový únik (> 240 ms)">Únik (> 240 ms)</div>
              </div>
            </div>
          </div>

          <!-- Vedecký základ & Klinické modely (Entry Karta) -->
          <div class="telemetry-card science-entry-card" id="scienceEntryCard">
            <div class="card-header-row">
              <div>
                <div class="card-subtitle cyan">EVIDENCE-BASED VÝSKUM & NEUROAKUSTIKA</div>
                <h3 class="card-title">Ako to funguje</h3>
              </div>
              <span class="science-tag-pill">5 Pilierov</span>
            </div>

            <p class="science-card-lead">
              Glide nie je len gamifikovaný trenažér – je to klinický systém postavený na 5
              recenzovaných neurobiologických pilieroch (DIVA/GODIVA, VRT akustika, DAF Choral
              Speech, Valsalva dekompresia a hierarchická stresová inokulácia).
            </p>

            <div class="science-mini-pillars">
              <span class="s-pillar-chip">🧠 1. DIVA / GODIVA</span>
              <span class="s-pillar-chip">📈 2. Akustika VRT</span>
              <span class="s-pillar-chip">🎧 3. DAF Modulácia</span>
              <span class="s-pillar-chip">🫁 4. Valsalva Reflex</span>
              <span class="s-pillar-chip">⚡ 5. Stresová Inokulácia</span>
            </div>

            <div class="science-card-action">
              <button class="btn-3d cyan full" id="openScienceModalBtn">
                <span>🔬 OTVORIŤ VEDECKÉ CITÁCIE & MODELY</span>
              </button>
            </div>
          </div>

          <!-- Štatistický prehľad pokusov -->
          <div class="telemetry-card">
            <div class="card-subtitle">CELKOVÝ PREHĽAD REČI</div>
            <h3 class="card-title">Tvoje malé kroky</h3>

            <div class="telemetry-stats-grid">
              <div class="tstat-box">
                <span class="tstat-num" id="tStatTotalAttempts">0</span>
                <span class="tstat-name">Celkovo pokusov</span>
              </div>
              <div class="tstat-box">
                <span class="tstat-num green" id="tStatSuccessRate">100%</span>
                <span class="tstat-name">Úspešné pokusy</span>
              </div>
              <div class="tstat-box">
                <span class="tstat-num gold" id="tStatCompletedLessons">0 / 25</span>
                <span class="tstat-name">Dokončené lekcie</span>
              </div>
              <div class="tstat-box">
                <span class="tstat-num blue" id="tStatAvgLatency">410 ms</span>
                <span class="tstat-name">Priemerná reakcia</span>
              </div>
              <div class="tstat-box">
                <span class="tstat-num orange" id="tStatVaultMastered">0 / 3 🏆</span>
                <span class="tstat-name">Odblokované v trezore</span>
              </div>
              <div class="tstat-box">
                <span class="tstat-num purple" id="tStatDafMode">Auto ✨</span>
                <span class="tstat-name">Zborový asistent</span>
              </div>
            </div>
          </div>

          <!-- Tvoj profil & Cloud Synchronizácia -->

          <!-- Osobný Rečový Neuro-profil (Balbutologická diagnostika) -->
          <div class="telemetry-card" id="telemetryDiagnosticCard">
            <div class="card-subtitle-row">
              <span class="card-subtitle cyan">VEDECKÝ NEURO-PROFIL REČI</span>
              <span class="science-tag-pill" id="diagProfileStatusPill">Personalizované</span>
            </div>
            <h3 class="card-title">Čo ti vyhovuje</h3>

            <div class="diag-summary-cards" style="margin-bottom: 14px">
              <div class="dsc-item">
                <span class="dsc-label">PRIMÁRNY BLOK & TENZIA</span>
                <div class="dsc-val" id="telemetryDiagTension">
                  Glotálno-laryngeálny kŕč (Hlasivky)
                </div>
              </div>
              <div class="dsc-item">
                <span class="dsc-label">ODPORÚČANÝ ŠTARTOVACÍ SVET</span>
                <div class="dsc-val highlight" id="telemetryDiagWorld">
                  Svet 1: Samohlásky & Easy Onset
                </div>
              </div>
              <div class="dsc-item">
                <span class="dsc-label">STRESOVÁ SOCIÁLNA SITUÁCIA</span>
                <div class="dsc-val" id="telemetryDiagSituation">
                  Telefonovanie & Nečakané hovory
                </div>
              </div>
              <div class="dsc-item">
                <span class="dsc-label">ODPORÚČANÁ STRATÉGIA</span>
                <div class="dsc-val" id="telemetryDiagGoal">Jemný mäkký nábeh + DAF spomalenie</div>
              </div>
            </div>

            <button class="btn-3d slate full sm" id="reopenDiagnosticBtn" type="button">
              <span>Upraviť tréningový profil</span>
            </button>
          </div>

          <!-- História posledných pokusov -->

          <!-- Správa systému -->

          <div class="tab-bottom-spacer"></div>
        </div>
      </section>
    </main>

    <!-- ==================================================================== -->
    <!-- M3 COMPACT BIOFEEDBACK BAR (Zrkadlenie z Figma Material 3 Dizajnu)   -->
    <!-- ==================================================================== -->
    <div class="m3-compact-player" id="m3CompactPlayer">
      <div class="m3-progress-indicator">
        <div class="m3-progress-track" id="m3PlayerProgress"></div>
      </div>
      <div class="m3-player-inner">
        <div class="m3-player-avatar" id="m3PlayerAvatar">🎙️</div>
        <div class="m3-player-text">
          <div class="m3-player-title" id="m3PlayerTitle">Tvoja ďalšia chvíľa</div>
          <div class="m3-player-sub" id="m3PlayerSub">Stačí chvíľa pre teba.</div>
        </div>
        <div class="m3-player-actions">
          <button
            class="m3-btn-icon play"
            id="m3PlayerActionBtn"
            type="button"
            title="Spustiť tréning"
          >
            <span id="m3PlayerActionIcon">▶</span>
          </button>
        </div>
      </div>
    </div>

    <!-- ==================================================================== -->
    <!-- SPODNÁ NAVIGAČNÁ LIŠTA (Presne 3 záložky, skryje sa v lekcii)        -->
    <!-- ==================================================================== -->
    <nav class="bottom-nav" id="bottomNav">
      <button class="nav-tab active" data-tab="tabCesta" id="navTabCesta">
        <span class="nav-icon"
          ><svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="m3 10 9-7 9 7M5 9v11h14V9M9 20v-6h6v6" /></svg
        ></span>
        <span class="nav-label">Cesta</span>
      </button>
      <button class="nav-tab" data-tab="tabDril" id="navTabDril">
        <span class="nav-icon"
          ><svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="M5 4v16M19 4v16M9 8v8M15 8v8M2 12h20" /></svg
        ></span>
        <span class="nav-label">Rýchly Dril</span>
      </button>
      <button class="nav-tab" data-tab="tabAsistent" id="navTabAsistent">
        <span class="nav-icon"
          ><svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path
              d="M4 14v-2a8 8 0 0 1 16 0v2M4 14h4v7H6a2 2 0 0 1-2-2v-5ZM20 14h-4v7h2a2 2 0 0 0 2-2v-5Z"
            /></svg
        ></span>
        <span class="nav-label">Asistent</span>
      </button>
      <button class="nav-tab" data-tab="tabTelemetria" id="navTabTelemetria">
        <span class="nav-icon"
          ><svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="M4 19V9M10 19V5M16 19v-7M22 19H2" /></svg
        ></span>
        <span class="nav-label">Telemetria</span>
      </button>
    </nav>

    <!-- ==================================================================== -->
    <!-- POPUP OKNO PRE LEVEL (POPOVER CARD NA MAPE)                          -->
    <!-- ==================================================================== -->
    <div class="node-popover-backdrop" id="nodePopoverBackdrop">
      <div class="node-popover-card" id="nodePopover">
        <button class="popover-close" id="popoverCloseBtn">✕</button>
        <div class="popover-world-tag" id="popoverWorldTag">SVET 1 • SAMOHLÁSKY</div>
        <h3 class="popover-title" id="popoverTitle">Lekcia 1.1: Úvod do A a O</h3>
        <p class="popover-desc" id="popoverDesc">
          Tréning mäkkého nábehu hlasiviek (VRT 45–160 ms). Žiadny tvrdý glotálny úder v hrtane.
        </p>

        <div class="popover-meta">
          <span class="popover-xp">⚡ +30 XP</span>
          <span class="popover-count" id="popoverWordCount">4 cvičenia</span>
        </div>

        <button class="btn-3d green full" id="startLessonBtn">
          <span>SPUSTIŤ TRÉNING</span>
        </button>
      </div>
    </div>

    <!-- ==================================================================== -->
    <!-- STAV 2: AKTÍVNA LEKCIA / POKUS (CELOOBRAZOVKOVÝ FULL-SCREEN REŽIM)   -->
    <!-- ==================================================================== -->
    <section class="lesson-screen" id="lessonScreen">
      <!-- Horná lišta lekcie -->
      <div class="lesson-topbar">
        <button class="lesson-exit-btn" id="exitLessonBtn" title="Opustiť lekciu">✕</button>

        <div class="lesson-progress-track">
          <div class="lesson-progress-fill" id="lessonProgressFill" style="width: 0%"></div>
        </div>

        <div class="lesson-hearts" id="lessonHearts">
          <span>❤️</span>
          <span id="lessonHeartsVal">5</span>
        </div>
      </div>

      <!-- Minimalistické tréningové javisko počas reči -->
      <div class="lesson-stage">
        <!-- Video zrkadlo kamery (pre Boss fighty a očný kontakt) -->
        <video id="cameraFeed" autoplay playsinline muted></video>
        <div class="eye-contact-prompt" id="interlocutorPrompt">
          👀 Udrž očný kontakt s kamerou!
        </div>

        <!-- Interaktívna bublina otázky oponenta počas dialógu / hovoru -->
        <div class="lesson-dialogue-card" id="lessonDialogueCard" style="display: none">
          <div class="ld-speaker-badge">
            <span class="ld-avatar" id="ldAvatar">👩‍💼</span>
            <span class="ld-name" id="ldSpeaker">Pokladníčka Zuzana</span>
            <span class="ld-speaking-icon" id="ldSpeakingIcon">🔊</span>
          </div>
          <div class="ld-bubble">
            <span class="ld-quote">“</span>
            <span class="ld-text" id="ldText"
              >Dobrý deň, budete platiť v hotovosti alebo kartou?</span
            >
          </div>
        </div>

        <!-- Kontext lekcie -->
        <div class="lesson-context-badge" id="lessonContextBadge">Svet 1 • Cvičenie 1 z 4</div>

        <!-- Živý indikátor slúchadiel DAF + FAF -->
        <div
          id="headphoneLiveIndicator"
          class="headphone-live-badge off"
          title="Klikni pre zapnutie alebo vypnutie zvuku v slúchadlách"
        >
          <span class="hlb-icon">🎧</span>
          <span class="hlb-text" id="headphoneStatusText"
            >DAF & FAF Slúchadlá: Vypnuté (Klikni pre zapnutie)</span
          >
          <span id="micStatus" class="hud-sub-label" style="display: none"
            >Mikrofón pripravený</span
          >
          <span class="hlb-dot"></span>
        </div>

        <!-- Veľký dominantný terč slova -->
        <div class="target-word-container">
          <h1 class="target-word" id="targetWord">AUTO</h1>
          <div class="target-meta" id="targetMeta">
            Klasifikácia: Samohláska (A) – cieľ VRT 45–160 ms
          </div>
        </div>

        <!-- Zen Dýchací Kruh (Pacer) -->
        <div class="pacer-wrapper">
          <div
            class="pacer-circle"
            id="pacerCircle"
            title="Klikni sem pre okamžité predčasné vyhodnotenie!"
          >
            <span class="pacer-text" id="pacerText">Priprav sa</span>
          </div>
        </div>

        <!-- Stavové hlásenie pod kruhom -->
        <div class="status-alert" id="statusAlert">
          Stlač tlačidlo Štart pre začiatok dychového cyklu.
        </div>

        <!-- Ovládacie tlačidlá lekcie -->
        <div class="lesson-controls" id="lessonControls">
          <button id="calibrateBtn" class="btn-3d amber sm">1. Kalibrovať ticho</button>
          <button id="startBtn" class="btn-3d green md">▶ Spustiť slovo (Pacer)</button>
        </div>

        <!-- Prepínače stresorov -->
        <div class="lesson-toggles">
          <label class="toggle-pill" title="Zapne webkameru do pozadia pre nácvik očného kontaktu">
            <input type="checkbox" id="camToggle" />
            <span>📷 Očný kontakt</span>
          </label>
          <label class="toggle-pill" title="Použiť reálne MP3 hlasy zo štúdia (/audio)">
            <input type="checkbox" id="voicePromptToggle" checked />
            <span>🔊 Reálny hlas (/audio)</span>
          </label>
          <button
            id="cardioBtn"
            class="btn-3d purple sm"
            style="padding: 6px 12px; font-size: 0.78rem"
          >
            ⚡ Tepový šok (30s)
          </button>
        </div>

        <!-- Kompatibilita pre dsp-core.js -->
        <div style="display: none">
          <div id="xpNextLabel"></div>
          <div id="xpFillBar"></div>
          <span id="comboVal">1x</span>
        </div>
      </div>

      <!-- Prepadový hovor Overlay (pre Boss Fighty) -->
      <div class="call-overlay" id="callOverlay">
        <div class="call-box">
          <div class="caller-avatar-circle">📞</div>
          <h2 class="caller-name" id="callerName">Kuriér (Balík)</h2>
          <p class="caller-sub" id="callerSub">
            Prichádzajúci hovor... Vypočuj si otázku a odpovedz bez bloku!
          </p>

          <div class="call-actions">
            <button class="btn-3d red" id="declineCallBtn">Zrušiť</button>
            <button class="btn-3d green" id="answerCallBtn">Prijať hovor</button>
          </div>
        </div>
      </div>

      <!-- Spodný Feedback Drawer (Duolingo Sheet po pokuse) -->
      <div class="feedback-drawer" id="feedbackDrawer">
        <div class="drawer-inner">
          <div class="drawer-header">
            <div class="drawer-status-icon" id="drawerStatusIcon">✓</div>
            <div class="drawer-text-wrap">
              <h3 class="drawer-headline" id="drawerHeadline">Úžasné! Dokonalý nábeh!</h3>
              <p class="drawer-subtext" id="drawerSubtext">
                Hlasivky naskočili mäkko a bez kŕča v sweet-spote.
              </p>
            </div>
            <div class="drawer-xp-badge" id="drawerXpBadge">+30 XP</div>
          </div>

          <!-- Akustická miniatúra a toggle tlačidlo -->
          <div class="drawer-details-toggle">
            <button class="toggle-matrix-btn" id="toggleMatrixBtn">
              <span>Zobraziť akustickú analýzu (VRT & graf)</span>
              <span class="chevron">▼</span>
            </button>
          </div>

          <!-- Matica akustických pravidiel pre dsp-core.js -->
          <div class="matrix-panel" id="matrixPanel">
            <div class="badge-banner" id="verdictBanner"></div>

            <div class="canvas-wrap">
              <div class="canvas-label">
                <span>Akustická obálka formantov (FFT 2048)</span>
                <span>Žlté pásmo = VRT (20% → 80% RMS)</span>
              </div>
              <canvas id="envelopeCanvas" width="600" height="90"></canvas>
              <canvas id="rmsCanvas" style="display: none" width="600" height="90"></canvas>
            </div>

            <div class="metrics-grid">
              <div class="metric-row">
                <span class="metric-title" id="m1Title">1. Reakčný čas (Štart)</span>
                <span class="metric-val" id="m1">-</span>
              </div>
              <div class="metric-row">
                <span class="metric-title">2. Čistota štartu (Anticheat)</span>
                <span class="metric-val" id="m2">-</span>
              </div>
              <div class="metric-row">
                <span class="metric-title">3. Trvanie spoluhlásky / Diera</span>
                <span class="metric-val" id="m3">-</span>
              </div>
              <div class="metric-row">
                <span class="metric-title">4. Nábeh hlasu</span>
                <span class="metric-val" id="m4"><span id="vrtValue">-</span></span>
              </div>
              <div class="metric-row">
                <span class="metric-title">5. Kontinuita slabiky</span>
                <span class="metric-val" id="m5">-</span>
              </div>
            </div>
          </div>

          <!-- Tlačidlo Pokračovať -->
          <div class="drawer-action-row">
            <button class="btn-3d full" id="drawerContinueBtn">
              <span>POKRAČOVAŤ (Enter)</span>
            </button>
          </div>
        </div>
      </div>
    </section>

    <!-- ==================================================================== -->
    <!-- KALIBRAČNÝ MODAL (MERANIE ŠUMU MIESTNOSTI)                           -->
    <!-- ==================================================================== -->
    <div class="modal-backdrop-overlay" id="calibrationModal" style="display: none">
      <div class="auth-modal-card" style="text-align: center; max-width: 400px">
        <div class="brand-soundwave lg" style="margin-bottom: 16px">
          <span class="sw-col c1"></span>
          <span class="sw-col c2"></span>
          <span class="sw-col c3"></span>
        </div>
        <h2 class="auth-modal-title" style="font-size: 1.5rem">Tvoj hlas má svoj priestor.</h2>
        <p class="auth-modal-desc" style="margin-top: 8px">
          Ulož si pokrok. Alebo pokračuj bez účtu.
        </p>
        <div
          class="cal-spinner"
          style="
            margin: 24px auto 8px auto;
            width: 44px;
            height: 44px;
            border: 3px solid rgba(168, 85, 247, 0.25);
            border-top-color: #a855f7;
            border-radius: 50%;
            animation: spin 1s linear infinite;
          "
        ></div>
      </div>
    </div>

    <!-- ==================================================================== -->
    <!-- OSLAVNÝ MODAL (LEKCIA / DRIL DOKONČENÝ)                              -->
    <!-- ==================================================================== -->
    <div class="celebration-overlay" id="celebrationModal">
      <div class="celebration-card">
        <div class="trophy-bounce">🏆</div>
        <h2 class="celebration-title" id="celebrationTitle">Lekcia dokončená!</h2>
        <p class="celebration-sub" id="celebrationSub">
          Tvoj mozog prepísal ďalšiu kŕčovú dráhu na plynulý nábeh.
        </p>

        <div class="stats-recap-grid">
          <div class="recap-card">
            <div class="recap-label">CELKOVÝ ZISK</div>
            <div class="recap-val xp" id="recapXpVal">+120 XP</div>
          </div>
          <div class="recap-card">
            <div class="recap-label">ÚSPEŠNOSŤ</div>
            <div class="recap-val green" id="recapAccuracyVal">100%</div>
          </div>
          <div class="recap-card">
            <div class="recap-label">DENNÁ SÉRIA</div>
            <div class="recap-val fire" id="recapStreakVal">🔥 1 deň</div>
          </div>
        </div>

        <button class="btn-3d green full lg" id="celebrationBackBtn">
          <span>POKRAČOVAŤ</span>
        </button>
      </div>
    </div>

    <!-- ==================================================================== -->
    <!-- VEDECKÝ ZÁKLAD & KLINICKÉ MODELY (SCIENTIFIC FOUNDATION MODAL)       -->
    <!-- ==================================================================== -->
    <div
      class="science-modal-backdrop"
      id="scienceModalBackdrop"
      role="dialog"
      aria-modal="true"
      aria-labelledby="scienceModalTitle"
    >
      <div class="science-modal-card">
        <!-- Hlavička modálu -->
        <div class="science-modal-header">
          <div class="smh-left">
            <div class="smh-badge">EVIDENCE-BASED NEUROAKUSTIKA</div>
            <h2 class="smh-title" id="scienceModalTitle">Ako to funguje</h2>
            <p class="smh-sub">
              Klinická architektúra, neurobiologické mechanizmy a recenzované citácie aplikácie
              Glide
            </p>
          </div>
          <button class="science-close-btn" id="scienceModalCloseBtn" title="Zavrieť dialóg">
            ✕
          </button>
        </div>

        <!-- Úvodný banner -->
        <div class="science-intro-banner">
          <div class="sib-icon">🔬</div>
          <div class="sib-text">
            Glide Biofeedback vychádza z prísnych empirických výskumov v oblasti motorického
            riadenia reči, neuroakustiky a kognitívno-behaviorálnej terapie balbuties. Kliknutím na
            jednotlivé piliere zobrazíš detailný fyziologický mechanizmus a formálne APA citácie.
          </div>
        </div>

        <!-- Akordeón 5 pilierov -->
        <div class="science-accordion" id="scienceAccordion">
          <!-- -------------------------------------------------------------- -->
          <!-- PILIER 1: DIVA & GODIVA MODEL                                  -->
          <!-- -------------------------------------------------------------- -->
          <article class="science-card" data-pillar="1">
            <header class="sc-header" tabindex="0" role="button" aria-expanded="false">
              <div class="sc-header-left">
                <span class="sc-icon">🧠</span>
                <div class="sc-title-wrap">
                  <div class="sc-lead-tag">PILIER 1 • NEUROVÝPOČTOVÝ MODEL</div>
                  <h3 class="sc-title">DIVA & GODIVA Model (Neurónové riadenie reči)</h3>
                  <p class="sc-summary">
                    Kompenzácia zlyhávajúcej doprednej motorickej väzby vizuálnym biofeedbackom v
                    reálnom čase
                  </p>
                </div>
              </div>
              <div class="sc-header-right">
                <span class="sc-badge">Feedforward Bypass</span>
                <span class="sc-chevron">▼</span>
              </div>
            </header>

            <div class="sc-body">
              <div class="sc-tags">
                <span class="sc-tag">DIVA Architecture</span>
                <span class="sc-tag">GODIVA Sequencing</span>
                <span class="sc-tag">Kortiko-striatálne slučky</span>
                <span class="sc-tag">Latencia &lt; 50 ms</span>
              </div>

              <div class="sc-section">
                <h4 class="sc-sec-title">Neurobiologický a výpočtový mechanizmus</h4>
                <p>
                  Výpočtový model
                  <strong>DIVA (Directions into Velocities of Articulators)</strong> a jeho
                  sekvenčná nadstavba <strong>GODIVA (Gradient Order DIVA)</strong> opisujú reč ako
                  súhru dvoch paralelných systémov:
                </p>
                <ul class="sc-list">
                  <li>
                    <strong>Dopredný podsystém (Feedforward Control):</strong> Rýchly riadiaci okruh
                    lokalizovaný v suplementárnej motorickej oblasti (SMA) a primárnej motorickej
                    kôre (M1). Zodpovedá za okamžité, automatizované spúšťanie fonácie bez čakania
                    na zmyslovú odozvu.
                  </li>
                  <li>
                    <strong>Spätnoväzbový podsystém (Feedback Control):</strong> Pomalší okruh v
                    sluchovej a somatosenzorickej kôre, ktorý porovnáva reálny akustický výstup s
                    očakávaným zmyslovým vzorcom.
                  </li>
                </ul>
                <p>
                  Pri balbuties dochádza k štrukturálnej a funkčnej dysfunkcii v
                  kortiko-striato-talamo-kortikálnych dráhach bazálnych ganglií. Interný dopredný
                  prediktívny model zlyháva v časovaní a generuje falošný somatosenzorický chybový
                  signál. Mozog situáciu vyhodnotí ako kolíziu, okamžite preruší motorický príkaz a
                  pokúsi sa o reštart slabiky – čo sa klinicky prejavuje ako
                  <strong>tonický blok</strong> alebo <strong>klonické opakovanie</strong>.
                </p>
              </div>

              <div class="sc-section">
                <h4 class="sc-sec-title">Aplikácia v motore Glide Biofeedback</h4>
                <p>
                  Aplikácia nahrádza zlyhávajúcu vnútornú somatosenzorickú väzbu
                  <strong>okamžitým externým vizuálnym biofeedbackom v reálnom čase</strong>
                  (vizuálny pacer, okamžitá amplitúdová obálka RMS a spektrálny audit). Vizuálna
                  slučka obchádza poškodené senzorimotorické okruhy, poskytuje kortexu alternatívny
                  stabilizačný signál v latencii do 50 ms a umožňuje vedomú rekalibráciu
                  artikulačného traktu.
                </p>
              </div>

              <div class="sc-citations">
                <div class="cit-header">FORMÁLNE CITÁCIE & POUŽITÁ LITERATÚRA (APA)</div>
                <ul class="cit-list">
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Guenther, F. H., Ghosh, S. S., & Tourville, J. A. (2006). Neural modeling and
                      imaging of the cortical interactions underlying syllable production.
                      <em>Brain and Language</em>, 96(3), 280–301.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.1016/j.bandl.2005.06.001"
                      target="_blank"
                      rel="noopener"
                      >doi:10.1016/j.bandl.2005.06.001</a
                    >
                  </li>
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Bohland, J. W., Bullock, D., & Guenther, F. H. (2010). Neural representations
                      and mechanisms for the performance of action sequences: The GODIVA model.
                      <em>Cerebral Cortex</em>, 20(4), 844–867.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.1093/cercor/bhp152"
                      target="_blank"
                      rel="noopener"
                      >doi:10.1093/cercor/bhp152</a
                    >
                  </li>
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Tourville, J. A., & Guenther, F. H. (2011). The DIVA model: A neural theory
                      of speech acquisition and production.
                      <em>Language and Cognitive Processes</em>, 26(7), 952–981.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.1080/01690960903498424"
                      target="_blank"
                      rel="noopener"
                      >doi:10.1080/01690960903498424</a
                    >
                  </li>
                </ul>
              </div>
            </div>
          </article>

          <!-- -------------------------------------------------------------- -->
          <!-- PILIER 2: GENTLE VOICE ONSET & AKUSTIKA VRT                    -->
          <!-- -------------------------------------------------------------- -->
          <article class="science-card" data-pillar="2">
            <header class="sc-header" tabindex="0" role="button" aria-expanded="false">
              <div class="sc-header-left">
                <span class="sc-icon">📈</span>
                <div class="sc-title-wrap">
                  <div class="sc-lead-tag">PILIER 2 • AKUSTICKÁ BIOMETRIKA</div>
                  <h3 class="sc-title">Gentle Voice Onset & Akustika VRT (Mäkký nábeh)</h3>
                  <p class="sc-summary">
                    Eliminácia tvrdého glotálneho rázu a hyperaddukcie hlasiviek riadeným predĺžením
                    nábehu akustického tlaku
                  </p>
                </div>
              </div>
              <div class="sc-header-right">
                <span class="sc-badge">VRT 60–140 ms</span>
                <span class="sc-chevron">▼</span>
              </div>
            </header>

            <div class="sc-body">
              <div class="sc-tags">
                <span class="sc-tag">Vocal Rise Time</span>
                <span class="sc-tag">Hollins Fluency System</span>
                <span class="sc-tag">Laryngálna addukcia</span>
                <span class="sc-tag">M. thyroarytenoideus</span>
              </div>

              <div class="sc-section">
                <h4 class="sc-sec-title">Fyziologický a akustický mechanizmus</h4>
                <p>
                  Primárnym mechanickým spúšťačom laryngálneho bloku pri iniciácii samohlások a
                  plozív je <strong>tvrdý glotálny ráz (hard glottal attack)</strong>. Ešte pred
                  začiatkom fonácie dochádza k nadmernej hyperaddukcii a stiahnutiu vnútorných
                  hlasivkových svalov (najmä <em>m. thyroarytenoideus</em> a
                  <em>m. cricoarytenoideus lateralis</em>). Pľúcny exspiračný tlak narastá za pevne
                  uzavretou glotis, až kým nedôjde k explozívnemu akustickému tresku (VRT &lt; 45
                  ms) alebo k úplnému laryngálnemu spazmu.
                </p>
                <p>
                  Klinická metodika <strong>Gentle Voice Onset (GVO)</strong>, vyvinutá v rámci
                  Hollins Fluency System (Dr. Ronald Webster), trénuje plynulý, kontrolovaný prechod
                  od subfonatórneho laminárneho prúdenia vzduchu k postupnému rozkmitaniu
                  slizničného krytu hlasiviek. Akustickým indexom tejto mäkkosti je
                  <strong>Nábeh hlasu</strong> – časový interval potrebný na vzostup amplitúdy
                  zvukovej obálky z 20 % na 80 % saturovaného RMS signálu.
                </p>
              </div>

              <div class="sc-section">
                <h4 class="sc-sec-title">Aplikácia v motore Glide Biofeedback</h4>
                <p>
                  Modul <code>dsp-core.js</code> vykonáva sub-milisekundový výpočet obálky signálu
                  metódou kĺzavého RMS okna. Systém kalibruje tri diagnostické zóny:
                </p>
                <ul class="sc-list">
                  <li>
                    <span class="sc-stat-pill red">&lt; 45 ms (Tvrdý glotálny ráz):</span> Prudký
                    úder v hrtane, riziko spazmu. Aplikácia neakceptuje pokus ako Perfect a navrhne
                    jemnejší začiatok s výdychom.
                  </li>
                  <li>
                    <span class="sc-stat-pill green">60–140 ms (Orientačné meranie):</span>
                    Optimálny fyziologický nábeh sliznice, uvoľnené suprahyoidné svalstvo, zlatý
                    štandard plynulosti.
                  </li>
                  <li>
                    <span class="sc-stat-pill purple"
                      >&gt; 240 ms (Dychový únik / Aspiration):</span
                    >
                    Nadmerný únik vzduchu bez včasného kontaktu hlasiviek (hypoaddukcia).
                  </li>
                </ul>
              </div>

              <div class="sc-citations">
                <div class="cit-header">FORMÁLNE CITÁCIE & POUŽITÁ LITERATÚRA (APA)</div>
                <ul class="cit-list">
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Webster, R. L. (1974). A behavioral analysis of stuttering: Presentation of a
                      rationale with speech improvement targets. In K. S. Calhoun, H. E. Adams, & K.
                      M. Mitchell (Eds.),
                      <em>Innovative treatment methods in psychopathology</em> (pp. 73–96). John
                      Wiley & Sons.</span
                    >
                  </li>
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Mallard, A. R., & Westbrook, J. B. (1983). Vowel duration in stutterers and
                      nonstutterers: A study of gentle onset. <em>Journal of Fluency Disorders</em>,
                      8(3), 279–285.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.1016/0094-730X(83)90010-8"
                      target="_blank"
                      rel="noopener"
                      >doi:10.1016/0094-730X(83)90010-8</a
                    >
                  </li>
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Peters, H. F. M., & Boves, L. (1988). Coordination of aerodynamic and
                      phonatory processes in stuttering and normal speech.
                      <em>Journal of Speech and Hearing Research</em>, 31(3), 352–361.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.1044/jshr.3103.352"
                      target="_blank"
                      rel="noopener"
                      >doi:10.1044/jshr.3103.352</a
                    >
                  </li>
                </ul>
              </div>
            </div>
          </article>

          <!-- -------------------------------------------------------------- -->
          <!-- PILIER 3: CHORAL SPEECH EFFECT & DAF MODULÁCIA                 -->
          <!-- -------------------------------------------------------------- -->
          <article class="science-card" data-pillar="3">
            <header class="sc-header" tabindex="0" role="button" aria-expanded="false">
              <div class="sc-header-left">
                <span class="sc-icon">🎧</span>
                <div class="sc-title-wrap">
                  <div class="sc-lead-tag">PILIER 3 • AUDITÍVNA NEUROSTIMULÁCIA</div>
                  <h3 class="sc-title">Choral Speech Effect & Sluchová modulácia (DAF)</h3>
                  <p class="sc-summary">
                    Oneskorená sluchová spätná väzba (40–140 ms) obchádzajúca časovú dysfunkciu
                    bazálnych ganglií
                  </p>
                </div>
              </div>
              <div class="sc-header-right">
                <span class="sc-badge">DAF 70 ms</span>
                <span class="sc-chevron">▼</span>
              </div>
            </header>

            <div class="sc-body">
              <div class="sc-tags">
                <span class="sc-tag">Delayed Auditory Feedback</span>
                <span class="sc-tag">Choral Effect</span>
                <span class="sc-tag">Reaktivácia STG</span>
                <span class="sc-tag">DAF Architektúra</span>
              </div>

              <div class="sc-section">
                <h4 class="sc-sec-title">Neurobiologický mechanizmus efektu zborovej reči</h4>
                <p>
                  Jedným z najvýraznejších a najlepšie preskúmaných fenoménov v rečovej patológii je
                  <strong>efekt zborovej reči (choral speech effect)</strong>: ak osoba so
                  zajakavosťou číta alebo hovorí súčasne v synchronizácii s iným rečníkom, prejavy
                  zajakavosti okamžite klesajú o 80 až 90 % bez nutnosti vedomej techniky.
                </p>
                <p>
                  Neurozobrazovacie fMRI štúdie (Foundas et al., 2004) odhalili, že u osôb s
                  balbuties je počas vlastnej reči ľavá sluchová kôra (najmä
                  <em>gyrus temporalis superior</em> – STG a <em>planum temporale</em>) hypoaktívna,
                  zatiaľ čo pravá hemisféra vykazuje neefektívnu kompenzačnú hyperaktivitu.
                  <strong
                    >Oneskorená sluchová spätná väzba (Delayed Auditory Feedback – DAF)</strong
                  >
                  v rozsahu 50–100 ms simuluje prítomnosť druhého hovoriaceho hlasu priamo v uchu.
                  Tento signál vyvoláva masívnu bilaterálnu reaktiváciu STG a poskytuje kortikálnym
                  okruhom externý rytmický kľúč (<em>external pacing cue</em>), ktorý nahrádza
                  porušené biologické hodiny v bazálnych gangliách.
                </p>
              </div>

              <div class="sc-section">
                <h4 class="sc-sec-title">Aplikácia v motore Glide Biofeedback</h4>
                <p>
                  Záložka <strong>"🎧 Asistent"</strong> prináša klinický ekvivalent prenosných DAF
                  zariadení priamo do webového rozhrania. Cez Web Audio API je vytvorená paralelná,
                  nízko-latenčná zvuková vetva (<code
                    >mediaStreamSource → DelayNode → GainNode → destination</code
                  >), ktorá neovplyvňuje analytický DSP motor. Používateľ má k dispozícii
                  kalibrovaný rozsah 40–140 ms s optimálnym klinickým stredom
                  <strong>70 ms</strong> a vizuálnym pulzným indikátorom prenosu hlasu do ucha.
                </p>
              </div>

              <div class="sc-citations">
                <div class="cit-header">FORMÁLNE CITÁCIE & POUŽITÁ LITERATÚRA (APA)</div>
                <ul class="cit-list">
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Kalinowski, J., Stuart, A., Sark, S., & Armson, J. (1996). Stuttering
                      amelioration at various auditory delays and speech rates.
                      <em>European Journal of Disorders of Communication</em>, 31(3), 259–269.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.3109/13682829609033157"
                      target="_blank"
                      rel="noopener"
                      >doi:10.3109/13682829609033157</a
                    >
                  </li>
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Foundas, A. L., Bollich, A. M., Feldman, J., Corey, D. M., Hurley, M., Lemen,
                      L. C., & Heilman, K. M. (2004). Aberrant auditory-motor processing in
                      developmental stuttering: An fMRI study.
                      <em>Cognitive and Behavioral Neurology</em>, 17(2), 77–85.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.1097/00146965-200406000-00004"
                      target="_blank"
                      rel="noopener"
                      >doi:10.1097/00146965-200406000-00004</a
                    >
                  </li>
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Stuart, A., Kalinowski, J., Rastatter, M. P., & Saltuklaroglu, T. (2004).
                      Investigations of the impact of altered auditory feedback in-the-ear devices
                      on the speech of people who stutter: One-year follow-up.
                      <em>Disability and Rehabilitation</em>, 26(14–15), 830–841.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.1080/09638280410001699419"
                      target="_blank"
                      rel="noopener"
                      >doi:10.1080/09638280410001699419</a
                    >
                  </li>
                </ul>
              </div>
            </div>
          </article>

          <!-- -------------------------------------------------------------- -->
          <!-- PILIER 4: VALSALVOV REFLEX A DEKOMPRESIA MANDIBULY             -->
          <!-- -------------------------------------------------------------- -->
          <article class="science-card" data-pillar="4">
            <header class="sc-header" tabindex="0" role="button" aria-expanded="false">
              <div class="sc-header-left">
                <span class="sc-icon">&#129729;</span>
                <div class="sc-title-wrap">
                  <div class="sc-lead-tag">PILIER 4 • BIOMECHANICKÁ DEKOMPRESIA</div>
                  <h3 class="sc-title">Valsalvov reflex a dekompresia mandibuly (SOS Dril)</h3>
                  <p class="sc-summary">
                    Rozpojenie nevedomého zovretia hrtanových zvieračov mechanickým uvoľnením sánky
                    o 2–3 mm
                  </p>
                </div>
              </div>
              <div class="sc-header-right">
                <span class="sc-badge">Valsalva Bypass</span>
                <span class="sc-chevron">▼</span>
              </div>
            </header>

            <div class="sc-body">
              <div class="sc-tags">
                <span class="sc-tag">Valsalva Mechanism</span>
                <span class="sc-tag">Mandibulárna dekompresia</span>
                <span class="sc-tag">Suprahyoidné svalstvo</span>
                <span class="sc-tag">Laryngálny spazmus</span>
              </div>

              <div class="sc-section">
                <h4 class="sc-sec-title">Biomechanický a fyziologický mechanizmus</h4>
                <p>
                  Výskum klinického neurológa a rečového teoretika Dr. Williama D. Parryho
                  formuloval hypotézu <strong>Valsalvovho mechanizmu (Valsalva Hypothesis)</strong>.
                  Podľa tohto modelu nevzniká rečový blok v primárnych jazykových centrách, ale
                  spustením primitívneho reflexu tlaku v hrtane. Valsalvov reflex je evolučne starý
                  obranný program: slúži na nepriedušné uzatvorenie dýchacích ciest pri ťažkej
                  fyzickej námahe (dvíhanie bremien, tlačenie, defekácia) prostredníctvom pevných
                  laryngeálnych zvieračov.
                </p>
                <p>
                  Keď rečník anticipuje náročnú hlásku alebo sociálne ohrozenie, mozog situáciu
                  chybne interpretuje ako potrebu "vynaložiť viac sily na pretlačenie slova". Tento
                  impulz zapne Valsalvov reflex: suprahyoidné svaly (<em>m. mylohyoideus</em>,
                  <em>m. geniohyoideus</em>) vytiahnu jazylku a sánku smerom hore a hrtanové
                  zvierače sa reflexne hermeticky zovrú. Čím viac sa človek snaží slovo silou
                  vytlačiť, tým silnejšie sa zvierače zovrú.
                </p>
              </div>

              <div class="sc-section">
                <h4 class="sc-sec-title">Aplikácia v motore Glide Biofeedback</h4>
                <p>
                  Záložka <strong>"⚡ Rýchly Dril" (SOS Sandbox)</strong> poskytuje rýchlu terénnu
                  rekalibráciu pred reálnym sociálnym vstupom (napr. pred nákupom, hovorom či
                  poradou). Pacer aplikácie vedie rečníka k cielenej
                  <strong>dekompresii mandibuly</strong>: mechanickému uvoľneniu spodnej sánky o 2
                  až 3 milimetre (zubné oblúky sa nesmú dotýkať, pery len jemne priľnú). Tento
                  jednoduchý pohyb mechanicky neutralizuje ťah suprahyoidných svalov, čo
                  fyziologicky znemožňuje zopnutie zvieračov hrtana a rozbíja patologický Valsalvov
                  reflex ešte pred prvou fonáciou.
                </p>
              </div>

              <div class="sc-citations">
                <div class="cit-header">FORMÁLNE CITÁCIE & POUŽITÁ LITERATÚRA (APA)</div>
                <ul class="cit-list">
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Parry, W. D. (1985/2013).
                      <em
                        >Understanding & controlling stuttering: A comprehensive new approach based
                        on the Valsalva mechanism</em
                      >
                      (3rd ed.). National Stuttering Association.</span
                    >
                  </li>
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Smith, A., & Denny, M. (1990). High-frequency oscillations in human speech
                      muscle activity. <em>Brain Research</em>, 534(1–2), 269–274.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.1016/0006-8993(90)90141-8"
                      target="_blank"
                      rel="noopener"
                      >doi:10.1016/0006-8993(90)90141-8</a
                    >
                  </li>
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Loucks, T. M., & De Nil, L. F. (2006). Anomalous sensorimotor integration in
                      developmental stuttering: A review.
                      <em>International Journal of Orofacial Myology</em>, 32, 22–37.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.52010/ijom.2006.32.1.3"
                      target="_blank"
                      rel="noopener"
                      >doi:10.52010/ijom.2006.32.1.3</a
                    >
                  </li>
                </ul>
              </div>
            </div>
          </article>

          <!-- -------------------------------------------------------------- -->
          <!-- PILIER 5: HIERARCHICKÁ DESENZIBILIZÁCIA A STRESOVÁ INOKULÁCIA  -->
          <!-- -------------------------------------------------------------- -->
          <article class="science-card" data-pillar="5">
            <header class="sc-header" tabindex="0" role="button" aria-expanded="false">
              <div class="sc-header-left">
                <span class="sc-icon">⚡</span>
                <div class="sc-title-wrap">
                  <div class="sc-lead-tag">PILIER 5 • BEHAVIORÁLNA INOKULÁCIA</div>
                  <h3 class="sc-title">
                    Hierarchická desenzibilizácia a stresová inokulácia (5 Svetov)
                  </h3>
                  <p class="sc-summary">
                    Postupné vrstvenie psychofyziologickej záťaže od samohlások po prepadové hovory
                    s kamerou
                  </p>
                </div>
              </div>
              <div class="sc-header-right">
                <span class="sc-badge">Stress Inoculation</span>
                <span class="sc-chevron">▼</span>
              </div>
            </header>

            <div class="sc-body">
              <div class="sc-tags">
                <span class="sc-tag">Stress Inoculation Training</span>
                <span class="sc-tag">Van Riper Therapy</span>
                <span class="sc-tag">Reakčný limit 550 ms</span>
                <span class="sc-tag">Kamerový očný kontakt</span>
              </div>

              <div class="sc-section">
                <h4 class="sc-sec-title">Psychofyziologický mechanizmus a sympatiková regulácia</h4>
                <p>
                  Plynulosť reči je mimoriadne zraniteľná voči aktivácii sympatikového nervového
                  systému. V reálnych sociálnych interakciách vyvoláva hrozba zlyhania okamžitú
                  autonómnu sympatikovú reakciu – vyplavenie katecholamínov, zrýchlenie srdcovej
                  frekvencie a motorickú reakciu typu <em>freeze</em> v orofaciálnej oblasti. Ak je
                  tréning obmedzený len na bezpečné, tiché laboratórne podmienky, dochádza k
                  nulovému transferu zručností do reálneho života.
                </p>
                <p>
                  Koncept
                  <strong
                    >stresovej inokulácie (Stress Inoculation Training – SIT, Donald Meichenbaum,
                    1985)</strong
                  >
                  v kombinácii s klasickou
                  <strong>desenzibilizačnou terapiou Charlesa Van Ripera (1973)</strong> a
                  kognitívno-behaviorálnymi protokolmi (Menzies et al., 2008) buduje trvalú odolnosť
                  voči blokom riadeným, postupným dávkovaním záťaže priamo počas nácviku motorického
                  vzorca.
                </p>
              </div>

              <div class="sc-section">
                <h4 class="sc-sec-title">Aplikácia v 5 Svetoch Glide Biofeedback</h4>
                <p>
                  Cesta 5 Svetov je presne odstupňovaná podľa náročnosti autonómnej nervovej záťaže:
                </p>
                <ul class="sc-list">
                  <li>
                    <strong>Svet 1: Samohlásky (A, O, E, U, I):</strong> Bezpečné prostredie bez
                    časového limitu; izolovaný nábehový tréning sliznice (VRT).
                  </li>
                  <li>
                    <strong>Svet 2: Znelé spoluhlásky (M, N, V, L):</strong> Udržanie nepretržitého
                    kmitania hlasiviek cez artikulačné prechody.
                  </li>
                  <li>
                    <strong>Svet 3: Plozívy a zhluky (P, T, K, CH, Štv-):</strong> Tlmenie
                    aerodynamických rázov v artikulačných bodoch bez barličiek.
                  </li>
                  <li>
                    <strong>Svet 4: Pokladňa & Rýchlosť:</strong> Reakčný limit
                    <strong>550 ms</strong> (zvukový prompt pokladne) – eliminuje priestor na
                    anticipačnú paniku a trénuje okamžitú automatickú dekompresiu sánky.
                  </li>
                  <li>
                    <strong>Svet 5: Boss Fights (Prepadové hovory & Sociálna expozícia):</strong>
                    Telefonáty s nepredvídateľnými reakciami oponenta (kuriér, lekár, automechanik)
                    v kombinácii s voliteľným zrkadlom prednej webkamery pre nácvik stabilného
                    očného kontaktu pri reči.
                  </li>
                </ul>
              </div>

              <div class="sc-citations">
                <div class="cit-header">FORMÁLNE CITÁCIE & POUŽITÁ LITERATÚRA (APA)</div>
                <ul class="cit-list">
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Van Riper, C. (1973). <em>The treatment of stuttering</em>.
                      Prentice-Hall.</span
                    >
                  </li>
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Meichenbaum, D. (1985). <em>Stress inoculation training</em>. Pergamon
                      Press.</span
                    >
                  </li>
                  <li class="cit-item">
                    <span class="cit-ref"
                      >Menzies, R. G., Onslow, M., Packman, A., & O’Brian, S. (2008). Cognitive
                      behavior therapy for adults who stutter: A tutorial for speech-language
                      pathologists. <em>Journal of Speech, Language, and Hearing Research</em>,
                      51(6), 1451–1464.</span
                    >
                    <a
                      class="cit-doi"
                      href="https://doi.org/10.1044/1092-4388(2008/07-0259)"
                      target="_blank"
                      rel="noopener"
                      >doi:10.1044/1092-4388(2008/07-0259)</a
                    >
                  </li>
                </ul>
              </div>
            </div>
          </article>
        </div>

        <!-- Pätička modálu -->
        <div class="science-modal-footer">
          <div class="smf-disclaimer">
            ⚠️ <strong>Upozornenie:</strong> Glide Biofeedback je neuro-tréningový biofeedback
            systém zameraný na motorické učenie reči. Nenahrádza individuálnu diagnostiku a
            intervenciu certifikovaného klinického logopéda.
          </div>
          <button class="btn-3d slate full" id="closeScienceModalBtn">
            <span>← SPÄŤ NA TELEMETRIU</span>
          </button>
        </div>
      </div>
    </div>

    <!-- Skripty -->
  </div>
  <!-- /#appLayout -->
</div>
<!-- /.app-shell-container -->

<!-- Skripty enginov -->

<!-- PWA Service Worker & Install Manager -->
`,b=o((e=>{(function(){function t(e){if(e==null)return null;if(typeof e==`function`)return e.$$typeof===se?null:e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case v:return`Fragment`;case b:return`Profiler`;case y:return`StrictMode`;case re:return`Suspense`;case ie:return`SuspenseList`;case x:return`Activity`}if(typeof e==`object`)switch(typeof e.tag==`number`&&console.error(`Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue.`),e.$$typeof){case _:return`Portal`;case te:return e.displayName||`Context`;case ee:return(e._context.displayName||`Context`)+`.Consumer`;case ne:var n=e.render;return e=e.displayName,e||=(e=n.displayName||n.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case ae:return n=e.displayName||null,n===null?t(e.type)||`Memo`:n;case oe:n=e._payload,e=e._init;try{return t(e(n))}catch{}}return null}function n(e){return``+e}function r(e){try{n(e);var t=!1}catch{t=!0}if(t){t=console;var r=t.error,i=typeof Symbol==`function`&&Symbol.toStringTag&&e[Symbol.toStringTag]||e.constructor.name||`Object`;return r.call(t,`The provided key is an unsupported type %s. This value must be coerced to a string before using it here.`,i),n(e)}}function i(e){if(e===v)return`<>`;if(typeof e==`object`&&e&&e.$$typeof===oe)return`<...>`;try{var n=t(e);return n?`<`+n+`>`:`<...>`}catch{return`<...>`}}function a(){var e=S.A;return e===null?null:e.getOwner()}function o(){return Error(`react-stack-top-frame`)}function s(e){if(ce.call(e,`key`)){var t=Object.getOwnPropertyDescriptor(e,`key`).get;if(t&&t.isReactWarning)return!1}return e.key!==void 0}function c(e,t){function n(){ue||(ue=!0,console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)",t))}n.isReactWarning=!0,Object.defineProperty(e,`key`,{get:n,configurable:!0})}function l(){var e=t(this.type);return de[e]||(de[e]=!0,console.error(`Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release.`)),e=this.props.ref,e===void 0?null:e}function d(e,t,n,r,i,a){var o=n.ref;return e={$$typeof:g,type:e,key:t,props:n,_owner:r},(o===void 0?null:o)===null?Object.defineProperty(e,`ref`,{enumerable:!1,value:null}):Object.defineProperty(e,`ref`,{enumerable:!1,get:l}),e._store={},Object.defineProperty(e._store,`validated`,{configurable:!1,enumerable:!1,writable:!0,value:0}),Object.defineProperty(e,`_debugInfo`,{configurable:!1,enumerable:!1,writable:!0,value:null}),Object.defineProperty(e,`_debugStack`,{configurable:!1,enumerable:!1,writable:!0,value:i}),Object.defineProperty(e,`_debugTask`,{configurable:!1,enumerable:!1,writable:!0,value:a}),Object.freeze&&(Object.freeze(e.props),Object.freeze(e)),e}function f(e,n,i,o,l,u){var f=n.children;if(f!==void 0)if(o)if(le(f)){for(o=0;o<f.length;o++)p(f[o]);Object.freeze&&Object.freeze(f)}else console.error(`React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.`);else p(f);if(ce.call(n,`key`)){f=t(e);var m=Object.keys(n).filter(function(e){return e!==`key`});o=0<m.length?`{key: someKey, `+m.join(`: ..., `)+`: ...}`:`{key: someKey}`,me[f+o]||(m=0<m.length?`{`+m.join(`: ..., `)+`: ...}`:`{}`,console.error(`A props object containing a "key" prop is being spread into JSX:
  let props = %s;
  <%s {...props} />
React keys must be passed directly to JSX without using spread:
  let props = %s;
  <%s key={someKey} {...props} />`,o,f,m,f),me[f+o]=!0)}if(f=null,i!==void 0&&(r(i),f=``+i),s(n)&&(r(n.key),f=``+n.key),`key`in n)for(var h in i={},n)h!==`key`&&(i[h]=n[h]);else i=n;return f&&c(i,typeof e==`function`?e.displayName||e.name||`Unknown`:e),d(e,f,i,a(),l,u)}function p(e){m(e)?e._store&&(e._store.validated=1):typeof e==`object`&&e&&e.$$typeof===oe&&(e._payload.status===`fulfilled`?m(e._payload.value)&&e._payload.value._store&&(e._payload.value._store.validated=1):e._store&&(e._store.validated=1))}function m(e){return typeof e==`object`&&!!e&&e.$$typeof===g}var h=u(),g=Symbol.for(`react.transitional.element`),_=Symbol.for(`react.portal`),v=Symbol.for(`react.fragment`),y=Symbol.for(`react.strict_mode`),b=Symbol.for(`react.profiler`),ee=Symbol.for(`react.consumer`),te=Symbol.for(`react.context`),ne=Symbol.for(`react.forward_ref`),re=Symbol.for(`react.suspense`),ie=Symbol.for(`react.suspense_list`),ae=Symbol.for(`react.memo`),oe=Symbol.for(`react.lazy`),x=Symbol.for(`react.activity`),se=Symbol.for(`react.client.reference`),S=h.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ce=Object.prototype.hasOwnProperty,le=Array.isArray,C=console.createTask?console.createTask:function(){return null};h={react_stack_bottom_frame:function(e){return e()}};var ue,de={},fe=h.react_stack_bottom_frame.bind(h,o)(),pe=C(i(o)),me={};e.Fragment=v,e.jsxDEV=function(e,t,n,r){var a=1e4>S.recentlyCreatedOwnerStacks++;return f(e,t,n,r,a?Error(`react-stack-top-frame`):fe,a?C(i(e)):pe)}})()})),ee=o(((e,t)=>{t.exports=b()}))(),te=`modulepreload`,ne=function(e){return`/`+e},re={},ie=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}r=o(t.map(t=>{if(t=ne(t,n),t in re)return;re[t]=!0;let r=t.endsWith(`.css`),i=r?`[rel="stylesheet"]`:``;if(n)for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}else if(document.querySelector(`link[href="${t}"]${i}`))return;let o=document.createElement(`link`);if(o.rel=r?`stylesheet`:te,r||(o.as=`script`),o.crossOrigin=``,o.href=t,a&&o.setAttribute(`nonce`,a),document.head.appendChild(o),r)return new Promise((e,n)=>{o.addEventListener(`load`,e),o.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},ae=`/tmp/glide-publish/web/src/App.tsx`,oe=window;function x(){let e=document.getElementById(`glide-runtime`);return!e&&document.querySelector(`script[src="/engine/dsp-core.js"]`)?(window.location.reload(),new Promise(()=>{})):(e||(e=document.createElement(`div`),e.id=`glide-runtime`,e.innerHTML=y,document.body.appendChild(e)),oe.glideEngineReady||=(async()=>{Object.assign(window,{supabase:await ie(()=>import(`./dist-3jsWS96F.js`),[])});for(let e of[`questions-and-voices`,`dsp-core`,`gamification-engine`,`daf-assistant`,`interface`,`supabase-auth`,`lifecycle`])await new Promise((t,n)=>{let r=document.createElement(`script`);r.src=`/engine/${e}.js`,r.onload=()=>t(),r.onerror=()=>n(Error(`Nepodarilo sa načítať modul ${e}.`)),document.body.appendChild(r)});document.documentElement.dataset.engine=`ready`})(),oe.glideEngineReady)}function se(){let[e,t]=(0,_.useState)(``);return(0,_.useEffect)(()=>{document.title=`Glide – Tvoj hlas, tvoje tempo`,document.documentElement.lang=`sk`,x().catch(e=>t(e.message))},[]),(0,ee.jsxDEV)(ee.Fragment,{children:e&&(0,ee.jsxDEV)(`div`,{className:`engine-error`,role:`alert`,children:[(0,ee.jsxDEV)(`strong`,{children:`Tréning sa nepodarilo spustiť.`},void 0,!1,{fileName:ae,lineNumber:79,columnNumber:11},this),(0,ee.jsxDEV)(`p`,{children:e},void 0,!1,{fileName:ae,lineNumber:80,columnNumber:11},this),(0,ee.jsxDEV)(`button`,{onClick:()=>window.location.reload(),children:`Skúsiť znova`},void 0,!1,{fileName:ae,lineNumber:81,columnNumber:11},this)]},void 0,!0,{fileName:ae,lineNumber:78,columnNumber:9},this)},void 0,!1)}var S=`/tmp/glide-publish/web/src/main.tsx`;v.createRoot(document.getElementById(`root`)).render((0,ee.jsxDEV)(_.StrictMode,{children:(0,ee.jsxDEV)(se,{},void 0,!1,{fileName:S,lineNumber:8,columnNumber:5},void 0)},void 0,!1,{fileName:S,lineNumber:7,columnNumber:3},void 0));